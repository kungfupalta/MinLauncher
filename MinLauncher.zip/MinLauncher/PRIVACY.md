# Privacidad

MinLauncher no recolecta, envía ni comparte ningún dato.

- **Sin internet:** la app no declara el permiso `INTERNET`, así que no puede conectarse a ningún servidor.
- **Todo local:** tus ajustes, apps fijadas, nombres, apps ocultas y el conteo de "más usadas" se guardan solo en el almacenamiento privado de la app. Podés exportarlos a un archivo si querés.
- **Sin analítica ni publicidad:** no incluye librerías de seguimiento ni de Google.
- **Búsqueda web:** si buscás algo que no es una app, MinLauncher abre tu navegador con DuckDuckGo. Lo que escribas lo recibe esa página, no MinLauncher.
- **Accesibilidad (opcional):** el servicio solo ejecuta la acción "bloquear pantalla" cuando hacés el gesto. No recibe eventos y no puede leer lo que hay en la pantalla.
