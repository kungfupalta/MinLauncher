# Cómo contribuir a MinLauncher

¡Gracias por querer ayudar! Estas son las reglas básicas.

## Antes de empezar
- Buscá en los *issues* si ya existe lo que querés reportar o proponer.
- Para cambios grandes, abrí primero un issue y lo charlamos.

## Valores del proyecto
- **Sin internet, sin rastreo, sin publicidad.** No se aceptan librerías ni cambios que agreguen el permiso `INTERNET` o analítica.
- **Pocas dependencias.** Preferimos las APIs de Android y Compose antes que sumar librerías.
- **Simple y rápido.** La pantalla de inicio tiene que abrir al instante.

## Cómo enviar un cambio
1. Hacé un *fork* y una rama (`git checkout -b mi-cambio`).
2. Probalo en un teléfono real o emulador (Android 12+), también en horizontal y con tema claro y oscuro.
3. Corré los tests: `gradle :app:testDebugUnitTest`.
4. Si cambia algo visible, sumá una línea a `CHANGELOG.md` bajo *Sin publicar*.
5. Abrí el *pull request* explicando qué cambia y por qué.

## Estilo
- Kotlin con el estilo oficial (`kotlin.code.style=official`).
- Los textos de la interfaz van en español rioplatense, igual que el resto de la app.
- Comentá el *por qué*, no el *qué*.
