# MinLauncher

Un launcher para Android **minimalista, gratuito y de código abierto**. Sin publicidad, sin rastreo y **sin permiso de internet**: todo queda en tu teléfono.

*English: a minimalist, free and open-source Android launcher. No ads, no tracking, no internet permission. See [Build](#compilar) and [Contributing](CONTRIBUTING.md).*

## Funciones

**Inicio**
- Reloj grande y fecha, con formato 24 h / 12 h / del sistema, tamaño y alineación a gusto.
- Lista de apps fijadas con nombres que podés renombrar y reordenar.
- **Widget de hora doble** (Hora Arianna: Ecuador · Hora Marcos: Argentina). Se quita manteniéndolo apretado y se vuelve a agregar en Ajustes > Inicio.
- Fondo de pantalla visible con velo regulable (hasta negro puro para ahorrar batería en pantallas AMOLED).

**Cajón de apps**
- Búsqueda que ignora tildes (`camara` encuentra *Cámara*), por varias palabras y por iniciales (`gm` encuentra *Google Maps*).
- Si no hay resultados, ofrece buscar en la web (DuckDuckGo).
- Índice alfabético, vista en cuadrícula o lista y fila de **más usadas** (el conteo queda solo en tu teléfono).
- Apps ocultas, atajos de cada app (como "Nuevo mensaje") al mantener apretada, info de la app y desinstalar.

**Personalización**
- Tema oscuro, claro o del sistema, y color de acento (incluye los colores del sistema, Material You).
- Iconos con forma elegible (squircle, círculo, redondeado, cuadrado), tamaño ajustable e **iconos temáticos**.
- **Gestos configurables**: deslizar arriba / abajo / izquierda / derecha, doble toque y mantener apretado. Cada uno puede abrir el cajón, las notificaciones, bloquear la pantalla, los ajustes o cualquier app.
- Copia de seguridad: exportá e importá todos tus ajustes en un archivo JSON.

**Primera vez**
- Una guía de bienvenida te ayuda a dejarlo como **launcher predeterminado** (con el aviso oficial de Android) y a elegir tema, colores, reloj, apps y gestos desde el principio.

## Instalación

1. Bajá el APK desde la sección *Releases* (o desde la pestaña *Actions* > *Build APK* > artefactos).
2. Permití instalar desde esa fuente si Android lo pide y abrí el APK.
3. Abrí MinLauncher: la guía de bienvenida te lleva a dejarlo como predeterminado. También podés hacerlo en *Ajustes de Android > Apps > Apps predeterminadas > App de inicio*.

Requiere Android 12 o superior (API 31).

## Permisos y privacidad

| Permiso | Para qué |
|---|---|
| `REQUEST_DELETE_PACKAGES` | Desinstalar apps desde el menú del launcher. |
| `EXPAND_STATUS_BAR` | Abrir el panel de notificaciones con un gesto. Usa una API oculta de Android: si tu versión la bloquea, el gesto simplemente no hace nada. |
| Servicio de accesibilidad (opcional) | Solo para el gesto *Bloquear pantalla*. No recibe eventos ni lee la pantalla: ver [`lock_service.xml`](app/src/main/res/xml/lock_service.xml). En Android 13+ puede hacer falta permitir los ajustes restringidos desde *Info de la app*. |

No hay permiso de internet, ni analítica, ni servicios de Google. Más detalle en [PRIVACY.md](PRIVACY.md).

## Compilar

Necesitás JDK 17 y el SDK de Android (compileSdk 36). Lo más simple es abrir la carpeta con **Android Studio**.

Por línea de comandos (el proyecto no incluye el *Gradle wrapper*; usá Gradle 8.11.1 o creá el wrapper una vez con `gradle wrapper --gradle-version 8.11.1`):

```bash
gradle :app:testDebugUnitTest      # tests
gradle :app:assembleRelease        # APK en app/build/outputs/apk/release/
```

GitHub Actions compila y prueba cada push y pull request. Al subir una etiqueta (`git tag v1.1.0 && git push --tags`) publica el APK en *Releases*.

### Firmar con tu propia clave

El APK de `release` se firma con la clave *debug* para poder instalarlo directo. Para publicar de verdad (GitHub Releases, F-Droid) creá tu propio *keystore*, agregá una `signingConfig` en `app/build.gradle.kts` leyendo las contraseñas de variables de entorno, y **nunca subas el `.jks` al repositorio** (ya está en `.gitignore`).

## Estructura del código

| Archivo | Qué hay |
|---|---|
| `MainActivity.kt` | Actividad HOME, avisos de "Inicio" y de vuelta a primer plano. |
| `Ui.kt` | Raíz, pantalla de inicio, gestos, reloj y cajón de apps. |
| `Sheets.kt` | Menú de cada app, editor del inicio, selector de apps, renombrar. |
| `SettingsScreen.kt` | Pantalla de ajustes y piezas reutilizables. |
| `Onboarding.kt` | Guía de bienvenida de primera vez. |
| `Widgets.kt` | Widget de hora doble. Para cambiar nombres o zonas horarias, editá `WorldClockEntries`. |
| `Theme.kt` | Paletas oscura/clara, color de acento, barras del sistema. |
| `Settings.kt` / `Prefs.kt` | Modelo de ajustes, gestos, guardado y copia de seguridad. |
| `Data.kt` | Apps, iconos, atajos, launcher predeterminado y acciones del sistema. |
| `Search.kt` | Búsqueda sin tildes e índice alfabético (con tests). |
| `LockService.kt` | Servicio de accesibilidad opcional para bloquear la pantalla. |

Antes de publicar, cambiá `REPO_URL` en `Settings.kt` por la dirección de tu repositorio (se muestra en *Ajustes > Acerca de*) y, si querés distribuirlo, el `applicationId` (`com.example.minlauncher` no se acepta en Google Play).

## Lo que todavía no tiene

- Widgets de Android (los de otras apps), carpetas, paquetes de iconos e insignias de notificaciones.
- Traducciones: los textos de la interfaz están en español dentro del código; el siguiente paso sería pasarlos a `strings.xml`.

Si querés sumar alguna, ¡las contribuciones son bienvenidas!

## Contribuir

Leé [CONTRIBUTING.md](CONTRIBUTING.md). Los cambios se registran en [CHANGELOG.md](CHANGELOG.md).

## Licencia

[MIT](LICENSE).
