# MinLauncher

Launcher minimalista y oscuro para Android (Kotlin + Jetpack Compose). Gratis y de código abierto (MIT), sin anuncios ni rastreo.

## Qué trae
- Inicio con reloj fino, fecha y apps favoritas (editables, ordenables y renombrables)
- Cajón de apps en grilla vertical con buscador, índice A–Z y búsqueda web si no hay resultados
- Iconos temáticos (estilo One UI) con tamaño y forma a elección (squircle, círculo, redondeado, cuadrado)
- Colores de acento y fondo oscurecible
- Apps ocultas, atajos de app (mantener apretada), renombrar, info y desinstalar
- Gestos: deslizar arriba (cajón), abajo (notificaciones), doble toque (bloquear), mantener apretado (editar)
- Funciona en vertical y horizontal

## Compilar sin PC
Subí este proyecto a GitHub y corré el workflow **Build APK** (pestaña Actions). El APK queda en los artefactos.

## Licencia
MIT
