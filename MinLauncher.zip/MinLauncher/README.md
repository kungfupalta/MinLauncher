# MinLauncher

Un launcher para Android **minimalista, gratuito y de código abierto**. Sin publicidad, sin rastreo y **sin permiso de internet**: todo queda en tu teléfono.

*English: a minimalist, free and open-source Android launcher. No ads, no tracking, no internet permission. See [Build](#compilar) and [Contributing](CONTRIBUTING.md).*

## Funciones

Con el aspecto de One UI (tarjetas redondeadas, cuadrícula con barra inferior, colores suaves), pero todo configurable.

**Inicio (estilo One UI)**
- **Cuadrícula de apps con páginas**, puntos de página y **barra inferior** (dock). Elegís columnas, filas, márgenes, nombres y tamaño de iconos.
- **Mantené apretada una app para moverla** y soltala donde quieras: en otra celda (se intercambian), en la barra inferior, arrastrala a un costado para pasar de página (al borde de la última se crea una nueva) o arriba, en *Quitar*, para sacarla del inicio. Sin moverla, abre su menú.
- La **lista de texto** sigue disponible, pero como opción (Ajustes > Pantalla de inicio > Estilo de las apps).
- Reloj grande que se **agranda o achica pellizcando con dos dedos**. Elegís grosor, color, tipografía, formato 12 h / 24 h y si las horas y los minutos van en una o dos líneas.
- Debajo de la hora: fecha en cuatro formatos, porcentaje de batería y próxima alarma, cada uno opcional.
- **Horas de otras personas, chiquitas debajo del reloj**: Hora Arianna (Ecuador) y Hora Marcos (Argentina). Cada una se activa por separado, también se agranda o achica pellizcándola y se quita manteniéndola apretada.
- Barra de búsqueda opcional y opción de **bloquear el diseño** para no mover nada sin querer.
- Fondo de pantalla visible con velo regulable (hasta negro puro para ahorrar batería en pantallas AMOLED).

**Cajón de apps**
- Búsqueda que ignora tildes (`camara` encuentra *Cámara*), por varias palabras y por iniciales (`gm` encuentra *Google Maps*). Si no hay resultados, ofrece buscar en la web (DuckDuckGo).
- Vista en cuadrícula (columnas automáticas o fijas) o lista, tamaño de los nombres, opacidad del fondo y buscador arriba o abajo.
- Índice alfabético, fila de **más usadas** (el conteo queda solo en tu teléfono) y apps ocultas.
- Atajos de cada app (como "Nuevo mensaje") al mantener apretada, info de la app y desinstalar.

**Personalización**
- Tema oscuro, claro o del sistema, y color de acento: 7 colores, **Material You** o uno **personalizado** con rojo, verde y azul.
- Iconos con forma elegible (squircle, círculo, redondeado, cuadrado), tamaño ajustable e **iconos temáticos**.
- **Gestos configurables**: deslizar arriba / abajo / izquierda / derecha, doble toque y mantener apretado. Cada uno puede abrir el cajón, las notificaciones, bloquear la pantalla, los ajustes o cualquier app.
- Orientación fija o automática, animaciones activables y barra de estado oculta.
- Copia de seguridad: exportá e importá todos tus ajustes en un archivo JSON, o restablecé todo a los valores de fábrica.

**Primera vez**
- Una guía de bienvenida te ayuda a dejarlo como **launcher predeterminado** (con el aviso oficial de Android) y a elegir tema, colores, reloj, apps y gestos desde el principio.

## Instalación

1. Bajá el APK desde la sección *Releases* (o desde la pestaña *Actions* > *Build APK* > artefactos).
2. Permití instalar desde esa fuente si Android lo pide y abrí el APK.
3. Abrí MinLauncher: la guía de bienvenida te lleva a dejarlo como predeterminado. También podés hacerlo en *Ajustes de Android > Apps > Apps predeterminadas > App de inicio*.

Requiere Android 12 o superior (API 31).

## Permisos y privacidad

| Permiso | Para qué |
|---|---|
| `REQUEST_DELETE_PACKAGES` | Desinstalar apps desde el menú del launcher. |
| `EXPAND_STATUS_BAR` | Abrir el panel de notificaciones con un gesto. Usa una API oculta de Android: si tu versión la bloquea, el gesto simplemente no hace nada. |
| Servicio de accesibilidad (opcional) | Solo para el gesto *Bloquear pantalla*. No recibe eventos ni lee la pantalla: ver [`lock_service.xml`](app/src/main/res/xml/lock_service.xml). En Android 13+ puede hacer falta permitir los ajustes restringidos desde *Info de la app*. |

No hay permiso de internet, ni analítica, ni servicios de Google. Más detalle en [PRIVACY.md](PRIVACY.md).

## Compilar

Necesitás JDK 17 y el SDK de Android (compileSdk 36). Lo más simple es abrir la carpeta con **Android Studio**.

Por línea de comandos (el proyecto no incluye el *Gradle wrapper*; usá Gradle 8.11.1 o creá el wrapper una vez con `gradle wrapper --gradle-version 8.11.1`):

```bash
gradle :app:testDebugUnitTest      # tests
gradle :app:assembleRelease        # APK en app/build/outputs/apk/release/
```

GitHub Actions compila y prueba cada push y pull request. Al subir una etiqueta (`git tag v1.1.0 && git push --tags`) publica el APK en *Releases*.

### Firmar con tu propia clave

El APK de `release` se firma con la clave *debug* para poder instalarlo directo. Para publicar de verdad (GitHub Releases, F-Droid) creá tu propio *keystore*, agregá una `signingConfig` en `app/build.gradle.kts` leyendo las contraseñas de variables de entorno, y **nunca subas el `.jks` al repositorio** (ya está en `.gitignore`).

## Estructura del código

| Archivo | Qué hay |
|---|---|
| `MainActivity.kt` | Actividad HOME, avisos de "Inicio" y de vuelta a primer plano. |
| `Ui.kt` | Raíz, inicio (cuadrícula y lista), reloj y cajón de apps. |
| `Sheets.kt` | Menú de cada app, editor del inicio, selector de apps, renombrar. |
| `SettingsScreen.kt` | Pantalla de ajustes y piezas reutilizables. |
| `Onboarding.kt` | Guía de bienvenida de primera vez. |
| `Workspace.kt` | El inicio con cuadrícula: páginas, barra inferior y arrastrar y soltar. |
| `Layout.kt` | El orden de las apps (páginas, celdas, barra inferior). Lógica pura, con tests. |
| `Gestures.kt` / `Pinch.kt` | Deslizar arriba/abajo y pellizcar con dos dedos. |
| `Widgets.kt` | Horas chiquitas debajo del reloj. Para cambiar nombres o zonas horarias, o sumar otra, editá `WorldClockEntries`. |
| `Theme.kt` | Paletas oscura/clara, color de acento, barras del sistema. |
| `Settings.kt` / `Prefs.kt` | Modelo de ajustes, gestos, guardado y copia de seguridad. |
| `Data.kt` | Apps, iconos, atajos, launcher predeterminado y acciones del sistema. |
| `Search.kt` | Búsqueda sin tildes e índice alfabético (con tests). |
| `LockService.kt` | Servicio de accesibilidad opcional para bloquear la pantalla. |

Antes de publicar, cambiá `REPO_URL` en `Settings.kt` por la dirección de tu repositorio (se muestra en *Ajustes > Acerca de*) y, si querés distribuirlo, el `applicationId` (`com.example.minlauncher` no se acepta en Google Play).

## Lo que todavía no tiene

- Widgets de Android (los de otras apps), carpetas, arrastrar apps desde el cajón al inicio (por ahora se agregan con *Agregar a inicio*), paquetes de iconos e insignias de notificaciones.
- Traducciones: los textos de la interfaz están en español dentro del código; el siguiente paso sería pasarlos a `strings.xml`.

Si querés sumar alguna, ¡las contribuciones son bienvenidas!

## Contribuir

Leé [CONTRIBUTING.md](CONTRIBUTING.md). Los cambios se registran en [CHANGELOG.md](CHANGELOG.md).

## Licencia

[MIT](LICENSE).
