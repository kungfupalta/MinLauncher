package com.example.minlauncher

import kotlin.math.floor

/** Valor de `page` para las apps de la barra inferior (dock): ahí `col` es el lugar de la barra. */
const val DOCK = -1
const val MAX_PAGES = 8

/** Una app puesta en un lugar del inicio. */
data class Placed(val pkg: String, val page: Int, val col: Int, val row: Int)

/**
 * Cómo están ordenadas tus apps en el inicio: páginas con una cuadrícula y una barra inferior.
 * Es todo lógica pura (sin Android), así se puede probar con tests.
 */
data class HomeLayout(val items: List<Placed> = emptyList(), val pageCount: Int = 1) {

    fun find(pkg: String): Placed? = items.firstOrNull { it.pkg == pkg }

    fun contains(pkg: String): Boolean = items.any { it.pkg == pkg }

    fun itemAt(page: Int, col: Int, row: Int): Placed? =
        items.firstOrNull { it.page == page && it.col == col && it.row == row }

    fun remove(pkg: String): HomeLayout = copy(items = items.filter { it.pkg != pkg })

    /**
     * Pone una app en un lugar. Si ahí había otra, se intercambian (la otra va al lugar que dejó libre).
     * Si la app es nueva en el inicio y el lugar estaba ocupado, la que estaba va al primer hueco libre.
     */
    fun move(pkg: String, page: Int, col: Int, row: Int, cols: Int, rows: Int): HomeLayout {
        val src = find(pkg)
        val occ = itemAt(page, col, row)
        if (occ?.pkg == pkg) return this
        var result = copy(
            items = items.filter { it.pkg != pkg && it.pkg != occ?.pkg } + Placed(pkg, page, col, row),
            pageCount = maxOf(pageCount, page + 1),
        )
        if (occ != null) {
            result = if (src != null) {
                result.copy(items = result.items + Placed(occ.pkg, src.page, src.col, src.row))
            } else {
                result.add(occ.pkg, cols, rows)
            }
        }
        return result
    }

    /** Agrega una app en el primer hueco libre de la cuadrícula (crea una página si no queda lugar). */
    fun add(pkg: String, cols: Int, rows: Int): HomeLayout {
        if (contains(pkg)) return this
        for (p in 0 until pageCount) {
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (itemAt(p, c, r) == null) return copy(items = items + Placed(pkg, p, c, r))
                }
            }
        }
        if (pageCount >= MAX_PAGES) return this
        return copy(items = items + Placed(pkg, pageCount, 0, 0), pageCount = pageCount + 1)
    }

    /** Saca las apps que ya no están instaladas. */
    fun dropMissing(installed: Set<String>): HomeLayout =
        if (items.all { it.pkg in installed }) this else copy(items = items.filter { it.pkg in installed })

    /** Quita las páginas vacías del final (siempre queda al menos una). */
    fun pruned(): HomeLayout {
        val used = items.filter { it.page >= 0 }.maxOfOrNull { it.page } ?: 0
        return if (pageCount == used + 1) this else copy(pageCount = used + 1)
    }

    /** Reacomoda lo que quedó fuera de lugar cuando cambia el tamaño de la cuadrícula o de la barra. */
    fun reflow(cols: Int, rows: Int, dockCount: Int): HomeLayout {
        val (ok, bad) = items.partition {
            if (it.page == DOCK) it.col < dockCount else it.col < cols && it.row < rows
        }
        if (bad.isEmpty()) return this
        var l = copy(items = ok)
        bad.forEach { l = l.add(it.pkg, cols, rows) }
        return l.pruned()
    }

    fun encode(): String =
        pageCount.toString() + "|" + items.joinToString(";") { "${it.pkg},${it.page},${it.col},${it.row}" }

    companion object {
        /** Arma un inicio desde una lista: las primeras van a la barra inferior y el resto a la cuadrícula. */
        fun fromOrder(pkgs: List<String>, cols: Int, rows: Int, dockCount: Int): HomeLayout {
            var l = HomeLayout()
            pkgs.distinct().forEachIndexed { i, pkg ->
                l = if (i < dockCount) l.copy(items = l.items + Placed(pkg, DOCK, i, 0)) else l.add(pkg, cols, rows)
            }
            return l
        }

        fun decode(text: String): HomeLayout? = try {
            val count = text.substringBefore('|').toInt()
            val body = text.substringAfter('|', "")
            val items = if (body.isEmpty()) {
                emptyList()
            } else {
                body.split(';').map { part ->
                    val f = part.split(',')
                    Placed(f[0], f[1].toInt(), f[2].toInt(), f[3].toInt())
                }
            }
            HomeLayout(items, count.coerceIn(1, MAX_PAGES))
        } catch (_: Exception) {
            null
        }
    }
}

/** Dónde cae algo que se suelta. `remove` = la zona de "Quitar". */
data class DropTarget(val page: Int, val col: Int, val row: Int, val remove: Boolean = false)

/** Medidas (en píxeles) del inicio, para saber qué hay bajo el dedo. */
data class Geo(
    val cols: Int,
    val rows: Int,
    val dockCount: Int,
    val showDock: Boolean,
    val widthPx: Float,
    val sidePx: Float,
    val topPx: Float,
    val cellW: Float,
    val cellH: Float,
    val gridH: Float,
    val dockTop: Float,
    val dockH: Float,
    val slotW: Float,
    val removeH: Float,
) {
    /**
     * Celda o lugar de la barra que está en (x, y). Con `clamp = false` devuelve null si no hay nada ahí;
     * con `clamp = true` (al soltar) devuelve siempre el lugar más cercano, o la zona de quitar.
     */
    fun targetAt(x: Float, y: Float, page: Int, clamp: Boolean): DropTarget? {
        if (clamp && y < removeH) return DropTarget(page, 0, 0, remove = true)
        if (showDock && y >= dockTop) {
            val s = floor((x - sidePx) / slotW).toInt()
            return if (clamp) DropTarget(DOCK, s.coerceIn(0, dockCount - 1), 0)
            else if (s in 0 until dockCount) DropTarget(DOCK, s, 0)
            else null
        }
        val c = floor((x - sidePx) / cellW).toInt()
        val r = floor((y - topPx) / cellH).toInt()
        if (clamp) return DropTarget(page, c.coerceIn(0, cols - 1), r.coerceIn(0, rows - 1))
        return if (c in 0 until cols && r in 0 until rows) DropTarget(page, c, r) else null
    }
}
