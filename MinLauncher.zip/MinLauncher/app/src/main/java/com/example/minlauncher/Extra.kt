package com.example.minlauncher

import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.floor
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------
// Animación al apretar
// ---------------------------------------------------------------------------

/** Click + mantener apretado, con un rebote suave al presionar. */
@Composable
fun Modifier.pressable(onClick: () -> Unit, onLongClick: (() -> Unit)? = null): Modifier {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.90f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 500f),
        label = "press",
    )
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLongClick)
    val hasLong = onLongClick != null
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .pointerInput(hasLong) {
            val lp: ((Offset) -> Unit)? = if (hasLong) ({ _: Offset -> long?.invoke() }) else null
            detectTapGestures(
                onPress = {
                    pressed = true
                    tryAwaitRelease()
                    pressed = false
                },
                onTap = { click() },
                onLongPress = lp,
            )
        }
}

// ---------------------------------------------------------------------------
// Calculadora del buscador
// ---------------------------------------------------------------------------

private class MathParser(private val s: String) {
    private var pos = 0

    private fun peek(): Char? = if (pos < s.length) s[pos] else null

    fun parse(): Double? = try {
        val v = expr()
        if (pos != s.length || v.isNaN() || v.isInfinite()) null else v
    } catch (_: Exception) {
        null
    }

    private fun expr(): Double {
        var v = term()
        while (true) {
            val c = peek()
            if (c == '+') {
                pos++
                v += term()
            } else if (c == '-') {
                pos++
                v -= term()
            } else {
                return v
            }
        }
    }

    private fun term(): Double {
        var v = power()
        while (true) {
            val c = peek()
            if (c == '*') {
                pos++
                v *= power()
            } else if (c == '/') {
                pos++
                v /= power()
            } else {
                return v
            }
        }
    }

    private fun power(): Double {
        val b = unary()
        return if (peek() == '^') {
            pos++
            Math.pow(b, power())
        } else {
            b
        }
    }

    private fun unary(): Double {
        val c = peek()
        return if (c == '-') {
            pos++
            -unary()
        } else if (c == '+') {
            pos++
            unary()
        } else {
            atom()
        }
    }

    private fun atom(): Double {
        if (peek() == '(') {
            pos++
            val v = expr()
            if (peek() != ')') throw IllegalArgumentException("falta )")
            pos++
            return v
        }
        val start = pos
        while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("número")
        return s.substring(start, pos).toDouble()
    }
}

fun evalMath(src: String): Double? {
    val s = src
        .replace(" ", "")
        .replace(',', '.')
        .replace('x', '*')
        .replace('×', '*')
        .replace('÷', '/')
    if (s.isEmpty() || !s.any { it.isDigit() }) return null
    if (s.any { !(it.isDigit() || it in "+-*/().^") }) return null
    return MathParser(s).parse()
}

fun formatResult(v: Double): String {
    if (v == floor(v) && Math.abs(v) < 1e15) return v.toLong().toString()
    return String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
}

// ---------------------------------------------------------------------------
// Piezas reutilizables de ajustes
// ---------------------------------------------------------------------------

@Composable
internal fun <T> ChipRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
) {
    val accent = LocalAccent.current
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { o ->
            val sel = o == selected
            Text(
                label(o),
                color = if (sel) OnAccent else Ink,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (sel) accent else CardHi)
                    .clickable { onSelect(o) }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
internal fun PermissionRow(
    title: String,
    subtitle: String,
    granted: Boolean,
    buttonText: String,
    onClick: () -> Unit,
) {
    val accent = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            Text(subtitle, color = Dim, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(12.dp))
        if (granted) {
            Box(
                Modifier.size(32.dp).clip(CircleShape).background(accent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.Check, null, tint = OnAccent, modifier = Modifier.size(18.dp))
            }
        } else {
            Text(
                buttonText,
                color = OnAccent,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(accent)
                    .clickable(onClick = onClick)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
internal fun GestureRow(title: String, current: GestureAction, onPick: (GestureAction) -> Unit) {
    val accent = LocalAccent.current
    var open by remember { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { open = true }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text(current.label, color = accent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }

    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            containerColor = Card,
            title = { Text(title, color = Ink, fontWeight = FontWeight.Light) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    GestureAction.values().forEach { a ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onPick(a); open = false }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                a.label,
                                color = if (a == current) accent else Ink,
                                fontSize = 16.sp,
                                modifier = Modifier.weight(1f),
                            )
                            if (a == current) {
                                Icon(Icons.Default.Check, null, tint = accent, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancelar", color = Dim) } },
        )
    }
}

// ---- Secciones (se usan en Ajustes y en el asistente) ---------------------

@Composable
internal fun IconsSettings(
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    cfg: LauncherConfig,
    onCfgChange: (LauncherConfig) -> Unit,
) {
    SliderRow("Tamaño", "${style.sizeDp}", style.sizeDp.toFloat(), 44f..88f) {
        onStyleChange(style.copy(sizeDp = it.roundToInt()))
    }
    Spacer(Modifier.height(6.dp))
    Text("Forma", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    ChipRow(IconShape.values().toList(), style.shape, { it.label }) {
        onStyleChange(style.copy(shape = it))
    }
    Spacer(Modifier.height(10.dp))
    SwitchRow(
        title = "Iconos temáticos",
        subtitle = "Color liso con el símbolo oscuro, como One UI",
        checked = style.themed,
        onChange = { onStyleChange(style.copy(themed = it)) },
    )
    SwitchRow(
        title = "Mostrar nombres",
        subtitle = "Debajo de cada icono",
        checked = cfg.showLabels,
        onChange = { onCfgChange(cfg.copy(showLabels = it)) },
    )
}

@Composable
internal fun ColorSettings(
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    cfg: LauncherConfig,
    onCfgChange: (LauncherConfig) -> Unit,
) {
    val custom = style.palette >= Palettes.size
    Text("Color de acento", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Palettes.forEachIndexed { i, p ->
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(p.accent))
                    .clickable { onStyleChange(style.copy(palette = i)) },
                contentAlignment = Alignment.Center,
            ) {
                if (i == style.palette) {
                    Icon(Icons.Default.Check, null, tint = OnAccent, modifier = Modifier.size(22.dp))
                }
            }
        }
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)
                    )
                )
                .clickable { onStyleChange(style.copy(palette = Palettes.size)) },
            contentAlignment = Alignment.Center,
        ) {
            if (custom) {
                Icon(Icons.Default.Check, null, tint = Color.Black, modifier = Modifier.size(22.dp))
            }
        }
    }
    if (custom) {
        Spacer(Modifier.height(8.dp))
        SliderRow("Tono personalizado", "${style.hue.roundToInt()}°", style.hue, 0f..359f) {
            onStyleChange(style.copy(hue = it))
        }
    }

    Spacer(Modifier.height(14.dp))
    Text("Fondo", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    ChipRow(BgStyle.values().toList(), cfg.bgStyle, { it.label }) {
        onCfgChange(cfg.copy(bgStyle = it))
    }
    if (cfg.bgStyle == BgStyle.Wallpaper) {
        Spacer(Modifier.height(8.dp))
        SliderRow("Oscurecer el fondo", "${(cfg.dim * 100).roundToInt()}%", cfg.dim, 0f..0.95f) {
            onCfgChange(cfg.copy(dim = it))
        }
    }
}

@Composable
internal fun HomeSettings(cfg: LauncherConfig, onCfgChange: (LauncherConfig) -> Unit) {
    Text("Estilo del inicio", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    ChipRow(HomeStyle.values().toList(), cfg.homeStyle, { it.label }) {
        onCfgChange(cfg.copy(homeStyle = it))
    }
    Spacer(Modifier.height(14.dp))
    Text("Tipo de reloj", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    ChipRow(ClockStyle.values().toList(), cfg.clockStyle, { it.label }) {
        onCfgChange(cfg.copy(clockStyle = it))
    }
    Spacer(Modifier.height(8.dp))
    SliderRow("Tamaño del reloj", "${cfg.clockSize}", cfg.clockSize.toFloat(), 56f..120f) {
        onCfgChange(cfg.copy(clockSize = it.roundToInt()))
    }
    SwitchRow(
        title = "Mostrar la fecha",
        checked = cfg.showDate,
        onChange = { onCfgChange(cfg.copy(showDate = it)) },
    )
    Text(
        "Tocá la hora para abrir el reloj y la fecha para abrir el calendario.",
        color = Dim,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        modifier = Modifier.padding(top = 4.dp),
    )
}

@Composable
internal fun GestureSettings(cfg: LauncherConfig, onCfgChange: (LauncherConfig) -> Unit) {
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    val accessible = remember(tick) { LockService.instance != null }
    val usesLock = listOf(
        cfg.gestureUp, cfg.gestureDown, cfg.gestureLeft, cfg.gestureRight, cfg.gestureDoubleTap
    ).any { it == GestureAction.Lock }

    GestureRow("Deslizar hacia arriba", cfg.gestureUp) { onCfgChange(cfg.copy(gestureUp = it)) }
    GestureRow("Deslizar hacia abajo", cfg.gestureDown) { onCfgChange(cfg.copy(gestureDown = it)) }
    GestureRow("Deslizar a la izquierda", cfg.gestureLeft) { onCfgChange(cfg.copy(gestureLeft = it)) }
    GestureRow("Deslizar a la derecha", cfg.gestureRight) { onCfgChange(cfg.copy(gestureRight = it)) }
    GestureRow("Doble toque", cfg.gestureDoubleTap) { onCfgChange(cfg.copy(gestureDoubleTap = it)) }
    Text(
        "Mantener apretado en el inicio siempre abre el editor.",
        color = Dim,
        fontSize = 12.sp,
        modifier = Modifier.padding(top = 4.dp),
    )
    if (usesLock) {
        Spacer(Modifier.height(6.dp))
        PermissionRow(
            title = "Accesibilidad (para bloquear)",
            subtitle = "Activá «MinLauncher» en la lista. Solo se usa para bloquear.",
            granted = accessible,
            buttonText = "Activar",
            onClick = { openAccessibilitySettings(ctx) },
        )
    }

    Spacer(Modifier.height(14.dp))
    Text("Animación del cajón", fontSize = 16.sp)
    Spacer(Modifier.height(10.dp))
    ChipRow(DrawerAnim.values().toList(), cfg.drawerAnim, { it.label }) {
        onCfgChange(cfg.copy(drawerAnim = it))
    }
    Spacer(Modifier.height(8.dp))
    SwitchRow(
        title = "Abrir al quedar una sola app",
        subtitle = "En el buscador, abre la app cuando solo hay una coincidencia",
        checked = cfg.autoLaunch,
        onChange = { onCfgChange(cfg.copy(autoLaunch = it)) },
    )
}

// ---------------------------------------------------------------------------
// Asistente de configuración (primera vez)
// ---------------------------------------------------------------------------

@Composable
private fun WizardCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        content = content,
    )
}

@Composable
fun SetupWizard(
    apps: List<AppInfo>,
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    cfg: LauncherConfig,
    onCfgChange: (LauncherConfig) -> Unit,
    onFinish: () -> Unit,
) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val tick = LocalResumeTick.current
    var step by remember { mutableIntStateOf(0) }
    val last = 5
    val sample = remember(apps) { apps.take(4) }
    val isHome = remember(tick) { isDefaultLauncher(ctx) }

    BackHandler { if (step > 0) step-- }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0C0F))
            .windowInsetsPadding(safeInsets())
            .imePadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            repeat(last + 1) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (i <= step) accent else CardHi),
                )
            }
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .padding(bottom = 16.dp),
        ) {
            val title: String
            val subtitle: String
            when (step) {
                0 -> { title = "Bienvenido a MinLauncher"; subtitle = "Vamos a dejarlo a tu gusto. Son unos pasos cortos y todo se puede cambiar después en Ajustes." }
                1 -> { title = "Iconos"; subtitle = "Elegí el tamaño y la forma. Mirá la vista previa." }
                2 -> { title = "Colores y fondo"; subtitle = "El color de acento tiñe toda la interfaz y los iconos temáticos." }
                3 -> { title = "Pantalla de inicio"; subtitle = "Cómo se ve el reloj y tus apps favoritas." }
                4 -> { title = "Gestos y animaciones"; subtitle = "Qué hace cada deslizamiento. Podés dejarlo en «Nada»." }
                else -> { title = "Último paso"; subtitle = "Dejá a MinLauncher como tu pantalla de inicio." }
            }
            Spacer(Modifier.height(8.dp))
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = Dim, fontSize = 15.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(20.dp))

            if (step == 1 || step == 2) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(Card)
                        .padding(vertical = 18.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    sample.forEach { AppIcon(it, style.sizeDp.coerceAtMost(72).dp) }
                }
                Spacer(Modifier.height(14.dp))
            }

            when (step) {
                0 -> {
                    WizardCard {
                        Text("Lo que vas a poder ajustar:", fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "• Tamaño y forma de los iconos\n• Colores, fondo y tipo de reloj\n• Estilo del inicio (también One UI)\n• Gestos y animaciones",
                            color = Dim,
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                        )
                    }
                }
                1 -> WizardCard { IconsSettings(style, onStyleChange, cfg, onCfgChange) }
                2 -> WizardCard { ColorSettings(style, onStyleChange, cfg, onCfgChange) }
                3 -> WizardCard { HomeSettings(cfg, onCfgChange) }
                4 -> WizardCard { GestureSettings(cfg, onCfgChange) }
                else -> {
                    WizardCard {
                        PermissionRow(
                            title = "Launcher predeterminado",
                            subtitle = "Elegí MinLauncher en la lista de apps de inicio",
                            granted = isHome,
                            buttonText = "Elegir",
                            onClick = { openHomeSettings(ctx) },
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Para volver a este asistente: mantené apretado el inicio → Ajustes del launcher → Repetir asistente.",
                        color = Dim,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (step > 0) {
                TextButton(onClick = { step-- }) { Text("Atrás", color = Dim, fontSize = 16.sp) }
            } else {
                TextButton(onClick = onFinish) { Text("Omitir", color = Dim, fontSize = 16.sp) }
            }
            Spacer(Modifier.weight(1f))
            Text(
                if (step < last) "Siguiente" else "Listo",
                color = OnAccent,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(26.dp))
                    .background(accent)
                    .clickable { if (step < last) step++ else onFinish() }
                    .padding(horizontal = 30.dp, vertical = 14.dp),
            )
        }
    }
}
