package com.example.minlauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private const val LAST_STEP = 5

/**
 * Bienvenida que aparece la primera vez: te guía para dejar MinLauncher como launcher
 * predeterminado y configurarlo a tu gusto antes de empezar. Todo se puede cambiar después en Ajustes.
 */
@Composable
fun Onboarding(
    apps: List<AppInfo>,
    pinned: List<String>,
    onPinned: (List<String>) -> Unit,
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    style: IconStyle,
    onStyle: (IconStyle) -> Unit,
    isDefault: Boolean,
    onSetDefault: () -> Unit,
    onFinish: () -> Unit,
) {
    var step by remember { mutableIntStateOf(0) }

    BackHandler(enabled = step > 0) { step-- }

    Column(
        Modifier
            .fillMaxSize()
            .background(SheetBg)
            .pointerInput(Unit) {} // evita que los toques lleguen al inicio que está detrás
            .windowInsetsPadding(safeInsets())
            .padding(horizontal = 24.dp, vertical = 16.dp),
    ) {
        // Puntitos de progreso + saltar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(LAST_STEP + 1) { i ->
                    Box(
                        Modifier
                            .height(6.dp)
                            .width(if (i == step) 22.dp else 6.dp)
                            .clip(CircleShape)
                            .background(if (i <= step) Accent else CardHi),
                    )
                }
            }
            if (step < LAST_STEP) TextAction("Saltar", onFinish)
        }
        Spacer(Modifier.height(24.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            Crossfade(targetState = step, label = "onboarding") { s ->
                when (s) {
                    0 -> StepWelcome()
                    1 -> StepDefault(isDefault, onSetDefault)
                    2 -> StepLook(apps, settings, onSettings, style, onStyle)
                    3 -> StepHome(settings, onSettings)
                    4 -> StepApps(apps, pinned, settings.maxPinned, onPinned)
                    else -> StepGestures(apps, settings, onSettings)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (step > 0) TextAction("Atrás") { step-- }
            Spacer(Modifier.weight(1f))
            PrimaryButton(if (step == LAST_STEP) "Empezar" else "Siguiente") {
                if (step == LAST_STEP) onFinish() else step++
            }
        }
    }
}

@Composable
private fun StepScaffold(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        StepHeader(title, subtitle)
        content()
    }
}

@Composable
private fun StepHeader(title: String, subtitle: String) {
    Text(title, color = Ink, fontSize = 30.sp, fontWeight = FontWeight.Light, lineHeight = 36.sp)
    Spacer(Modifier.height(8.dp))
    Text(subtitle, color = Dim, fontSize = 15.sp, lineHeight = 22.sp)
    Spacer(Modifier.height(24.dp))
}

@Composable
private fun StepWelcome() {
    StepScaffold(
        "Bienvenido a MinLauncher",
        "Un launcher simple, gratuito y de código abierto. Sin publicidad, sin rastreo y sin internet.",
    ) {
        Text(
            "En un minuto lo dejamos a tu gusto: lo ponés como launcher predeterminado, elegís " +
                "colores, reloj, apps y gestos. Después lo podés cambiar todo desde Ajustes.",
            color = Ink,
            fontSize = 16.sp,
            lineHeight = 24.sp,
        )
    }
}

@Composable
private fun StepDefault(isDefault: Boolean, onSetDefault: () -> Unit) {
    val ctx = LocalContext.current
    StepScaffold(
        "Launcher predeterminado",
        "Para que el botón Inicio abra MinLauncher, Android necesita que lo elijas como app de inicio.",
    ) {
        if (isDefault) {
            Text(
                "Listo, MinLauncher ya es tu launcher predeterminado.",
                color = Accent,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
            )
        } else {
            PrimaryButton("Establecer como predeterminado", Modifier.fillMaxWidth(), onSetDefault)
            Spacer(Modifier.height(8.dp))
            TextAction("Abrir ajustes de Android") { openHomeSettings(ctx) }
            Spacer(Modifier.height(12.dp))
            Text(
                "Si Android no muestra el aviso, elegilo a mano en Ajustes > Apps > Apps predeterminadas > " +
                    "App de inicio. También podés hacerlo más tarde desde los Ajustes de MinLauncher.",
                color = Dim,
                fontSize = 13.sp,
                lineHeight = 19.sp,
            )
        }
    }
}

@Composable
private fun StepLook(
    apps: List<AppInfo>,
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    style: IconStyle,
    onStyle: (IconStyle) -> Unit,
) {
    StepScaffold("Apariencia", "Elegí cómo se ve. Los cambios se aplican en vivo.") {
        Text("Tema", color = Ink, fontSize = 16.sp)
        ChipRow(ThemeMode.entries.map { it.label }, settings.theme.ordinal) {
            onSettings(settings.copy(theme = ThemeMode.entries[it]))
        }
        Spacer(Modifier.height(10.dp))
        Text("Color de acento", color = Ink, fontSize = 16.sp)
        AccentPicker(settings, onSettings)
        Spacer(Modifier.height(10.dp))
        Text("Forma de los iconos", color = Ink, fontSize = 16.sp)
        ChipRow(IconShape.entries.map { it.label }, style.shape.ordinal) {
            onStyle(style.copy(shape = IconShape.entries[it]))
        }
        SwitchRow("Iconos temáticos", "Del color de acento", style.themed) {
            onStyle(style.copy(themed = it))
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .padding(vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            apps.take(4).forEach { AppIcon(it, style.sizeDp.coerceAtMost(72).dp) }
        }
    }
}

@Composable
private fun StepHome(settings: LauncherSettings, onSettings: (LauncherSettings) -> Unit) {
    StepScaffold("Pantalla de inicio", "Qué querés ver al desbloquear el teléfono.") {
        SwitchRow("Mostrar reloj", checked = settings.showClock) { onSettings(settings.copy(showClock = it)) }
        if (settings.showClock) {
            SliderRow("Tamaño del reloj", "${settings.clockSize}", settings.clockSize.toFloat(), 48f..140f) {
                onSettings(settings.copy(clockSize = it.roundToInt()))
            }
            ChipRow(listOf("Hora del sistema", "24 h", "12 h"), settings.clockFormat) {
                onSettings(settings.copy(clockFormat = it))
            }
            SwitchRow("Mostrar fecha", checked = settings.showDate) { onSettings(settings.copy(showDate = it)) }
        }
        SwitchRow(
            "Widget de hora doble",
            "Hora de Arianna (Ecuador) y de Marcos (Argentina)",
            settings.showWorldClocks,
        ) { onSettings(settings.copy(showWorldClocks = it)) }
        Spacer(Modifier.height(8.dp))
        Text("Alineación", color = Ink, fontSize = 16.sp)
        ChipRow(listOf("Izquierda", "Centro"), if (settings.centerHome) 1 else 0) {
            onSettings(settings.copy(centerHome = it == 1))
        }
        SliderRow("Tamaño de las apps", "${settings.homeTextSize}", settings.homeTextSize.toFloat(), 18f..40f) {
            onSettings(settings.copy(homeTextSize = it.roundToInt()))
        }
    }
}

@Composable
private fun StepApps(
    apps: List<AppInfo>,
    pinned: List<String>,
    maxPinned: Int,
    onPinned: (List<String>) -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        StepHeader("Tus apps de inicio", "Tocá las que quieras tener a mano (hasta $maxPinned). Ahora tenés ${pinned.size}.")
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(apps, key = { it.component.flattenToString() }) { app ->
                val selected = app.pkg in pinned
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable {
                            onPinned(
                                if (selected) pinned - app.pkg
                                else (pinned + app.pkg).takeLast(maxPinned)
                            )
                        }
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AppIcon(app, 40.dp)
                    Spacer(Modifier.width(16.dp))
                    Text(app.label, color = Ink, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                    Box(
                        Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(if (selected) Accent else CardHi),
                    )
                }
            }
        }
    }
}

@Composable
private fun StepGestures(
    apps: List<AppInfo>,
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
) {
    StepScaffold("Gestos", "Tocá un gesto para cambiar lo que hace. Hay más en Ajustes.") {
        SettingsCard {
            GestureRow(GestureSlot.SwipeUp, settings, apps, onSettings)
            GestureRow(GestureSlot.SwipeDown, settings, apps, onSettings)
            GestureRow(GestureSlot.DoubleTap, settings, apps, onSettings)
            GestureRow(GestureSlot.LongPress, settings, apps, onSettings)
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Todo listo. Recordá: mantené apretado un espacio vacío del inicio para editar tus apps y abrir Ajustes.",
            color = Dim,
            fontSize = 14.sp,
            lineHeight = 21.sp,
        )
    }
}
