package com.example.minlauncher

import androidx.compose.ui.graphics.Color

/** Datos del proyecto que se muestran en "Acerca de". Cambiá REPO_URL por el de tu repositorio. */
object About {
    const val REPO_URL = "https://github.com/TU-USUARIO/MinLauncher"
    const val LICENSE_NAME = "MIT"
}

enum class ThemeMode(val label: String) {
    System("Sistema"),
    Dark("Oscuro"),
    Light("Claro"),
}

/** `ui` se usa en la interfaz oscura; `iconBg` en la clara y como fondo de los iconos temáticos. */
data class AccentPreset(val name: String, val ui: Color, val iconBg: Color)

val AccentPresets = listOf(
    AccentPreset("Celeste", Color(0xFF72B8EE), Color(0xFF2583CC)),
    AccentPreset("Menta", Color(0xFF7FD6B0), Color(0xFF1F9C6E)),
    AccentPreset("Lavanda", Color(0xFFB9A7F2), Color(0xFF6C54D1)),
    AccentPreset("Rosa", Color(0xFFF2A3C4), Color(0xFFD1467F)),
    AccentPreset("Durazno", Color(0xFFF5B98A), Color(0xFFD9772B)),
    AccentPreset("Coral", Color(0xFFF59A92), Color(0xFFCC3D33)),
    AccentPreset("Limón", Color(0xFFE6D66E), Color(0xFFA68F12)),
)

/** Índice especial: usar los colores del sistema (Material You). */
val AccentSystem: Int get() = AccentPresets.size

// ---- Gestos --------------------------------------------------------------
object Gesture {
    const val NONE = "none"
    const val DRAWER = "drawer"
    const val NOTIFICATIONS = "notifications"
    const val LOCK = "lock"
    const val SETTINGS = "settings"
    const val EDIT = "edit"
    const val APP_PREFIX = "app:"
}

val GestureOptions = listOf(
    Gesture.NONE to "Nada",
    Gesture.DRAWER to "Cajón de apps",
    Gesture.NOTIFICATIONS to "Panel de notificaciones",
    Gesture.LOCK to "Bloquear pantalla",
    Gesture.EDIT to "Editar inicio",
    Gesture.SETTINGS to "Ajustes del launcher",
)

enum class GestureSlot(val key: String, val label: String, val default: String) {
    SwipeUp("g_up", "Deslizar hacia arriba", Gesture.DRAWER),
    SwipeDown("g_down", "Deslizar hacia abajo", Gesture.NOTIFICATIONS),
    SwipeLeft("g_left", "Deslizar a la izquierda", Gesture.NONE),
    SwipeRight("g_right", "Deslizar a la derecha", Gesture.NONE),
    DoubleTap("g_double", "Doble toque", Gesture.NONE),

    /** Siempre abre el editor o los ajustes, así nunca te quedás sin acceso a la configuración. */
    LongPress("g_long", "Mantener apretado", Gesture.EDIT),
}

fun gestureLabel(value: String, apps: List<AppInfo>): String =
    if (value.startsWith(Gesture.APP_PREFIX)) {
        val pkg = value.removePrefix(Gesture.APP_PREFIX)
        "Abrir " + (apps.firstOrNull { it.pkg == pkg }?.label ?: "una app")
    } else {
        GestureOptions.firstOrNull { it.first == value }?.second ?: "Nada"
    }

// ---- Ajustes -------------------------------------------------------------
data class LauncherSettings(
    val theme: ThemeMode = ThemeMode.Dark,
    val accent: Int = 0,
    /** 0 = se ve el fondo de pantalla tal cual, 1 = negro puro (ahorra batería en AMOLED). */
    val dim: Float = 0.62f,
    val showClock: Boolean = true,
    val clockSize: Int = 96,
    /** 0 = según el sistema, 1 = 24 h, 2 = 12 h */
    val clockFormat: Int = 0,
    val showDate: Boolean = true,
    /** Horas chiquitas debajo del reloj: se guardan las claves activas ("arianna", "marcos"). */
    val worldClocks: Set<String> = setOf("arianna", "marcos"),
    val centerHome: Boolean = false,
    val homeTextSize: Int = 28,
    val maxPinned: Int = 7,
    val hideStatusBar: Boolean = false,
    val drawerList: Boolean = false,
    val drawerIndex: Boolean = true,
    val drawerFrequent: Boolean = true,
    val drawerKeyboard: Boolean = false,
    val autoLaunch: Boolean = false,
    val gestures: Map<GestureSlot, String> = GestureSlot.entries.associateWith { it.default },
) {
    fun gesture(slot: GestureSlot): String = gestures[slot] ?: slot.default

    fun withWorldClock(key: String, on: Boolean): LauncherSettings =
        copy(worldClocks = if (on) worldClocks + key else worldClocks - key)
}
