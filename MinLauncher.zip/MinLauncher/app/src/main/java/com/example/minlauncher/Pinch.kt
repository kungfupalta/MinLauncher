package com.example.minlauncher

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged

/**
 * Pellizcar con dos dedos para cambiar el tamaño. Con un solo dedo no hace nada (no consume el
 * toque), así los deslizamientos y toques del inicio siguen funcionando igual.
 *
 * [onZoom] recibe el factor de cada movimiento (1.02 = un poquito más grande) y [onEnd] se llama
 * cuando levantás los dedos, ahí es donde conviene guardar el tamaño.
 */
@Composable
fun Modifier.pinchToResize(onZoom: (Float) -> Unit, onEnd: () -> Unit): Modifier {
    val zoomCallback by rememberUpdatedState(onZoom)
    val endCallback by rememberUpdatedState(onEnd)
    return this.pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            var pinched = false
            do {
                val event = awaitPointerEvent()
                if (event.changes.count { it.pressed } >= 2) {
                    val zoom = event.calculateZoom()
                    if (zoom != 1f) {
                        pinched = true
                        zoomCallback(zoom)
                    }
                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            } while (event.changes.any { it.pressed })
            if (pinched) endCallback()
        }
    }
}
