package com.example.minlauncher

import android.content.pm.ShortcutInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---- Piezas compartidas ---------------------------------------------------
@Composable
internal fun CircleBtn(icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (enabled) CardHi else Color.Transparent)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, null,
            tint = if (enabled) Ink else Dim.copy(alpha = 0.3f),
            modifier = Modifier.size(20.dp),
        )
    }
}

@Composable
private fun SheetAction(
    icon: ImageVector,
    text: String,
    circle: Color,
    iconTint: Color,
    textColor: Color,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(circle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Text(text, color = textColor, fontSize = 17.sp)
    }
}

@Composable
private fun ShortcutRow(text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
        Spacer(Modifier.width(16.dp))
        Text(text, color = Ink, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---- Menú de app (mantener apretada) -----------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(
    app: AppInfo,
    isPinned: Boolean,
    layoutLocked: Boolean,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
    onShortcut: (ShortcutInfo) -> Unit,
) {
    val ctx = LocalContext.current
    // Los atajos de la app (por ejemplo "Nuevo mensaje") solo se pueden leer siendo el launcher predeterminado
    val shortcuts by produceState(emptyList<ShortcutInfo>(), app.pkg) {
        value = withContext(Dispatchers.IO) { loadShortcuts(ctx, app) }
    }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Row(
                Modifier.padding(start = 4.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppIcon(app, 48.dp)
                Spacer(Modifier.width(14.dp))
                Text(app.label, fontSize = 22.sp, fontWeight = FontWeight.Light)
            }
            if (shortcuts.isNotEmpty()) {
                shortcuts.forEach { s ->
                    ShortcutRow(s.shortLabel?.toString() ?: s.id) { onShortcut(s) }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (!layoutLocked) {
                SheetAction(
                    Icons.Default.Star,
                    if (isPinned) "Quitar de inicio" else "Agregar a inicio",
                    Accent, OnAccent, Ink, onTogglePin,
                )
            }
            SheetAction(Icons.Default.Edit, "Renombrar", CardHi, Ink, Ink, onRename)
            SheetAction(Icons.Default.Close, "Ocultar del cajón", CardHi, Ink, Ink, onHide)
            SheetAction(Icons.Default.Info, "Info de la app", CardHi, Ink, Ink, onInfo)
            SheetAction(
                Icons.Default.Delete, "Desinstalar",
                Color(0xFF4A2626), Color(0xFFFF8A80), Color(0xFFFF8A80), onUninstall,
            )
        }
    }
}

// ---- Renombrar ----------------------------------------------------------
@Composable
fun RenameDialog(app: AppInfo, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(app.label) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Renombrar", color = Ink, fontWeight = FontWeight.Light) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text(app.original, color = Dim) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Ink,
                        unfocusedTextColor = Ink,
                        cursorColor = Accent,
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Dim.copy(alpha = 0.4f),
                    ),
                )
                Text(
                    "Dejalo vacío para volver al nombre original",
                    color = Dim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Guardar", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = Dim) } },
    )
}

// ---- Editor del inicio --------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeEditor(
    apps: List<AppInfo>,
    pinned: List<String>,
    maxPinned: Int,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onSettings: () -> Unit,
    onWallpaper: () -> Unit,
    onDismiss: () -> Unit,
) {
    // 0 = lista, 1 = agregar app
    var mode by remember { mutableIntStateOf(0) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        if (mode == 1) {
            AppPicker(
                apps = apps,
                exclude = pinned.toSet(),
                title = "Agregar app",
                onBack = { mode = 0 },
                onPick = { onPinnedChange(pinned + it.pkg); mode = 0 },
            )
        } else {
            EditList(
                apps = apps,
                pinned = pinned,
                maxPinned = maxPinned,
                onPinnedChange = onPinnedChange,
                onRename = onRename,
                onAdd = { mode = 1 },
                onSettings = onSettings,
                onWallpaper = onWallpaper,
                onDone = onDismiss,
            )
        }
    }
}

@Composable
private fun MenuRow(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(CardHi),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = Ink, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Text(text, color = Ink, fontSize = 17.sp)
    }
}

@Composable
private fun EditList(
    apps: List<AppInfo>,
    pinned: List<String>,
    maxPinned: Int,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onAdd: () -> Unit,
    onSettings: () -> Unit,
    onWallpaper: () -> Unit,
    onDone: () -> Unit,
) {
    // Solo los paquetes que siguen instalados
    val list = pinned.filter { p -> apps.any { it.pkg == p } }
    val canAdd = list.size < maxPinned

    fun move(i: Int, j: Int) {
        val m = list.toMutableList()
        java.util.Collections.swap(m, i, j)
        onPinnedChange(m)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
    ) {
        Text("Editar inicio", fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(
            "Tocá un nombre para renombrarlo",
            color = Dim,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp),
        )

        list.forEachIndexed { index, pkg ->
            val app = apps.first { it.pkg == pkg }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Card)
                    .padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    app.label,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onRename(app) }
                        .padding(vertical = 10.dp),
                )
                CircleBtn(Icons.Default.KeyboardArrowUp, enabled = index > 0) { move(index, index - 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.KeyboardArrowDown, enabled = index < list.lastIndex) { move(index, index + 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.Close) { onPinnedChange(list - pkg) }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(if (canAdd) Accent else Card)
                .then(if (canAdd) Modifier.clickable(onClick = onAdd) else Modifier)
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Add, null, tint = if (canAdd) OnAccent else Dim, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(
                if (canAdd) "Agregar app" else "Máximo $maxPinned apps (se cambia en Ajustes)",
                color = if (canAdd) OnAccent else Dim,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
            )
        }

        Spacer(Modifier.height(8.dp))
        MenuRow(Icons.Default.Settings, "Ajustes", onSettings)
        Spacer(Modifier.height(8.dp))
        MenuRow(Icons.Default.Edit, "Cambiar fondo de pantalla", onWallpaper)

        Spacer(Modifier.height(8.dp))
        Text(
            "Listo",
            color = Accent,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onDone)
                .padding(horizontal = 24.dp, vertical = 12.dp),
        )
    }
}

/** Lista con buscador para elegir una app. Se usa para agregar al inicio y para los gestos. */
@Composable
fun AppPicker(
    apps: List<AppInfo>,
    exclude: Set<String>,
    title: String,
    onBack: (() -> Unit)?,
    onPick: (AppInfo) -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val candidates = remember(apps, exclude, q) {
        apps.filter { it.pkg !in exclude && matchesQuery(it.label, q) }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.88f)
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
                Spacer(Modifier.width(14.dp))
            }
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(14.dp))
        SearchField(q, { q = it }, { candidates.firstOrNull()?.let(onPick) })
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(candidates, key = { it.component.flattenToString() }) { app ->
                AppRow(app, false, onPick, onPick)
            }
        }
    }
}

// ---- Menú del inicio con cuadrícula (mantener apretado un espacio vacío) ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GridHomeMenu(
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    onOpenSettings: () -> Unit,
    onWallpaper: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Text("Pantalla de inicio", fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Text(
                "Mantené apretada una app para moverla. Arrastrala a un costado para cambiar de página " +
                    "o arriba para quitarla del inicio.",
                color = Dim,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 14.dp),
            )
            SettingsCard {
                Text("Columnas", color = Ink, fontSize = 16.sp)
                ChipRow(listOf("3", "4", "5", "6", "7"), settings.gridCols.coerceIn(3, 7) - 3) {
                    onSettings(settings.copy(gridCols = it + 3))
                }
                Text("Filas", color = Ink, fontSize = 16.sp)
                ChipRow(listOf("3", "4", "5", "6", "7", "8", "9"), settings.gridRows.coerceIn(3, 9) - 3) {
                    onSettings(settings.copy(gridRows = it + 3))
                }
                SwitchRow("Barra inferior", checked = settings.homeDock) {
                    onSettings(settings.copy(homeDock = it))
                }
                SwitchRow("Bloquear el diseño", "Evita mover las apps sin querer", settings.lockLayout) {
                    onSettings(settings.copy(lockLayout = it))
                }
            }
            Spacer(Modifier.height(12.dp))
            MenuRow(Icons.Default.Settings, "Ajustes", onOpenSettings)
            Spacer(Modifier.height(8.dp))
            MenuRow(Icons.Default.Edit, "Cambiar fondo de pantalla", onWallpaper)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TextAction("Listo", onDismiss)
            }
        }
    }
}
