package com.example.minlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ---- Paleta (celeste del panel rápido de One UI) -------------------------
val Accent = Color(0xFF72B8EE)
val OnAccent = Color(0xFF0B1D2E)
val Ink = Color(0xFFF2F2F5)
val Dim = Color(0xFF8E8E99)
val Card = Color(0xFF1F2023)
val CardHi = Color(0xFF2C2D31)
val SheetBg = Color(0xFF17181B)

/** true = se ve tu fondo de pantalla oscurecido; false = negro puro (ahorra batería en AMOLED) */
private const val SHOW_WALLPAPER = true
private const val MAX_PINNED = 7

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Color.Black,
            surface = SheetBg,
        ),
        content = content,
    )
}

// ---- Raíz ---------------------------------------------------------------
val LocalIconStyle = compositionLocalOf { IconStyle() }

@Composable
fun safeInsets(): WindowInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)

fun IconShape.composeShape(): Shape = when (this) {
    IconShape.Circle -> CircleShape
    IconShape.Rounded -> RoundedCornerShape(percent = 20)
    IconShape.Square -> RoundedCornerShape(percent = 6)
    IconShape.Squircle -> RoundedCornerShape(percent = 26)
}

@Composable
fun LauncherRoot(homeSignal: Int) {
    val ctx = LocalContext.current
    var style by remember { mutableStateOf(Prefs.getStyle(ctx)) }
    CompositionLocalProvider(LocalIconStyle provides style) {
        LauncherContent(homeSignal, style) {
            style = it
            Prefs.setStyle(ctx, it)
        }
    }
}

@Composable
fun LauncherContent(homeSignal: Int, style: IconStyle, onStyleChange: (IconStyle) -> Unit) {
    val ctx = LocalContext.current
    var rawApps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var pinned by remember { mutableStateOf(Prefs.getPinned(ctx) ?: emptyList()) }
    var labels by remember { mutableStateOf(Prefs.getLabels(ctx)) }
    var drawerOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var editing by remember { mutableStateOf(false) }
    var renameApp by remember { mutableStateOf<AppInfo?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadTick) {
        val loaded = withContext(Dispatchers.IO) { loadApps(ctx) }
        rawApps = loaded
        if (Prefs.getPinned(ctx) == null) {
            pinned = defaultPinned(ctx, loaded).take(4)
            Prefs.setPinned(ctx, pinned)
        }
    }

    // Recargar si se instala / desinstala / actualiza una app
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                i.data?.schemeSpecificPart?.let { IconCache.clear(it) }
                reloadTick++
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    // Botón Home estando en el launcher: volver al inicio
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        menuApp = null
        editing = false
    }

    // Lista con los nombres personalizados aplicados
    val apps = remember(rawApps, labels) {
        rawApps
            .map { it.copy(label = labels[it.pkg] ?: it.original) }
            .sortedBy { it.label.lowercase() }
    }
    val pinnedApps = remember(apps, pinned) {
        pinned.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    }

    fun savePinned(list: List<String>) {
        pinned = list
        Prefs.setPinned(ctx, list)
    }

    fun saveLabel(app: AppInfo, name: String) {
        val n = name.trim()
        labels = if (n.isEmpty() || n == app.original) labels - app.pkg else labels + (app.pkg to n)
        Prefs.setLabels(ctx, labels)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (SHOW_WALLPAPER) Color.Black.copy(alpha = 0.62f) else Color.Black)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -90f) drawerOpen = true },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        HomeScreen(
            pinnedApps = pinnedApps,
            onLaunch = { launchApp(ctx, it) },
            onLongPress = { menuApp = it },
            onEdit = { editing = true },
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut(),
        ) {
            Drawer(
                apps = apps,
                pinned = pinned,
                onClose = { drawerOpen = false },
                onLaunch = { launchApp(ctx, it); drawerOpen = false },
                onLongPress = { menuApp = it },
            )
        }
    }

    menuApp?.let { app ->
        AppSheet(
            app = app,
            isPinned = app.pkg in pinned,
            onDismiss = { menuApp = null },
            onTogglePin = {
                savePinned(
                    if (app.pkg in pinned) pinned - app.pkg
                    else (pinned + app.pkg).takeLast(MAX_PINNED)
                )
                menuApp = null
            },
            onRename = { renameApp = app; menuApp = null },
            onInfo = { openAppInfo(ctx, app); menuApp = null },
            onUninstall = { uninstallApp(ctx, app); menuApp = null },
        )
    }

    if (editing) {
        HomeEditor(
            apps = apps,
            pinned = pinned,
            style = style,
            onStyleChange = onStyleChange,
            onPinnedChange = { savePinned(it) },
            onRename = { renameApp = it },
            onDismiss = { editing = false },
        )
    }

    renameApp?.let { app ->
        RenameDialog(
            app = app,
            onSave = { saveLabel(app, it); renameApp = null },
            onDismiss = { renameApp = null },
        )
    }
}

// ---- Inicio -------------------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedList(
    pinnedApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    if (pinnedApps.isEmpty()) {
        Text(
            "Deslizá hacia arriba para ver tus apps.\nMantené apretado acá para agregar las tuyas.",
            color = Dim,
            fontSize = 14.sp,
            lineHeight = 21.sp,
        )
    } else {
        pinnedApps.forEach { app ->
            Text(
                text = app.label,
                color = Ink,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-0.3).sp,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .combinedClickable(
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                    )
                    .padding(vertical = 9.dp, horizontal = 2.dp),
            )
        }
    }
}

@Composable
fun HomeScreen(
    pinnedApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onEdit: () -> Unit,
) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    if (landscape) {
        Row(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onEdit() }) }
                .padding(horizontal = 40.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                Clock(72.sp)
            }
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    PinnedList(pinnedApps, onLaunch, onLongPress)
                }
            }
        }
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onEdit() }) }
                .padding(horizontal = 32.dp, vertical = 24.dp),
        ) {
            Spacer(Modifier.height(40.dp))
            Clock()
            Spacer(Modifier.weight(1f))
            PinnedList(pinnedApps, onLaunch, onLongPress)
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Dim.copy(alpha = 0.45f)),
            )
        }
    }
}

@Composable
fun Clock(fontSize: TextUnit = 96.sp) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    val time = DateFormat.format(pattern, now).toString()
    val date = DateUtils.formatDateTime(
        ctx, now,
        DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NO_YEAR,
    )

    Column {
        Text(
            text = time,
            color = Ink,
            fontSize = fontSize,
            fontWeight = FontWeight.Thin,
            letterSpacing = (fontSize.value * -0.03f).sp,
            lineHeight = fontSize * 1.04f,
        )
        Text(
            text = date.uppercase(),
            color = Accent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(start = 4.dp),
        )
    }
}

// ---- Cajón de apps ------------------------------------------------------
@Composable
fun SearchField(query: String, onChange: (String) -> Unit, onSearch: () -> Unit) {
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Ink, fontSize = 17.sp),
        cursorBrush = SolidColor(Accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Card)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Search, null, tint = Accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Buscar apps", color = Dim, fontSize = 17.sp)
                    inner()
                }
            }
        },
    )
}

@Composable
fun AppIcon(app: AppInfo, size: Dp) {
    val ctx = LocalContext.current
    val style = LocalIconStyle.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(app, style), app, style) {
        value = IconCache.peek(app, style)
            ?: withContext(Dispatchers.Default) { IconCache.get(ctx, app, style) }
    }
    Box(Modifier.size(size).clip(style.shape.composeShape())) {
        icon?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    pinned: List<String>,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    BackHandler { onClose() }
    val style = LocalIconStyle.current

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2090A0D))
            .windowInsetsPadding(safeInsets())
            .imePadding()
            .padding(horizontal = 12.dp),
    ) {
        LazyVerticalGrid(
            columns = GridCells.Adaptive((style.sizeDp + 22).dp),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(top = 16.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            gridItems(filtered, key = { it.component.flattenToString() }) { app ->
                AppCell(app, onLaunch, onLongPress)
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.padding(horizontal = 8.dp)) {
            SearchField(query, { query = it }, { filtered.firstOrNull()?.let(onLaunch) })
        }
        Spacer(Modifier.height(12.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppInfo,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppIcon(app, LocalIconStyle.current.sizeDp.dp)
        Spacer(Modifier.height(6.dp))
        Text(
            app.label,
            color = Ink,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(
    app: AppInfo,
    isPinned: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(app, 44.dp)
        Spacer(Modifier.width(18.dp))
        Text(
            app.label,
            color = Ink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (isPinned) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
        }
    }
}

// ---- Editor del inicio --------------------------------------------------
@Composable
private fun CircleBtn(icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (enabled) CardHi else Color.Transparent)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, null,
            tint = if (enabled) Ink else Dim.copy(alpha = 0.3f),
            modifier = Modifier.size(20.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeEditor(
    apps: List<AppInfo>,
    pinned: List<String>,
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onDismiss: () -> Unit,
) {
    // 0 = lista, 1 = agregar app, 2 = apariencia
    var mode by remember { mutableIntStateOf(0) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        when (mode) {
            1 -> AddAppList(
                apps = apps,
                pinned = pinned,
                onBack = { mode = 0 },
                onPick = { onPinnedChange(pinned + it.pkg); mode = 0 },
            )
            2 -> StyleSettings(
                apps = apps,
                style = style,
                onChange = onStyleChange,
                onBack = { mode = 0 },
            )
            else -> EditList(
                apps = apps,
                pinned = pinned,
                onPinnedChange = onPinnedChange,
                onRename = onRename,
                onAdd = { mode = 1 },
                onStyle = { mode = 2 },
                onDone = onDismiss,
            )
        }
    }
}

@Composable
private fun StyleSettings(
    apps: List<AppInfo>,
    style: IconStyle,
    onChange: (IconStyle) -> Unit,
    onBack: () -> Unit,
) {
    val sample = apps.take(4)
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
            Spacer(Modifier.width(14.dp))
            Text("Apariencia", fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(16.dp))

        // Vista previa en vivo
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .padding(vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            sample.forEach { AppIcon(it, style.sizeDp.coerceAtMost(72).dp) }
        }

        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Tamaño de los iconos", fontSize = 16.sp)
            Text("${style.sizeDp}", color = Accent, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = style.sizeDp.toFloat(),
            onValueChange = { onChange(style.copy(sizeDp = it.roundToInt())) },
            valueRange = 44f..88f,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = CardHi,
            ),
        )

        Spacer(Modifier.height(10.dp))
        Text("Forma", fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            IconShape.values().forEach { sh ->
                val selected = sh == style.shape
                Text(
                    sh.label,
                    color = if (selected) OnAccent else Ink,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (selected) Accent else Card)
                        .clickable { onChange(style.copy(shape = sh)) }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .clickable { onChange(style.copy(themed = !style.themed)) }
                .padding(start = 18.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Iconos temáticos", fontSize = 17.sp)
                Text("Azules con el símbolo oscuro", color = Dim, fontSize = 12.sp)
            }
            Switch(
                checked = style.themed,
                onCheckedChange = { onChange(style.copy(themed = it)) },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = OnAccent,
                    checkedTrackColor = Accent,
                    uncheckedThumbColor = Dim,
                    uncheckedTrackColor = CardHi,
                    uncheckedBorderColor = Dim,
                ),
            )
        }
    }
}

@Composable
private fun EditList(
    apps: List<AppInfo>,
    pinned: List<String>,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onAdd: () -> Unit,
    onStyle: () -> Unit,
    onDone: () -> Unit,
) {
    // Solo los paquetes que siguen instalados
    val list = pinned.filter { p -> apps.any { it.pkg == p } }
    val canAdd = list.size < MAX_PINNED

    fun move(i: Int, j: Int) {
        val m = list.toMutableList()
        java.util.Collections.swap(m, i, j)
        onPinnedChange(m)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
    ) {
        Text("Editar inicio", fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(
            "Tocá un nombre para renombrarlo",
            color = Dim,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp),
        )

        list.forEachIndexed { index, pkg ->
            val app = apps.first { it.pkg == pkg }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Card)
                    .padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    app.label,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onRename(app) }
                        .padding(vertical = 10.dp),
                )
                CircleBtn(Icons.Default.KeyboardArrowUp, enabled = index > 0) { move(index, index - 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.KeyboardArrowDown, enabled = index < list.lastIndex) { move(index, index + 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.Close) { onPinnedChange(list - pkg) }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(if (canAdd) Accent else Card)
                .then(if (canAdd) Modifier.clickable(onClick = onAdd) else Modifier)
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Add, null, tint = if (canAdd) OnAccent else Dim, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(
                if (canAdd) "Agregar app" else "Máximo $MAX_PINNED apps",
                color = if (canAdd) OnAccent else Dim,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
            )
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .clickable(onClick = onStyle)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(CardHi),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.Settings, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(16.dp))
            Text("Apariencia", fontSize = 17.sp)
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Listo",
            color = Accent,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onDone)
                .padding(horizontal = 24.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun AddAppList(
    apps: List<AppInfo>,
    pinned: List<String>,
    onBack: () -> Unit,
    onPick: (AppInfo) -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val candidates = remember(apps, pinned, q) {
        apps.filter { it.pkg !in pinned && (q.isBlank() || it.label.contains(q.trim(), ignoreCase = true)) }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.88f)
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
            Spacer(Modifier.width(14.dp))
            Text("Agregar app", fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(14.dp))
        SearchField(q, { q = it }, { candidates.firstOrNull()?.let(onPick) })
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(candidates, key = { it.component.flattenToString() }) { app ->
                AppRow(app, false, onPick, onPick)
            }
        }
    }
}

// ---- Renombrar ----------------------------------------------------------
@Composable
fun RenameDialog(app: AppInfo, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(app.label) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Renombrar", color = Ink, fontWeight = FontWeight.Light) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text(app.original, color = Dim) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Ink,
                        unfocusedTextColor = Ink,
                        cursorColor = Accent,
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Dim.copy(alpha = 0.4f),
                    ),
                )
                Text(
                    "Dejalo vacío para volver al nombre original",
                    color = Dim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Guardar", color = Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = Dim) } },
    )
}

// ---- Menú de app (mantener apretada) -----------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(
    app: AppInfo,
    isPinned: Boolean,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Row(
                Modifier.padding(start = 4.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppIcon(app, 48.dp)
                Spacer(Modifier.width(14.dp))
                Text(app.label, fontSize = 22.sp, fontWeight = FontWeight.Light)
            }
            SheetAction(
                Icons.Default.Star,
                if (isPinned) "Quitar de inicio" else "Fijar en inicio",
                Accent, OnAccent, Ink, onTogglePin,
            )
            SheetAction(Icons.Default.Edit, "Renombrar", CardHi, Ink, Ink, onRename)
            SheetAction(Icons.Default.Info, "Info de la app", CardHi, Ink, Ink, onInfo)
            SheetAction(Icons.Default.Delete, "Desinstalar", Color(0xFF4A2626), Color(0xFFFF8A80), Color(0xFFFF8A80), onUninstall)
        }
    }
}

@Composable
private fun SheetAction(
    icon: ImageVector,
    text: String,
    circle: Color,
    iconTint: Color,
    textColor: Color,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(circle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Text(text, color = textColor, fontSize = 17.sp)
    }
}
