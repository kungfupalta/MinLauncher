package com.example.minlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

private const val FREQUENT_COUNT = 4

// ---- Raíz ---------------------------------------------------------------
val LocalIconStyle = compositionLocalOf { IconStyle() }

@Composable
fun safeInsets(): WindowInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)

fun IconShape.composeShape(): Shape = when (this) {
    IconShape.Circle -> CircleShape
    IconShape.Rounded -> RoundedCornerShape(percent = 20)
    IconShape.Square -> RoundedCornerShape(percent = 6)
    IconShape.Squircle -> RoundedCornerShape(percent = 26)
}

@Composable
fun LauncherRoot(homeSignal: Int, resumeTick: Int) {
    val ctx = LocalContext.current
    var settings by remember { mutableStateOf(Prefs.getSettings(ctx)) }
    var baseStyle by remember { mutableStateOf(Prefs.getStyle(ctx)) }

    LauncherTheme(settings) {
        val palette = LocalPalette.current
        val preset = AccentPresets.getOrNull(settings.accent)
        // Los iconos temáticos toman el color de acento elegido
        val style = baseStyle.copy(
            tintBg = (preset?.iconBg ?: palette.accent).toArgb(),
            tintFg = if (preset != null) 0xFF08131F.toInt() else palette.onAccent.toArgb(),
        )
        SystemBarsEffect(palette.dark, settings.hideStatusBar, settings.orientation)
        CompositionLocalProvider(LocalIconStyle provides style) {
            LauncherContent(
                homeSignal = homeSignal,
                resumeTick = resumeTick,
                settings = settings,
                onSettings = { settings = it; Prefs.setSettings(ctx, it) },
                style = baseStyle,
                onStyle = { baseStyle = it; Prefs.setStyle(ctx, it) },
            )
        }
    }
}

@Composable
fun LauncherContent(
    homeSignal: Int,
    resumeTick: Int,
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    style: IconStyle,
    onStyle: (IconStyle) -> Unit,
) {
    val ctx = LocalContext.current
    val palette = LocalPalette.current
    var rawApps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var pinned by remember { mutableStateOf(Prefs.getPinned(ctx) ?: emptyList()) }
    var labels by remember { mutableStateOf(Prefs.getLabels(ctx)) }
    var hidden by remember { mutableStateOf(Prefs.getHidden(ctx)) }
    var layoutState by remember { mutableStateOf(Prefs.getLayout(ctx)) }
    val layout = layoutState ?: HomeLayout()

    fun saveLayout(l: HomeLayout) {
        layoutState = l
        Prefs.setLayout(ctx, l)
    }
    var onboarded by remember { mutableStateOf(Prefs.isOnboarded(ctx)) }
    var drawerOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var editing by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var focusSearch by remember { mutableStateOf(false) }
    var renameApp by remember { mutableStateOf<AppInfo?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    // Se vuelve a comprobar cada vez que la app vuelve a primer plano
    val isDefault = remember(resumeTick) { isDefaultLauncher(ctx) }
    val setDefault = rememberSetDefaultLauncher()

    LaunchedEffect(reloadTick) {
        val loaded = withContext(Dispatchers.IO) { loadApps(ctx) }
        rawApps = loaded
        if (Prefs.getPinned(ctx) == null) {
            pinned = defaultPinned(ctx, loaded).take(4)
            Prefs.setPinned(ctx, pinned)
        }
        val current = layoutState
        if (current == null) {
            // Primera vez con la cuadrícula: se arma con las apps que ya tenías en inicio
            if (Prefs.isOnboarded(ctx)) {
                saveLayout(HomeLayout.fromOrder(pinned, settings.gridCols, settings.gridRows, settings.dockCount))
            }
        } else if (loaded.isNotEmpty()) {
            // Se sacan las apps que se desinstalaron
            val cleaned = current.dropMissing(loaded.map { it.pkg }.toSet())
            if (cleaned != current) saveLayout(cleaned)
        }
    }

    // Si cambia el tamaño de la cuadrícula o de la barra inferior, se reacomodan las apps
    LaunchedEffect(settings.gridCols, settings.gridRows, settings.dockCount) {
        layoutState?.let { saveLayout(it.reflow(settings.gridCols, settings.gridRows, settings.dockCount)) }
    }

    // Recargar si se instala / desinstala / actualiza una app
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                i.data?.schemeSpecificPart?.let { IconCache.clear(it) }
                reloadTick++
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    // Botón Home estando en el launcher: volver al inicio
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        menuApp = null
        editing = false
        showSettings = false
    }

    LaunchedEffect(drawerOpen) { if (!drawerOpen) focusSearch = false }

    // Lista con los nombres personalizados aplicados
    val apps = remember(rawApps, labels) {
        rawApps
            .map { it.copy(label = labels[it.pkg] ?: it.original) }
            .sortedBy { normalize(it.label) }
    }
    val visibleApps = remember(apps, hidden) { apps.filter { it.pkg !in hidden } }
    val pinnedApps = remember(apps, pinned) {
        pinned.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    }

    fun savePinned(list: List<String>) {
        pinned = list
        Prefs.setPinned(ctx, list)
    }

    fun saveHidden(set: Set<String>) {
        hidden = set
        Prefs.setHidden(ctx, set)
    }

    fun saveLabel(app: AppInfo, name: String) {
        val n = name.trim()
        labels = if (n.isEmpty() || n == app.original) labels - app.pkg else labels + (app.pkg to n)
        Prefs.setLabels(ctx, labels)
    }

    fun runGesture(slot: GestureSlot) {
        val action = settings.gesture(slot)
        when {
            action == Gesture.DRAWER -> drawerOpen = true
            action == Gesture.NOTIFICATIONS -> expandNotifications(ctx)
            action == Gesture.LOCK -> lockScreenOrPrompt(ctx)
            action == Gesture.SETTINGS -> showSettings = true
            // Con el diseño bloqueado no se edita el inicio, pero siempre queda el acceso a Ajustes
            action == Gesture.EDIT -> {
                if (settings.lockLayout) showSettings = true else editing = true
            }
            action.startsWith(Gesture.APP_PREFIX) -> {
                val pkg = action.removePrefix(Gesture.APP_PREFIX)
                apps.firstOrNull { it.pkg == pkg }?.let { launchApp(ctx, it) }
            }
        }
    }

    val onHomePkgs = if (settings.homeStyle == 1) pinned else layout.items.map { it.pkg }

    // En el inicio, "atrás" no hace nada (un launcher no se cierra)
    BackHandler { }

    Box(
        Modifier
            .fillMaxSize()
            .background(palette.scrim.copy(alpha = settings.dim.coerceIn(0f, 1f))),
    ) {
        HomeScreen(
            layout = layout,
            onLayout = { saveLayout(it) },
            apps = apps,
            pinnedApps = pinnedApps,
            settings = settings,
            onLaunch = { launchApp(ctx, it) },
            onLongPress = { menuApp = it },
            onGesture = { runGesture(it) },
            onRemoveClock = { key -> onSettings(settings.withWorldClock(key, false)) },
            onResizeClock = { onSettings(settings.copy(clockSize = it)) },
            onResizeSmall = { onSettings(settings.copy(worldClockSize = it)) },
            onOpenSearch = { focusSearch = true; drawerOpen = true },
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = if (settings.animations) slideInVertically { it / 2 } + fadeIn() else EnterTransition.None,
            exit = if (settings.animations) slideOutVertically { it / 2 } + fadeOut() else ExitTransition.None,
        ) {
            Drawer(
                apps = visibleApps,
                pinned = onHomePkgs,
                settings = settings,
                autoFocus = settings.drawerKeyboard || focusSearch,
                onClose = { drawerOpen = false },
                onLaunch = { launchApp(ctx, it); drawerOpen = false },
                onLongPress = { menuApp = it },
                onOpenSettings = { drawerOpen = false; showSettings = true },
            )
        }

        AnimatedVisibility(
            visible = showSettings,
            enter = if (settings.animations) fadeIn() + slideInVertically { it / 12 } else EnterTransition.None,
            exit = if (settings.animations) fadeOut() else ExitTransition.None,
        ) {
            SettingsScreen(
                settings = settings,
                onSettings = onSettings,
                style = style,
                onStyle = onStyle,
                apps = apps,
                hidden = hidden,
                onHidden = { saveHidden(it) },
                isDefault = isDefault,
                onSetDefault = setDefault,
                onBack = { showSettings = false },
            )
        }

        if (!onboarded) {
            Onboarding(
                apps = apps,
                pinned = pinned,
                onPinned = { savePinned(it) },
                settings = settings,
                onSettings = onSettings,
                style = style,
                onStyle = onStyle,
                isDefault = isDefault,
                onSetDefault = setDefault,
                onFinish = {
                    Prefs.setOnboarded(ctx, true)
                    onboarded = true
                    if (layoutState == null || layout.items.isEmpty()) {
                        saveLayout(
                            HomeLayout.fromOrder(pinned, settings.gridCols, settings.gridRows, settings.dockCount)
                        )
                    }
                },
            )
        }
    }

    menuApp?.let { app ->
        AppSheet(
            app = app,
            isPinned = app.pkg in onHomePkgs,
            layoutLocked = settings.lockLayout,
            onDismiss = { menuApp = null },
            onTogglePin = {
                if (settings.homeStyle == 1) {
                    savePinned(
                        if (app.pkg in pinned) pinned - app.pkg
                        else (pinned + app.pkg).takeLast(settings.maxPinned)
                    )
                } else if (layout.contains(app.pkg)) {
                    saveLayout(layout.remove(app.pkg).pruned())
                } else {
                    saveLayout(layout.add(app.pkg, settings.gridCols, settings.gridRows))
                }
                menuApp = null
            },
            onRename = { renameApp = app; menuApp = null },
            onHide = { saveHidden(hidden + app.pkg); menuApp = null },
            onInfo = { openAppInfo(ctx, app); menuApp = null },
            onUninstall = { uninstallApp(ctx, app); menuApp = null },
            onShortcut = { launchShortcut(ctx, it); menuApp = null },
        )
    }

    if (editing) {
        if (settings.homeStyle == 1) {
            HomeEditor(
                apps = apps,
                pinned = pinned,
                maxPinned = settings.maxPinned,
                onPinnedChange = { savePinned(it) },
                onRename = { renameApp = it },
                onSettings = { editing = false; showSettings = true },
                onWallpaper = { editing = false; pickWallpaper(ctx) },
                onDismiss = { editing = false },
            )
        } else {
            GridHomeMenu(
                settings = settings,
                onSettings = onSettings,
                onOpenSettings = { editing = false; showSettings = true },
                onWallpaper = { editing = false; pickWallpaper(ctx) },
                onDismiss = { editing = false },
            )
        }
    }

    renameApp?.let { app ->
        RenameDialog(
            app = app,
            onSave = { saveLabel(app, it); renameApp = null },
            onDismiss = { renameApp = null },
        )
    }
}

// ---- Inicio -------------------------------------------------------------
/** Lista de texto: la opción alternativa a la cuadrícula. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedApps(
    pinnedApps: List<AppInfo>,
    settings: LauncherSettings,
    swipeUpOpensDrawer: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    if (pinnedApps.isEmpty()) {
        val hint = (if (swipeUpOpensDrawer) "Deslizá hacia arriba para ver tus apps.\n" else "") +
            "Mantené apretado acá para elegir tus apps y ajustar el launcher."
        Text(
            hint,
            color = Dim,
            fontSize = 14.sp,
            lineHeight = 21.sp,
            textAlign = if (settings.centerHome) TextAlign.Center else TextAlign.Start,
        )
    } else {
        val family = fontFor(settings.homeFont)
        val weight = weightFor(settings.homeWeight)
        pinnedApps.forEach { app ->
            Row(
                Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .combinedClickable(
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                    )
                    .padding(vertical = 9.dp, horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (settings.homeIcons) {
                    AppIcon(app, (settings.homeTextSize * 1.3f).dp)
                    Spacer(Modifier.width(12.dp))
                }
                Text(
                    text = app.label,
                    color = Ink,
                    fontSize = settings.homeTextSize.sp,
                    fontWeight = weight,
                    fontFamily = family,
                    letterSpacing = (-0.3).sp,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
internal fun HomeSearchBar(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Default.Search, null, tint = Accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text("Buscar apps", color = Dim, fontSize = 17.sp)
    }
}

@Composable
fun HomeScreen(
    layout: HomeLayout,
    onLayout: (HomeLayout) -> Unit,
    apps: List<AppInfo>,
    pinnedApps: List<AppInfo>,
    settings: LauncherSettings,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onGesture: (GestureSlot) -> Unit,
    onRemoveClock: (String) -> Unit,
    onResizeClock: (Int) -> Unit,
    onResizeSmall: (Int) -> Unit,
    onOpenSearch: () -> Unit,
) {
    if (settings.homeStyle == 1) {
        ListHome(
            pinnedApps, settings, onLaunch, onLongPress, onGesture,
            onRemoveClock, onResizeClock, onResizeSmall, onOpenSearch,
        )
    } else {
        GridHome(
            layout, onLayout, apps, settings, onLaunch, onLongPress, onGesture,
            onRemoveClock, onResizeClock, onResizeSmall, onOpenSearch,
        )
    }
}

/** Reloj y horas chiquitas, más abajo la cuadrícula de apps con páginas y barra inferior. */
@Composable
private fun GridHome(
    layout: HomeLayout,
    onLayout: (HomeLayout) -> Unit,
    apps: List<AppInfo>,
    settings: LauncherSettings,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
    onGesture: (GestureSlot) -> Unit,
    onRemoveClock: (String) -> Unit,
    onResizeClock: (Int) -> Unit,
    onResizeSmall: (Int) -> Unit,
    onOpenSearch: () -> Unit,
) {
    val cfg = LocalConfiguration.current
    val landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
    val gesture by rememberUpdatedState(onGesture)
    val center = settings.centerHome
    val align = if (center) Alignment.CenterHorizontally else Alignment.Start

    val availDp = if (landscape) cfg.screenWidthDp * 0.4f - settings.homeMargin * 2f
    else cfg.screenWidthDp - settings.homeMargin * 2f
    val maxClock = (availDp / (if (settings.clockStacked) 1.25f else 2.5f))
        .coerceIn(MIN_CLOCK_SP, MAX_CLOCK_SP)
    val hasHeader = settings.showClock || WorldClockEntries.any { it.key in settings.worldClocks }

    val header: @Composable () -> Unit = {
        Column(
            Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { gesture(GestureSlot.LongPress) })
                }
                .swipeGestures { gesture(it) }
                .padding(start = settings.homeMargin.dp, end = settings.homeMargin.dp, top = 16.dp, bottom = 4.dp),
            horizontalAlignment = align,
        ) {
            if (settings.showClock) Clock(settings, maxClock, align, onResizeClock)
            WorldClocks(settings, align, onRemoveClock, onResizeSmall)
        }
    }

    if (landscape) {
        Row(Modifier.fillMaxSize().windowInsetsPadding(safeInsets())) {
            if (hasHeader) {
                Box(
                    Modifier.weight(0.42f).fillMaxHeight(),
                    contentAlignment = if (center) Alignment.Center else Alignment.CenterStart,
                ) { header() }
            }
            Workspace(
                layout, onLayout, apps, settings, onLaunch, onMenu, onGesture, onOpenSearch,
                Modifier.weight(if (hasHeader) 0.58f else 1f).fillMaxHeight(),
            )
        }
    } else {
        Column(Modifier.fillMaxSize().windowInsetsPadding(safeInsets())) {
            if (hasHeader) header()
            Workspace(
                layout, onLayout, apps, settings, onLaunch, onMenu, onGesture, onOpenSearch,
                Modifier.weight(1f).fillMaxWidth(),
            )
        }
    }
}

/** La vista de lista: reloj arriba y los nombres de tus apps abajo. */
@Composable
private fun ListHome(
    pinnedApps: List<AppInfo>,
    settings: LauncherSettings,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onGesture: (GestureSlot) -> Unit,
    onRemoveClock: (String) -> Unit,
    onResizeClock: (Int) -> Unit,
    onResizeSmall: (Int) -> Unit,
    onOpenSearch: () -> Unit,
) {
    val cfg = LocalConfiguration.current
    val landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
    val gesture by rememberUpdatedState(onGesture)
    val center = settings.centerHome
    val align = if (center) Alignment.CenterHorizontally else Alignment.Start
    val swipeUpIsDrawer = settings.gesture(GestureSlot.SwipeUp) == Gesture.DRAWER

    // El reloj no puede ser más ancho que el lugar que tiene en la pantalla
    val availDp = if (landscape) cfg.screenWidthDp / 2f - settings.homeMargin
    else cfg.screenWidthDp - settings.homeMargin * 2f
    val maxClock = (availDp / (if (settings.clockStacked) 1.25f else 2.5f))
        .coerceIn(MIN_CLOCK_SP, MAX_CLOCK_SP)

    val gestures = Modifier
        .pointerInput(Unit) {
            detectTapGestures(
                onDoubleTap = { gesture(GestureSlot.DoubleTap) },
                onLongPress = { gesture(GestureSlot.LongPress) },
            )
        }
        .swipeGestures { gesture(it) }

    if (landscape) {
        Row(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .then(gestures)
                .padding(horizontal = settings.homeMargin.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.weight(1f).fillMaxHeight(),
                contentAlignment = if (center) Alignment.Center else Alignment.CenterStart,
            ) {
                Column(horizontalAlignment = align) {
                    if (settings.showClock) Clock(settings, maxClock, align, onResizeClock)
                    WorldClocks(settings, align, onRemoveClock, onResizeSmall)
                }
            }
            Box(
                Modifier.weight(1f).fillMaxHeight(),
                contentAlignment = if (center) Alignment.Center else Alignment.CenterStart,
            ) {
                Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = align) {
                    PinnedApps(pinnedApps, settings, swipeUpIsDrawer, onLaunch, onLongPress)
                    if (settings.homeSearchBar) {
                        Spacer(Modifier.height(12.dp))
                        HomeSearchBar(onOpenSearch)
                    }
                }
            }
        }
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .then(gestures)
                .padding(horizontal = settings.homeMargin.dp, vertical = 24.dp),
            horizontalAlignment = align,
        ) {
            if (settings.clockPosition == 1) Spacer(Modifier.weight(1f)) else Spacer(Modifier.height(40.dp))
            if (settings.showClock) Clock(settings, maxClock, align, onResizeClock)
            WorldClocks(settings, align, onRemoveClock, onResizeSmall)
            Spacer(Modifier.weight(1f))
            PinnedApps(pinnedApps, settings, swipeUpIsDrawer, onLaunch, onLongPress)
            if (settings.appsPosition == 1) Spacer(Modifier.weight(1f))
            if (settings.homeSearchBar) {
                Spacer(Modifier.height(16.dp))
                HomeSearchBar(onOpenSearch)
            }
            Spacer(Modifier.height(24.dp))
            if (swipeUpIsDrawer) {
                Box(
                    Modifier
                        .align(Alignment.CenterHorizontally)
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Dim.copy(alpha = 0.45f)),
                )
            }
        }
    }
}

/** Línea de datos debajo de la hora: fecha, batería y próxima alarma, según lo que actives. */
private fun infoLine(ctx: Context, now: Long, s: LauncherSettings, is24: Boolean): String {
    val parts = mutableListOf<String>()
    if (s.showDate) parts.add(formatDate(ctx, now, s.dateFormat))
    if (s.showBattery) {
        val pct = batteryPercent(ctx)
        if (pct >= 0) parts.add("$pct%")
    }
    if (s.showAlarm) {
        val alarm = nextAlarmMillis(ctx)
        if (alarm != null) {
            parts.add("Alarma " + DateFormat.format(if (is24) "HH:mm" else "h:mm a", alarm))
        }
    }
    return parts.joinToString("  ·  ").uppercase()
}

@Composable
private fun ClockText(
    text: String,
    size: Float,
    color: Color,
    weight: FontWeight,
    family: FontFamily,
    stacked: Boolean,
) {
    Text(
        text = text,
        color = color,
        fontSize = size.sp,
        fontWeight = weight,
        fontFamily = family,
        letterSpacing = (size * -0.03f).sp,
        lineHeight = (size * (if (stacked) 0.98f else 1.04f)).sp,
        maxLines = 1,
        softWrap = false,
    )
}

/** Reloj principal. Pellizcá con dos dedos para cambiarle el tamaño. */
@Composable
fun Clock(
    settings: LauncherSettings,
    maxSp: Float,
    align: Alignment.Horizontal,
    onResize: (Int) -> Unit,
) {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    // Tamaño mientras pellizcás; se guarda recién al levantar los dedos
    var live by remember(settings.clockSize) { mutableFloatStateOf(settings.clockSize.toFloat()) }
    val size = live.coerceIn(MIN_CLOCK_SP, maxSp)
    val is24 = when (settings.clockFormat) {
        1 -> true
        2 -> false
        else -> DateFormat.is24HourFormat(ctx)
    }
    val hours = DateFormat.format(if (is24) "HH" else "h", now).toString()
    val minutes = DateFormat.format("mm", now).toString()
    val accented = settings.clockColor == 1
    val timeColor = if (accented) Accent else Ink
    val infoColor = if (accented) Ink else Accent
    val weight = weightFor(settings.clockWeight)
    val family = fontFor(settings.homeFont)
    val info = infoLine(ctx, now, settings, is24)

    Column(
        Modifier.pinchToResize(
            onZoom = { z -> live = (live * z).coerceIn(MIN_CLOCK_SP, maxSp) },
            onEnd = { onResize(live.roundToInt()) },
        ),
        horizontalAlignment = align,
    ) {
        if (settings.clockStacked) {
            ClockText(hours, size, timeColor, weight, family, true)
            ClockText(minutes, size, timeColor, weight, family, true)
        } else {
            ClockText("$hours:$minutes", size, timeColor, weight, family, false)
        }
        if (info.isNotEmpty()) {
            Text(
                text = info,
                color = infoColor,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = family,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 4.dp),
            )
        }
    }
}

// ---- Cajón de apps ------------------------------------------------------
@Composable
fun SearchField(
    query: String,
    onChange: (String) -> Unit,
    onSearch: () -> Unit,
    focusRequester: FocusRequester? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Ink, fontSize = 17.sp),
        cursorBrush = SolidColor(Accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier
            .fillMaxWidth()
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Card)
                    .padding(start = 18.dp, end = if (trailing != null) 8.dp else 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Search, null, tint = Accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Buscar apps", color = Dim, fontSize = 17.sp)
                    inner()
                }
                trailing?.invoke()
            }
        },
    )
}

@Composable
fun AppIcon(app: AppInfo, size: Dp) {
    val ctx = LocalContext.current
    val style = LocalIconStyle.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(app, style), app, style) {
        value = IconCache.peek(app, style)
            ?: withContext(Dispatchers.Default) { IconCache.get(ctx, app, style) }
    }
    Box(Modifier.size(size).clip(style.shape.composeShape())) {
        icon?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    pinned: List<String>,
    settings: LauncherSettings,
    autoFocus: Boolean,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val style = LocalIconStyle.current
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    var query by remember { mutableStateOf("") }

    // Búsqueda sin tildes; primero las que empiezan igual
    val filtered = remember(apps, query) {
        if (query.isBlank()) {
            apps
        } else {
            val q = normalize(query.trim())
            apps.filter { matchesQuery(it.label, query) }
                .sortedBy { if (normalize(it.label).startsWith(q)) 0 else 1 }
        }
    }
    val usage = remember { Prefs.getUsage(ctx) }
    val frequent = remember(apps) {
        apps.filter { (usage[it.pkg] ?: 0) > 0 }
            .sortedByDescending { usage[it.pkg] ?: 0 }
            .take(FREQUENT_COUNT)
    }
    val showFrequent = settings.drawerFrequent && query.isBlank() && frequent.isNotEmpty()
    val letters = remember(filtered) { filtered.map { indexLetter(it.label) }.distinct() }
    val showIndex = settings.drawerIndex && query.isBlank() && filtered.size >= 12
    val headerOffset = if (showFrequent) 1 else 0
    val indexPad = if (showIndex) 22.dp else 0.dp
    val cells: GridCells = if (settings.drawerColumns > 0) {
        GridCells.Fixed(settings.drawerColumns)
    } else {
        GridCells.Adaptive((style.sizeDp + 22).dp)
    }

    BackHandler { onClose() }

    LaunchedEffect(Unit) {
        if (autoFocus) runCatching { focusRequester.requestFocus() }
    }
    LaunchedEffect(filtered, query) {
        if (settings.autoLaunch && query.isNotBlank() && filtered.size == 1) onLaunch(filtered[0])
    }

    fun jump(letter: Char) {
        val idx = filtered.indexOfFirst { indexLetter(it.label) == letter }
        if (idx < 0) return
        scope.launch {
            if (settings.drawerList) listState.scrollToItem(idx + headerOffset)
            else gridState.scrollToItem(idx + headerOffset)
        }
    }

    val searchBox: @Composable () -> Unit = {
        Box(Modifier.padding(horizontal = 8.dp)) {
            SearchField(
                query = query,
                onChange = { query = it },
                onSearch = {
                    if (filtered.isNotEmpty()) onLaunch(filtered.first())
                    else if (query.isNotBlank()) webSearch(ctx, query.trim())
                },
                focusRequester = focusRequester,
                trailing = {
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).clickable(onClick = onOpenSettings),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Default.Settings, null, tint = Dim, modifier = Modifier.size(20.dp))
                    }
                },
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(DrawerBg.copy(alpha = settings.drawerOpacity.coerceIn(0.3f, 1f)))
            .pointerInput(Unit) {} // evita que los toques lleguen al inicio que está detrás
            .windowInsetsPadding(safeInsets())
            .imePadding()
            .padding(horizontal = 12.dp),
    ) {
        if (settings.drawerSearchTop) {
            Spacer(Modifier.height(12.dp))
            searchBox()
            Spacer(Modifier.height(4.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (filtered.isEmpty() && query.isNotBlank()) {
                Column(
                    Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { webSearch(ctx, query.trim()) }
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Ninguna app coincide", color = Dim, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Buscar “${query.trim()}” en la web",
                        color = Accent,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                    )
                }
            } else if (settings.drawerList) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 8.dp, end = indexPad),
                ) {
                    if (showFrequent) {
                        item(key = "frequent") { FrequentRow(frequent, onLaunch, onLongPress) }
                    }
                    items(filtered, key = { it.component.flattenToString() }) { app ->
                        AppRow(app, app.pkg in pinned, onLaunch, onLongPress)
                    }
                }
            } else {
                LazyVerticalGrid(
                    state = gridState,
                    columns = cells,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 8.dp, end = indexPad),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    if (showFrequent) {
                        item(key = "frequent", span = { GridItemSpan(maxLineSpan) }) {
                            FrequentRow(frequent, onLaunch, onLongPress)
                        }
                    }
                    gridItems(filtered, key = { it.component.flattenToString() }) { app ->
                        AppCell(app, onLaunch, onLongPress, settings.drawerLabels, settings.drawerLabelSize)
                    }
                }
            }
            if (showIndex) {
                AlphabetIndex(
                    letters = letters,
                    onSelect = { jump(it) },
                    modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight(0.85f),
                )
            }
        }
        if (!settings.drawerSearchTop) {
            Spacer(Modifier.height(8.dp))
            searchBox()
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun FrequentRow(
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        Text(
            "MÁS USADAS",
            color = Dim,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(start = 6.dp, top = 4.dp, bottom = 2.dp),
        )
        Row(Modifier.fillMaxWidth()) {
            repeat(FREQUENT_COUNT) { i ->
                Box(Modifier.weight(1f)) {
                    apps.getOrNull(i)?.let { AppCell(it, onLaunch, onLongPress) }
                }
            }
        }
    }
}

/** Letras al costado: tocá o arrastrá para saltar a esa letra. */
@Composable
private fun AlphabetIndex(letters: List<Char>, onSelect: (Char) -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    val select by rememberUpdatedState(onSelect)
    var heightPx by remember { mutableIntStateOf(1) }
    var last by remember { mutableIntStateOf(-1) }

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = ((y / heightPx) * letters.size).toInt().coerceIn(0, letters.size - 1)
        if (i != last) {
            last = i
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            select(letters[i])
        }
    }

    Column(
        modifier
            .width(22.dp)
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectTapGestures(onPress = { pick(it.y); tryAwaitRelease(); last = -1 })
            }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onDragEnd = { last = -1 },
                    onDragCancel = { last = -1 },
                    onVerticalDrag = { change, _ -> pick(change.position.y) },
                )
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        letters.forEach { l ->
            Text(l.toString(), color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppInfo,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    showLabel: Boolean = true,
    labelSp: Int = 12,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppIcon(app, LocalIconStyle.current.sizeDp.dp)
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                app.label,
                color = Ink,
                fontSize = labelSp.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(
    app: AppInfo,
    isPinned: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(app, 44.dp)
        Spacer(Modifier.width(18.dp))
        Text(
            app.label,
            color = Ink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (isPinned) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
        }
    }
}
