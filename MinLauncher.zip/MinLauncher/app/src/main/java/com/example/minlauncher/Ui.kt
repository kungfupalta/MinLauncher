package com.example.minlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---- Paleta y estado global de la interfaz -------------------------------
val DefaultAccent = Color(0xFF72B8EE)
val OnAccent = Color(0xFF0B1D2E)
val Ink = Color(0xFFF2F2F5)
val Dim = Color(0xFF8E8E99)
val Card = Color(0xFF1F2023)
val CardHi = Color(0xFF2C2D31)
val SheetBg = Color(0xFF17181B)

val LocalAccent = compositionLocalOf { DefaultAccent }
val LocalIconStyle = compositionLocalOf { IconStyle() }
val LocalCfg = compositionLocalOf { LauncherConfig() }

private const val MAX_PINNED = 7

@Composable
fun safeInsets(): WindowInsets = WindowInsets.systemBars.union(WindowInsets.displayCutout)

fun IconShape.composeShape(): Shape = when (this) {
    IconShape.Circle -> CircleShape
    IconShape.Rounded -> RoundedCornerShape(percent = 20)
    IconShape.Square -> RoundedCornerShape(percent = 6)
    IconShape.Squircle -> RoundedCornerShape(percent = 26)
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = DefaultAccent,
            background = Color.Black,
            surface = SheetBg,
        ),
        content = content,
    )
}

// ---- Raíz ---------------------------------------------------------------
@Composable
fun LauncherRoot(homeSignal: Int) {
    val ctx = LocalContext.current
    var style by remember { mutableStateOf(Prefs.getStyle(ctx)) }
    var cfg by remember { mutableStateOf(Prefs.getConfig(ctx)) }
    val accent = Color(Palettes[style.palette.coerceIn(0, Palettes.lastIndex)].accent)

    CompositionLocalProvider(
        LocalIconStyle provides style,
        LocalCfg provides cfg,
        LocalAccent provides accent,
    ) {
        LauncherContent(
            homeSignal = homeSignal,
            style = style,
            onStyleChange = { style = it; Prefs.setStyle(ctx, it) },
            cfg = cfg,
            onCfgChange = { cfg = it; Prefs.setConfig(ctx, it) },
        )
    }
}

@Composable
fun LauncherContent(
    homeSignal: Int,
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    cfg: LauncherConfig,
    onCfgChange: (LauncherConfig) -> Unit,
) {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var rawApps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var pinned by remember { mutableStateOf(Prefs.getPinned(ctx) ?: emptyList()) }
    var labels by remember { mutableStateOf(Prefs.getLabels(ctx)) }
    var hidden by remember { mutableStateOf(Prefs.getHidden(ctx)) }
    var drawerOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var editing by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var renameApp by remember { mutableStateOf<AppInfo?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadTick) {
        val loaded = withContext(Dispatchers.IO) { loadApps(ctx) }
        rawApps = loaded
        if (Prefs.getPinned(ctx) == null) {
            pinned = defaultPinned(ctx, loaded).take(4)
            Prefs.setPinned(ctx, pinned)
        }
    }

    // Recargar si se instala / desinstala / actualiza una app
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                i.data?.schemeSpecificPart?.let { IconCache.clear(it) }
                reloadTick++
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    // Botón Home estando en el launcher: volver al inicio
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        menuApp = null
        editing = false
        settingsOpen = false
    }

    // Lista con los nombres personalizados aplicados
    val apps = remember(rawApps, labels) {
        rawApps
            .map { it.copy(label = labels[it.pkg] ?: it.original) }
            .sortedBy { it.label.lowercase() }
    }
    val visibleApps = remember(apps, hidden) { apps.filter { it.pkg !in hidden } }
    val pinnedApps = remember(apps, pinned) {
        pinned.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    }

    fun savePinned(list: List<String>) {
        pinned = list
        Prefs.setPinned(ctx, list)
    }

    fun saveHidden(set: Set<String>) {
        hidden = set
        Prefs.setHidden(ctx, set)
    }

    fun saveLabel(app: AppInfo, name: String) {
        val n = name.trim()
        labels = if (n.isEmpty() || n == app.original) labels - app.pkg else labels + (app.pkg to n)
        Prefs.setLabels(ctx, labels)
    }

    fun longPressed(app: AppInfo) {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        menuApp = app
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = cfg.dim))
            .pointerInput(cfg.swipeDownNotifications, drawerOpen, settingsOpen) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -90f) {
                            drawerOpen = true
                        } else if (total > 120f && cfg.swipeDownNotifications && !drawerOpen && !settingsOpen) {
                            expandNotifications(ctx)
                        }
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        HomeScreen(
            pinnedApps = pinnedApps,
            onLaunch = { launchApp(ctx, it) },
            onLongPress = { longPressed(it) },
            onEdit = { editing = true },
            onDoubleTap = { if (cfg.doubleTapLock) LockService.lock() },
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut(),
        ) {
            Drawer(
                apps = visibleApps,
                onClose = { drawerOpen = false },
                onLaunch = { launchApp(ctx, it); drawerOpen = false },
                onLongPress = { longPressed(it) },
            )
        }

        AnimatedVisibility(
            visible = settingsOpen,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut(),
        ) {
            SettingsScreen(
                apps = apps,
                hidden = hidden,
                style = style,
                onStyleChange = onStyleChange,
                cfg = cfg,
                onCfgChange = onCfgChange,
                onUnhide = { saveHidden(hidden - it) },
                onClose = { settingsOpen = false },
            )
        }
    }

    menuApp?.let { app ->
        AppSheet(
            app = app,
            isPinned = app.pkg in pinned,
            onDismiss = { menuApp = null },
            onTogglePin = {
                savePinned(
                    if (app.pkg in pinned) pinned - app.pkg
                    else (pinned + app.pkg).takeLast(MAX_PINNED)
                )
                menuApp = null
            },
            onRename = { renameApp = app; menuApp = null },
            onHide = { saveHidden(hidden + app.pkg); menuApp = null },
            onInfo = { openAppInfo(ctx, app); menuApp = null },
            onUninstall = { uninstallApp(ctx, app); menuApp = null },
        )
    }

    if (editing) {
        HomeEditor(
            apps = apps,
            pinned = pinned,
            onPinnedChange = { savePinned(it) },
            onRename = { renameApp = it },
            onSettings = { editing = false; settingsOpen = true },
            onDismiss = { editing = false },
        )
    }

    renameApp?.let { app ->
        RenameDialog(
            app = app,
            onSave = { saveLabel(app, it); renameApp = null },
            onDismiss = { renameApp = null },
        )
    }
}

// ---- Inicio -------------------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedList(
    pinnedApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    if (pinnedApps.isEmpty()) {
        Text(
            "Deslizá hacia arriba para ver tus apps.\nMantené apretado acá para agregar las tuyas.",
            color = Dim,
            fontSize = 14.sp,
            lineHeight = 21.sp,
        )
    } else {
        pinnedApps.forEach { app ->
            Text(
                text = app.label,
                color = Ink,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = (-0.3).sp,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .combinedClickable(
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                    )
                    .padding(vertical = 9.dp, horizontal = 2.dp),
            )
        }
    }
}

@Composable
fun HomeScreen(
    pinnedApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onEdit: () -> Unit,
    onDoubleTap: () -> Unit,
) {
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val doubleTap by rememberUpdatedState(onDoubleTap)

    if (landscape) {
        Row(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { onEdit() }, onDoubleTap = { doubleTap() })
                }
                .padding(horizontal = 40.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                Clock(
                    fontSize = 72.sp,
                    onTimeClick = { openClock(ctx) },
                    onDateClick = { openCalendar(ctx) },
                    onLongClick = onEdit,
                    onDoubleClick = { doubleTap() },
                )
            }
            Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    PinnedList(pinnedApps, onLaunch, onLongPress)
                }
            }
        }
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(safeInsets())
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { onEdit() }, onDoubleTap = { doubleTap() })
                }
                .padding(horizontal = 32.dp, vertical = 24.dp),
        ) {
            Spacer(Modifier.height(40.dp))
            Clock(
                onTimeClick = { openClock(ctx) },
                onDateClick = { openCalendar(ctx) },
                onLongClick = onEdit,
                onDoubleClick = { doubleTap() },
            )
            Spacer(Modifier.weight(1f))
            PinnedList(pinnedApps, onLaunch, onLongPress)
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Dim.copy(alpha = 0.45f)),
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Clock(
    fontSize: TextUnit = 96.sp,
    onTimeClick: () -> Unit = {},
    onDateClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
    onDoubleClick: () -> Unit = {},
) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val cfg = LocalCfg.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    val time = DateFormat.format(pattern, now).toString()
    val date = DateUtils.formatDateTime(
        ctx, now,
        DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NO_YEAR,
    )

    Column {
        Text(
            text = time,
            color = Ink,
            fontSize = fontSize,
            fontWeight = FontWeight.Thin,
            letterSpacing = (fontSize.value * -0.03f).sp,
            lineHeight = fontSize * 1.04f,
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .combinedClickable(
                    onClick = onTimeClick,
                    onLongClick = onLongClick,
                    onDoubleClick = onDoubleClick,
                ),
        )
        if (cfg.showDate) {
            Text(
                text = date.uppercase(),
                color = accent,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 2.sp,
                modifier = Modifier
                    .padding(start = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .combinedClickable(onClick = onDateClick, onLongClick = onLongClick),
            )
        }
    }
}

// ---- Iconos -------------------------------------------------------------
@Composable
fun AppIcon(app: AppInfo, size: Dp) {
    val ctx = LocalContext.current
    val style = LocalIconStyle.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(app, style), app, style) {
        value = IconCache.peek(app, style)
            ?: withContext(Dispatchers.Default) { IconCache.get(ctx, app, style) }
    }
    Box(Modifier.size(size).clip(style.shape.composeShape())) {
        icon?.let { Image(it, null, Modifier.fillMaxSize()) }
    }
}

// ---- Cajón de apps ------------------------------------------------------
@Composable
fun SearchField(
    query: String,
    onChange: (String) -> Unit,
    onSearch: () -> Unit,
    placeholder: String = "Buscar apps",
) {
    val accent = LocalAccent.current
    BasicTextField(
        value = query,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Ink, fontSize = 17.sp),
        cursorBrush = SolidColor(accent),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Card)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.Search, null, tint = accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text(placeholder, color = Dim, fontSize = 17.sp)
                    inner()
                }
            }
        },
    )
}

private fun letterOf(label: String): String {
    val c = label.firstOrNull()?.uppercaseChar() ?: return "#"
    return if (c.isLetter()) c.toString() else "#"
}

@Composable
fun AlphaBar(letters: List<String>, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    var h by remember { mutableIntStateOf(1) }
    val currentSelect by rememberUpdatedState(onSelect)

    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = ((y / h) * letters.size).toInt().coerceIn(0, letters.lastIndex)
        currentSelect(letters[i])
    }

    Column(
        modifier
            .fillMaxHeight(0.86f)
            .onSizeChanged { h = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onVerticalDrag = { change, _ -> pick(change.position.y) },
                )
            }
            .pointerInput(letters) { detectTapGestures(onTap = { pick(it.y) }) }
            .padding(horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        letters.forEach { Text(it, color = Dim, fontSize = 10.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    val ctx = LocalContext.current
    val style = LocalIconStyle.current
    val cfg = LocalCfg.current
    val accent = LocalAccent.current
    val scope = rememberCoroutineScope()
    val gridState = rememberLazyGridState()
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    val letters = remember(filtered) { filtered.map { letterOf(it.label) }.distinct() }
    val firstIndex = remember(filtered) {
        letters.associateWith { l -> filtered.indexOfFirst { letterOf(it.label) == l } }
    }
    val showBar = query.isBlank() && filtered.size > 20

    BackHandler { onClose() }

    // Abrir directo si queda una sola coincidencia (opcional)
    LaunchedEffect(filtered, query) {
        if (cfg.autoLaunch && query.trim().length >= 2 && filtered.size == 1) onLaunch(filtered[0])
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2090A0D))
            .windowInsetsPadding(safeInsets())
            .imePadding()
            .padding(horizontal = 12.dp),
    ) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive((style.sizeDp + 22).dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 16.dp, bottom = 8.dp, end = if (showBar) 20.dp else 0.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                gridItems(filtered, key = { it.component.flattenToString() }) { app ->
                    AppCell(app, onLaunch, onLongPress)
                }
                if (filtered.isEmpty() && query.isNotBlank()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(Card)
                                .clickable { webSearch(ctx, query.trim()) }
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Default.Search, null, tint = accent, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(14.dp))
                            Text("Buscar «${query.trim()}» en la web", fontSize = 16.sp, maxLines = 2)
                        }
                    }
                }
            }
            if (showBar) {
                AlphaBar(letters, Modifier.align(Alignment.CenterEnd)) { l ->
                    firstIndex[l]?.let { idx -> scope.launch { gridState.scrollToItem(idx) } }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.padding(horizontal = 8.dp)) {
            SearchField(
                query = query,
                onChange = { query = it },
                onSearch = {
                    if (filtered.isEmpty()) webSearch(ctx, query.trim())
                    else onLaunch(filtered.first())
                },
            )
        }
        Spacer(Modifier.height(12.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppInfo,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    val style = LocalIconStyle.current
    val cfg = LocalCfg.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppIcon(app, style.sizeDp.dp)
        if (cfg.showLabels) {
            Spacer(Modifier.height(6.dp))
            Text(
                app.label,
                color = Ink,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(
    app: AppInfo,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(app, 44.dp)
        Spacer(Modifier.width(18.dp))
        Text(
            app.label,
            color = Ink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
    }
}

// ---- Editor del inicio --------------------------------------------------
@Composable
private fun CircleBtn(icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(if (enabled) CardHi else Color.Transparent)
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon, null,
            tint = if (enabled) Ink else Dim.copy(alpha = 0.3f),
            modifier = Modifier.size(20.dp),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeEditor(
    apps: List<AppInfo>,
    pinned: List<String>,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onSettings: () -> Unit,
    onDismiss: () -> Unit,
) {
    var adding by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        if (adding) {
            AddAppList(
                apps = apps,
                pinned = pinned,
                onBack = { adding = false },
                onPick = { onPinnedChange(pinned + it.pkg); adding = false },
            )
        } else {
            EditList(
                apps = apps,
                pinned = pinned,
                onPinnedChange = onPinnedChange,
                onRename = onRename,
                onAdd = { adding = true },
                onSettings = onSettings,
                onDone = onDismiss,
            )
        }
    }
}

@Composable
private fun EditList(
    apps: List<AppInfo>,
    pinned: List<String>,
    onPinnedChange: (List<String>) -> Unit,
    onRename: (AppInfo) -> Unit,
    onAdd: () -> Unit,
    onSettings: () -> Unit,
    onDone: () -> Unit,
) {
    val accent = LocalAccent.current
    // Solo los paquetes que siguen instalados
    val list = pinned.filter { p -> apps.any { it.pkg == p } }
    val canAdd = list.size < MAX_PINNED

    fun move(i: Int, j: Int) {
        val m = list.toMutableList()
        java.util.Collections.swap(m, i, j)
        onPinnedChange(m)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 28.dp),
    ) {
        Text("Editar inicio", fontSize = 24.sp, fontWeight = FontWeight.Light)
        Text(
            "Tocá un nombre para renombrarlo",
            color = Dim,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp),
        )

        list.forEachIndexed { index, pkg ->
            val app = apps.first { it.pkg == pkg }
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Card)
                    .padding(start = 18.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    app.label,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 1,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onRename(app) }
                        .padding(vertical = 10.dp),
                )
                CircleBtn(Icons.Default.KeyboardArrowUp, enabled = index > 0) { move(index, index - 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.KeyboardArrowDown, enabled = index < list.lastIndex) { move(index, index + 1) }
                Spacer(Modifier.width(4.dp))
                CircleBtn(Icons.Default.Close) { onPinnedChange(list - pkg) }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(6.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(if (canAdd) accent else Card)
                .then(if (canAdd) Modifier.clickable(onClick = onAdd) else Modifier)
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Add, null, tint = if (canAdd) OnAccent else Dim, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(
                if (canAdd) "Agregar app" else "Máximo $MAX_PINNED apps",
                color = if (canAdd) OnAccent else Dim,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
            )
        }

        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Card)
                .clickable(onClick = onSettings)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(CardHi),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.Settings, null, tint = Ink, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(16.dp))
            Text("Ajustes del launcher", fontSize = 17.sp)
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Listo",
            color = accent,
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onDone)
                .padding(horizontal = 24.dp, vertical = 12.dp),
        )
    }
}

@Composable
private fun AddAppList(
    apps: List<AppInfo>,
    pinned: List<String>,
    onBack: () -> Unit,
    onPick: (AppInfo) -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val candidates = remember(apps, pinned, q) {
        apps.filter { it.pkg !in pinned && (q.isBlank() || it.label.contains(q.trim(), ignoreCase = true)) }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.88f)
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
            Spacer(Modifier.width(14.dp))
            Text("Agregar app", fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        Spacer(Modifier.height(14.dp))
        SearchField(q, { q = it }, { candidates.firstOrNull()?.let(onPick) })
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(candidates, key = { it.component.flattenToString() }) { app ->
                AppRow(app, onPick, onPick)
            }
        }
    }
}

// ---- Pantalla de ajustes ------------------------------------------------
@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val accent = LocalAccent.current
    Text(
        title.uppercase(),
        color = accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 1.6.sp,
        modifier = Modifier.padding(start = 6.dp, top = 24.dp, bottom = 8.dp),
    )
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        content = content,
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val accent = LocalAccent.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp)
            if (subtitle != null) {
                Text(subtitle, color = Dim, fontSize = 12.sp, lineHeight = 16.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = OnAccent,
                checkedTrackColor = accent,
                uncheckedThumbColor = Dim,
                uncheckedTrackColor = CardHi,
                uncheckedBorderColor = Dim,
            ),
        )
    }
}

@Composable
private fun SliderRow(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontSize = 16.sp)
        Text(valueText, color = accent, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = accent,
            activeTrackColor = accent,
            inactiveTrackColor = CardHi,
        ),
    )
}

@Composable
private fun ActionRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
    ) {
        Text(title, fontSize = 16.sp)
        Text(subtitle, color = Dim, fontSize = 12.sp, lineHeight = 16.sp)
    }
}

@Composable
fun SettingsScreen(
    apps: List<AppInfo>,
    hidden: Set<String>,
    style: IconStyle,
    onStyleChange: (IconStyle) -> Unit,
    cfg: LauncherConfig,
    onCfgChange: (LauncherConfig) -> Unit,
    onUnhide: (String) -> Unit,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    BackHandler { onClose() }

    val sample = remember(apps, hidden) { apps.filter { it.pkg !in hidden }.take(4) }
    val hiddenApps = remember(apps, hidden) { apps.filter { it.pkg in hidden } }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0C0F))
            .windowInsetsPadding(safeInsets()),
    ) {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onClose)
            Spacer(Modifier.width(14.dp))
            Text("Ajustes", fontSize = 26.sp, fontWeight = FontWeight.Light)
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
        ) {
            // Vista previa en vivo
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Card)
                    .padding(vertical = 18.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                sample.forEach { AppIcon(it, style.sizeDp.coerceAtMost(72).dp) }
            }

            Section("Iconos") {
                SliderRow(
                    title = "Tamaño",
                    valueText = "${style.sizeDp}",
                    value = style.sizeDp.toFloat(),
                    range = 44f..88f,
                    onChange = { onStyleChange(style.copy(sizeDp = it.roundToInt())) },
                )
                Spacer(Modifier.height(6.dp))
                Text("Forma", fontSize = 16.sp)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    IconShape.values().forEach { sh ->
                        val selected = sh == style.shape
                        Text(
                            sh.label,
                            color = if (selected) OnAccent else Ink,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (selected) accent else CardHi)
                                .clickable { onStyleChange(style.copy(shape = sh)) }
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                SwitchRow(
                    title = "Iconos temáticos",
                    subtitle = "Color liso con el símbolo oscuro, como One UI",
                    checked = style.themed,
                    onChange = { onStyleChange(style.copy(themed = it)) },
                )
                SwitchRow(
                    title = "Mostrar nombres",
                    subtitle = "Debajo de cada icono en el cajón",
                    checked = cfg.showLabels,
                    onChange = { onCfgChange(cfg.copy(showLabels = it)) },
                )
            }

            Section("Colores") {
                Text("Color de acento", fontSize = 16.sp)
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Palettes.forEachIndexed { i, p ->
                        Box(
                            Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(Color(p.accent))
                                .clickable { onStyleChange(style.copy(palette = i)) },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (i == style.palette) {
                                Icon(Icons.Default.Check, null, tint = OnAccent, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                SliderRow(
                    title = "Oscurecer el fondo",
                    valueText = "${(cfg.dim * 100).roundToInt()}%",
                    value = cfg.dim,
                    range = 0f..0.95f,
                    onChange = { onCfgChange(cfg.copy(dim = it)) },
                )
            }

            Section("Inicio") {
                SwitchRow(
                    title = "Mostrar la fecha",
                    checked = cfg.showDate,
                    onChange = { onCfgChange(cfg.copy(showDate = it)) },
                )
                Text(
                    "Tocá la hora para abrir el reloj y la fecha para abrir el calendario.",
                    color = Dim,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }

            Section("Gestos") {
                SwitchRow(
                    title = "Deslizar hacia abajo",
                    subtitle = "Abre el panel de notificaciones",
                    checked = cfg.swipeDownNotifications,
                    onChange = { onCfgChange(cfg.copy(swipeDownNotifications = it)) },
                )
                SwitchRow(
                    title = "Doble toque para bloquear",
                    subtitle = "Bloquea la pantalla desde el inicio",
                    checked = cfg.doubleTapLock,
                    onChange = { onCfgChange(cfg.copy(doubleTapLock = it)) },
                )
                if (cfg.doubleTapLock) {
                    ActionRow(
                        title = "Activar permiso en Accesibilidad",
                        subtitle = "Buscá «MinLauncher» y activalo. Solo se usa para bloquear.",
                        onClick = { openAccessibilitySettings(ctx) },
                    )
                }
                SwitchRow(
                    title = "Abrir al quedar una sola app",
                    subtitle = "En el buscador, abre la app cuando solo hay una coincidencia",
                    checked = cfg.autoLaunch,
                    onChange = { onCfgChange(cfg.copy(autoLaunch = it)) },
                )
            }

            Section("Apps ocultas") {
                if (hiddenApps.isEmpty()) {
                    Text(
                        "No ocultaste ninguna app. Mantené apretada una app y elegí «Ocultar».",
                        color = Dim,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                    )
                } else {
                    hiddenApps.forEach { app ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(app, 36.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(app.label, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                            TextButton(onClick = { onUnhide(app.pkg) }) {
                                Text("Mostrar", color = accent)
                            }
                        }
                    }
                }
            }

            Section("Sistema") {
                ActionRow(
                    title = "Launcher predeterminado",
                    subtitle = "Elegir MinLauncher como app de inicio",
                    onClick = { openHomeSettings(ctx) },
                )
            }

            Text(
                "MinLauncher 1.1 · código abierto (licencia MIT)",
                color = Dim,
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 28.dp),
            )
        }
    }
}

// ---- Renombrar ----------------------------------------------------------
@Composable
fun RenameDialog(app: AppInfo, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    val accent = LocalAccent.current
    var text by remember { mutableStateOf(app.label) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Card,
        title = { Text("Renombrar", color = Ink, fontWeight = FontWeight.Light) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = { Text(app.original, color = Dim) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Ink,
                        unfocusedTextColor = Ink,
                        cursorColor = accent,
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Dim.copy(alpha = 0.4f),
                    ),
                )
                Text(
                    "Dejalo vacío para volver al nombre original",
                    color = Dim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Guardar", color = accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = Dim) } },
    )
}

// ---- Menú de app (mantener apretada) -----------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(
    app: AppInfo,
    isPinned: Boolean,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onHide: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    val ctx = LocalContext.current
    val accent = LocalAccent.current
    val shortcuts = remember(app.pkg) { loadShortcuts(ctx, app) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Row(
                Modifier.padding(start = 4.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AppIcon(app, 48.dp)
                Spacer(Modifier.width(14.dp))
                Text(app.label, fontSize = 22.sp, fontWeight = FontWeight.Light)
            }
            shortcuts.forEach { sc ->
                SheetAction(
                    Icons.Default.PlayArrow,
                    sc.shortLabel?.toString() ?: "",
                    CardHi, Ink, Ink,
                ) { startShortcut(ctx, sc); onDismiss() }
            }
            SheetAction(
                Icons.Default.Star,
                if (isPinned) "Quitar de inicio" else "Fijar en inicio",
                accent, OnAccent, Ink, onTogglePin,
            )
            SheetAction(Icons.Default.Edit, "Renombrar", CardHi, Ink, Ink, onRename)
            SheetAction(Icons.Default.Close, "Ocultar del cajón", CardHi, Ink, Ink, onHide)
            SheetAction(Icons.Default.Info, "Info de la app", CardHi, Ink, Ink, onInfo)
            SheetAction(
                Icons.Default.Delete, "Desinstalar",
                Color(0xFF4A2626), Color(0xFFFF8A80), Color(0xFFFF8A80), onUninstall,
            )
        }
    }
}

@Composable
private fun SheetAction(
    icon: ImageVector,
    text: String,
    circle: Color,
    iconTint: Color,
    textColor: Color,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(circle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(16.dp))
        Text(text, color = textColor, fontSize = 17.sp)
    }
}
