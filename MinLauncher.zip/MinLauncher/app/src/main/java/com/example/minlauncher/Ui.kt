package com.example.minlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.text.format.DateFormat
import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ---- Paleta -------------------------------------------------------------
val Accent = Color(0xFF9DB8FF)
val Ink = Color(0xFFF2F2F5)
val Dim = Color(0xFF8E8E99)

/** true = se ve tu fondo de pantalla oscurecido; false = negro puro (ahorra batería en AMOLED) */
private const val SHOW_WALLPAPER = true
private const val MAX_PINNED = 6

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Color.Black,
            surface = Color(0xFF14151A),
        ),
        content = content,
    )
}

// ---- Raíz ---------------------------------------------------------------
@Composable
fun LauncherRoot(homeSignal: Int) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var pinned by remember { mutableStateOf(Prefs.getPinned(ctx) ?: emptyList()) }
    var drawerOpen by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var reloadTick by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadTick) {
        val loaded = withContext(Dispatchers.IO) { loadApps(ctx) }
        apps = loaded
        if (Prefs.getPinned(ctx) == null) {
            pinned = defaultPinned(ctx, loaded)
            Prefs.setPinned(ctx, pinned)
        }
    }

    // Recargar si se instala / desinstala / actualiza una app
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                i.data?.schemeSpecificPart?.let { IconCache.clear(it) }
                reloadTick++
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }

    // Botón Home estando en el launcher: volver al inicio
    LaunchedEffect(homeSignal) {
        drawerOpen = false
        menuApp = null
    }

    val pinnedApps = remember(apps, pinned) {
        pinned.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (SHOW_WALLPAPER) Color.Black.copy(alpha = 0.62f) else Color.Black)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -90f) drawerOpen = true },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        HomeScreen(
            pinnedApps = pinnedApps,
            onLaunch = { launchApp(ctx, it) },
            onLongPress = { menuApp = it },
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut(),
        ) {
            Drawer(
                apps = apps,
                pinned = pinned,
                onClose = { drawerOpen = false },
                onLaunch = { launchApp(ctx, it); drawerOpen = false },
                onLongPress = { menuApp = it },
            )
        }
    }

    menuApp?.let { app ->
        AppSheet(
            app = app,
            isPinned = app.pkg in pinned,
            onDismiss = { menuApp = null },
            onTogglePin = {
                pinned = if (app.pkg in pinned) pinned - app.pkg
                else (pinned + app.pkg).takeLast(MAX_PINNED)
                Prefs.setPinned(ctx, pinned)
                menuApp = null
            },
            onInfo = { openAppInfo(ctx, app); menuApp = null },
            onUninstall = { uninstallApp(ctx, app); menuApp = null },
        )
    }
}

// ---- Inicio -------------------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    pinnedApps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
            .padding(horizontal = 32.dp, vertical = 24.dp),
    ) {
        Spacer(Modifier.height(40.dp))
        Clock()
        Spacer(Modifier.weight(1f))

        if (pinnedApps.isEmpty()) {
            Text(
                "Deslizá hacia arriba para abrir tus apps.\nMantené apretada una para fijarla acá.",
                color = Dim,
                fontSize = 14.sp,
                lineHeight = 21.sp,
            )
        } else {
            pinnedApps.forEach { app ->
                Text(
                    text = app.label,
                    color = Ink,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = (-0.3).sp,
                    maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .combinedClickable(
                            onClick = { onLaunch(app) },
                            onLongClick = { onLongPress(app) },
                        )
                        .padding(vertical = 9.dp, horizontal = 2.dp),
                )
            }
        }

        Spacer(Modifier.height(28.dp))
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .width(36.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Dim.copy(alpha = 0.45f)),
        )
    }
}

@Composable
fun Clock() {
    val ctx = LocalContext.current
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    val pattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    val time = DateFormat.format(pattern, now).toString()
    val date = DateUtils.formatDateTime(
        ctx, now,
        DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NO_YEAR,
    )

    Column {
        Text(
            text = time,
            color = Ink,
            fontSize = 96.sp,
            fontWeight = FontWeight.Thin,
            letterSpacing = (-3).sp,
            lineHeight = 100.sp,
        )
        Text(
            text = date.uppercase(),
            color = Accent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(start = 4.dp),
        )
    }
}

// ---- Cajón de apps ------------------------------------------------------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(
    apps: List<AppInfo>,
    pinned: List<String>,
    onClose: () -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }
    BackHandler { onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF2090A0D))
            .windowInsetsPadding(WindowInsets.systemBars)
            .imePadding()
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(16.dp))

        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Ink, fontSize = 17.sp),
            cursorBrush = SolidColor(Accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { filtered.firstOrNull()?.let(onLaunch) }),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color.White.copy(alpha = 0.07f))
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.Search, null, tint = Dim, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) Text("Buscar apps", color = Dim, fontSize = 17.sp)
                        inner()
                    }
                }
            },
        )

        Spacer(Modifier.height(8.dp))

        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 8.dp)) {
            items(filtered, key = { it.component.flattenToString() }) { app ->
                AppRow(app, app.pkg in pinned, onLaunch, onLongPress)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppRow(
    app: AppInfo,
    isPinned: Boolean,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(IconCache.peek(app), app) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.get(ctx, app) }
    }

    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = { onLongPress(app) },
            )
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp)) {
            icon?.let { Image(it, null, Modifier.fillMaxSize()) }
        }
        Spacer(Modifier.width(18.dp))
        Text(
            app.label,
            color = Ink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        if (isPinned) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
        }
    }
}

// ---- Menú de app (mantener apretada) -----------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppSheet(
    app: AppInfo,
    isPinned: Boolean,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14151A),
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
        ) {
            Text(
                app.label,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(bottom = 12.dp),
            )
            SheetAction(if (isPinned) "Quitar de inicio" else "Fijar en inicio", Accent, onTogglePin)
            SheetAction("Info de la app", Ink, onInfo)
            SheetAction("Desinstalar", Color(0xFFFF8A80), onUninstall)
        }
    }
}

@Composable
private fun SheetAction(text: String, color: Color, onClick: () -> Unit) {
    Text(
        text,
        color = color,
        fontSize = 17.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickableSafe(onClick)
            .padding(vertical = 14.dp, horizontal = 4.dp),
    )
}

private fun Modifier.combinedClickableSafe(onClick: () -> Unit): Modifier =
    this.then(Modifier.clickable(onClick = onClick))
