package com.example.minlauncher

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Lo que se está arrastrando ahora mismo. */
class DragState {
    var pkg by mutableStateOf<String?>(null)
    var pos by mutableStateOf(Offset.Zero)
    var moved by mutableStateOf(false)
    var origin: Offset = Offset.Zero
}

@Composable
internal fun HomeIcon(app: AppInfo, iconDp: Dp, showLabel: Boolean, labelSp: Int) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        AppIcon(app, iconDp)
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            Text(
                app.label,
                color = Ink,
                fontSize = labelSp.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 2.dp),
            )
        }
    }
}

/**
 * El inicio estilo One UI: páginas con una cuadrícula de apps, puntos de página, barra de búsqueda
 * opcional y una barra inferior (dock). Mantené apretada una app para moverla: soltala en otra celda
 * (se intercambian), en la barra inferior, o arrastrala a un costado para pasar de página.
 * Si la soltás arriba, en "Quitar", sale del inicio (no se desinstala).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Workspace(
    layout: HomeLayout,
    onLayout: (HomeLayout) -> Unit,
    apps: List<AppInfo>,
    settings: LauncherSettings,
    onLaunch: (AppInfo) -> Unit,
    onMenu: (AppInfo) -> Unit,
    onGesture: (GestureSlot) -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val d = density.density
    val haptic = LocalHapticFeedback.current
    val style = LocalIconStyle.current
    val drag = remember { DragState() }
    val layoutNow by rememberUpdatedState(layout)
    val onLayoutNow by rememberUpdatedState(onLayout)
    val launchNow by rememberUpdatedState(onLaunch)
    val menuNow by rememberUpdatedState(onMenu)
    val gestureNow by rememberUpdatedState(onGesture)
    val lockedNow by rememberUpdatedState(settings.lockLayout)
    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val byPkgNow by rememberUpdatedState(byPkg)
    var size by remember { mutableStateOf(IntSize.Zero) }

    fun px2dp(px: Float): Dp = (px / d).dp

    // ---- Medidas
    val cols = settings.gridCols.coerceIn(3, 7)
    val rows = settings.gridRows.coerceIn(3, 9)
    val dockCount = settings.dockCount.coerceIn(3, 6)
    val showDock = settings.homeDock
    val wPx = size.width.toFloat()
    val hPx = size.height.toFloat()
    val sidePx = settings.gridPadding * d
    val topPx = 28f * d
    val dockHpx = if (showDock) 96f * d else 0f
    val dotsHpx = if (settings.pageDots) 24f * d else 0f
    val searchHpx = if (settings.homeSearchBar) 64f * d else 0f
    val gridHpx = (hPx - topPx - dockHpx - dotsHpx - searchHpx).coerceAtLeast(120f * d)
    val cellW = ((wPx - 2f * sidePx) / cols).coerceAtLeast(1f)
    val cellH = (gridHpx / rows).coerceAtLeast(1f)
    val slotW = ((wPx - 2f * sidePx) / dockCount).coerceAtLeast(1f)
    val geo = Geo(
        cols = cols, rows = rows, dockCount = dockCount, showDock = showDock,
        widthPx = wPx, sidePx = sidePx, topPx = topPx, cellW = cellW, cellH = cellH,
        gridH = gridHpx, dockTop = hPx - dockHpx, dockH = dockHpx, slotW = slotW,
        removeH = topPx + 8f * d,
    )
    val geoNow by rememberUpdatedState(geo)

    val cellWdp = px2dp(cellW)
    val cellHdp = px2dp(cellH)
    val iconDp = minOf(
        style.sizeDp.dp,
        cellWdp - 14.dp,
        cellHdp * (if (settings.homeLabels) 0.58f else 0.8f),
    ).coerceAtLeast(28.dp)
    val dockIcon = minOf(style.sizeDp.dp, px2dp(slotW) - 14.dp, px2dp(dockHpx) - 28.dp).coerceAtLeast(28.dp)

    val pageCount = layout.pageCount.coerceIn(1, MAX_PAGES)
    val pagerState = rememberPagerState(pageCount = { pageCount })

    // ---- Soltar
    fun finishDrag() {
        val key = drag.pkg ?: return
        val moved = drag.moved
        val pos = drag.pos
        drag.pkg = null
        drag.moved = false
        if (!moved) {
            // La soltó sin moverla: se muestra el menú de la app
            byPkgNow[key]?.let { menuNow(it) }
            return
        }
        val g = geoNow
        val t = g.targetAt(pos.x, pos.y, pagerState.currentPage, clamp = true) ?: return
        val l = layoutNow
        val next = if (t.remove) l.remove(key) else l.move(key, t.page, t.col, t.row, g.cols, g.rows)
        onLayoutNow(next.pruned())
    }

    fun cancelDrag() {
        if (drag.pkg == null) return
        drag.pkg = null
        drag.moved = false
        onLayoutNow(layoutNow.pruned())
    }

    // ---- Cambiar de página mientras arrastrás: mantené el dedo en el borde
    val dragging = drag.pkg != null
    LaunchedEffect(dragging) {
        if (!dragging) return@LaunchedEffect
        var side = 0
        var since = 0L
        while (true) {
            val g = geoNow
            val edge = 40f * d
            val x = drag.pos.x
            val s = if (x < edge) -1 else if (x > g.widthPx - edge) 1 else 0
            val now = System.currentTimeMillis()
            if (s != side) {
                side = s
                since = now
            } else if (s != 0 && now - since > 600L) {
                since = now
                val target = pagerState.currentPage + s
                val count = layoutNow.pageCount
                if (target in 0 until count) {
                    pagerState.animateScrollToPage(target)
                } else if (s == 1 && target == count && count < MAX_PAGES) {
                    // Al borde derecho de la última página se crea una página nueva
                    onLayoutNow(layoutNow.copy(pageCount = count + 1))
                    delay(120)
                    pagerState.animateScrollToPage(target)
                }
            }
            delay(60)
        }
    }

    val doubleTapAction: ((Offset) -> Unit)? =
        if (settings.gesture(GestureSlot.DoubleTap) != Gesture.NONE) {
            val f: (Offset) -> Unit = { gestureNow(GestureSlot.DoubleTap) }
            f
        } else null

    Box(
        modifier
            .onSizeChanged { size = it }
            .pointerInput(doubleTapAction != null) {
                detectTapGestures(
                    onDoubleTap = doubleTapAction,
                    onTap = { pos ->
                        val t = geoNow.targetAt(pos.x, pos.y, pagerState.currentPage, clamp = false)
                        if (t != null && !t.remove) {
                            val placed = layoutNow.itemAt(t.page, t.col, t.row)
                            val app = placed?.let { byPkgNow[it.pkg] }
                            if (app != null) launchNow(app)
                        }
                    },
                )
            }
            .swipeGestures { gestureNow(it) }
            // Tiene que ir último: así agarra el arrastre antes que los deslizamientos
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { pos ->
                        val t = geoNow.targetAt(pos.x, pos.y, pagerState.currentPage, clamp = false)
                        val placed = if (t != null && !t.remove) layoutNow.itemAt(t.page, t.col, t.row) else null
                        val app = placed?.let { byPkgNow[it.pkg] }
                        if (app == null) {
                            // Mantener apretado un espacio vacío
                            gestureNow(GestureSlot.LongPress)
                        } else if (lockedNow) {
                            menuNow(app)
                        } else {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            drag.origin = pos
                            drag.pos = pos
                            drag.moved = false
                            drag.pkg = app.pkg
                        }
                    },
                    onDrag = { change, amount ->
                        if (drag.pkg != null) {
                            change.consume()
                            drag.pos = drag.pos + amount
                            if (!drag.moved && (drag.pos - drag.origin).getDistance() > 24f) drag.moved = true
                        }
                    },
                    onDragEnd = { finishDrag() },
                    onDragCancel = { cancelDrag() },
                )
            },
    ) {
        if (size.width > 0 && size.height > 0) {
            Column(Modifier.fillMaxSize()) {
                Spacer(Modifier.height(px2dp(topPx)))

                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxWidth().height(px2dp(gridHpx)),
                    userScrollEnabled = drag.pkg == null,
                ) { page ->
                    Box(Modifier.fillMaxSize()) {
                        for (p in layout.items) {
                            if (p.page != page || p.pkg == drag.pkg) continue
                            val app = byPkg[p.pkg] ?: continue
                            Box(
                                Modifier
                                    .offset { IntOffset((sidePx + p.col * cellW).roundToInt(), (p.row * cellH).roundToInt()) }
                                    .size(cellWdp, cellHdp),
                            ) {
                                HomeIcon(app, iconDp, settings.homeLabels, settings.homeLabelSize)
                            }
                        }
                    }
                }

                if (settings.pageDots) {
                    Row(
                        Modifier.fillMaxWidth().height(px2dp(dotsHpx)),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        repeat(pageCount) { i ->
                            val current = i == pagerState.currentPage
                            Box(
                                Modifier
                                    .padding(horizontal = 3.dp)
                                    .size(if (current) 8.dp else 6.dp)
                                    .clip(CircleShape)
                                    .background(if (current) Ink else Dim.copy(alpha = 0.5f)),
                            )
                        }
                    }
                }

                if (settings.homeSearchBar) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(px2dp(searchHpx))
                            .padding(horizontal = px2dp(sidePx), vertical = 8.dp),
                    ) { HomeSearchBar(onOpenSearch) }
                }

                if (showDock) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(px2dp(dockHpx))
                            .padding(horizontal = px2dp(sidePx), vertical = 10.dp),
                    ) {
                        if (settings.dockBackground) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(32.dp))
                                    .background(Card.copy(alpha = 0.6f)),
                            )
                        }
                        Row(Modifier.fillMaxSize()) {
                            for (slot in 0 until dockCount) {
                                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                                    val p = layout.itemAt(DOCK, slot, 0)
                                    val app = if (p != null && p.pkg != drag.pkg) byPkg[p.pkg] else null
                                    if (app != null) HomeIcon(app, dockIcon, false, 11)
                                }
                            }
                        }
                    }
                }
            }

            // Hueco donde va a quedar lo que arrastrás
            val target = if (drag.pkg != null && drag.moved) {
                geo.targetAt(drag.pos.x, drag.pos.y, pagerState.currentPage, clamp = true)
            } else null
            if (target != null && !target.remove) {
                val rx: Float
                val ry: Float
                val rw: Float
                val rh: Float
                if (target.page == DOCK) {
                    rx = sidePx + target.col * slotW
                    ry = geo.dockTop
                    rw = slotW
                    rh = dockHpx
                } else {
                    rx = sidePx + target.col * cellW
                    ry = topPx + target.row * cellH
                    rw = cellW
                    rh = cellH
                }
                Box(
                    Modifier
                        .offset { IntOffset(rx.roundToInt(), ry.roundToInt()) }
                        .size(px2dp(rw), px2dp(rh))
                        .padding(6.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Accent.copy(alpha = 0.22f)),
                )
            }

            if (layout.items.isEmpty() && drag.pkg == null) {
                Text(
                    "Todavía no hay apps acá.\nMantené apretada una app en el cajón y elegí «Agregar a inicio».",
                    color = Dim,
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(32.dp),
                )
            }

            val dragged = drag.pkg?.let { byPkg[it] }
            if (dragged != null) {
                val over = drag.pos.y < geo.removeH
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 4.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (over) Color(0xFFD32F2F) else Card)
                        .padding(horizontal = 18.dp, vertical = 6.dp),
                ) {
                    Text("Quitar", color = if (over) Color.White else Ink, fontSize = 13.sp)
                }
                Box(
                    Modifier
                        .offset {
                            IntOffset(
                                (drag.pos.x - cellW / 2f).roundToInt(),
                                (drag.pos.y - cellH / 2f).roundToInt(),
                            )
                        }
                        .size(cellWdp, cellHdp)
                        .graphicsLayer {
                            scaleX = 1.12f
                            scaleY = 1.12f
                            alpha = 0.96f
                        },
                ) {
                    HomeIcon(dragged, iconDp, settings.homeLabels, settings.homeLabelSize)
                }
            }
        }
    }
}
