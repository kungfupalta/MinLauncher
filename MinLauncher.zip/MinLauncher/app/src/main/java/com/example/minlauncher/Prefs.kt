package com.example.minlauncher

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    // ---- Primera vez ------------------------------------------------------
    fun isOnboarded(c: Context): Boolean = sp(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) { sp(c).edit().putBoolean("onboarded", v).apply() }

    // ---- Apps de inicio ---------------------------------------------------
    /** null = nunca configurado (primera vez). */
    fun getPinned(c: Context): List<String>? =
        sp(c).getString("pinned", null)?.let { if (it.isEmpty()) emptyList() else it.split("|") }

    fun setPinned(c: Context, list: List<String>) {
        sp(c).edit().putString("pinned", list.joinToString("|")).apply()
    }

    // ---- Estilo de iconos -------------------------------------------------
    fun getStyle(c: Context): IconStyle {
        val p = sp(c)
        val shape = try {
            IconShape.valueOf(p.getString("shape", IconShape.Squircle.name)!!)
        } catch (_: Exception) { IconShape.Squircle }
        return IconStyle(
            sizeDp = p.getInt("iconSize", 62),
            shape = shape,
            themed = p.getBoolean("themed", true),
        )
    }

    fun setStyle(c: Context, st: IconStyle) {
        sp(c).edit()
            .putInt("iconSize", st.sizeDp)
            .putString("shape", st.shape.name)
            .putBoolean("themed", st.themed)
            .apply()
    }

    // ---- Nombres personalizados: paquete -> nombre -------------------------
    fun getLabels(c: Context): Map<String, String> {
        val s = sp(c).getString("labels", null) ?: return emptyMap()
        return try {
            val o = JSONObject(s)
            o.keys().asSequence().associateWith { o.getString(it) }
        } catch (_: Exception) { emptyMap() }
    }

    fun setLabels(c: Context, map: Map<String, String>) {
        sp(c).edit().putString("labels", JSONObject(map).toString()).apply()
    }

    // ---- Apps ocultas -----------------------------------------------------
    fun getHidden(c: Context): Set<String> =
        sp(c).getStringSet("hidden", emptySet())?.toSet() ?: emptySet()

    fun setHidden(c: Context, set: Set<String>) {
        sp(c).edit().putStringSet("hidden", set.toSet()).apply()
    }

    // ---- Uso (todo queda en el teléfono) -----------------------------------
    fun getUsage(c: Context): Map<String, Int> {
        val s = sp(c).getString("usage", null) ?: return emptyMap()
        return try {
            val o = JSONObject(s)
            o.keys().asSequence().associateWith { o.getInt(it) }
        } catch (_: Exception) { emptyMap() }
    }

    fun bumpUsage(c: Context, pkg: String) {
        val m = getUsage(c).toMutableMap()
        m[pkg] = (m[pkg] ?: 0) + 1
        sp(c).edit().putString("usage", JSONObject(m).toString()).apply()
    }

    // ---- Ajustes ----------------------------------------------------------
    fun getSettings(c: Context): LauncherSettings {
        val p = sp(c)
        val d = LauncherSettings()
        val theme = try {
            ThemeMode.valueOf(p.getString("theme", d.theme.name) ?: d.theme.name)
        } catch (_: Exception) { d.theme }
        return LauncherSettings(
            theme = theme,
            accent = p.getInt("accent", d.accent),
            dim = p.getFloat("dim", d.dim),
            showClock = p.getBoolean("showClock", d.showClock),
            clockSize = p.getInt("clockSize", d.clockSize),
            clockFormat = p.getInt("clockFormat", d.clockFormat),
            showDate = p.getBoolean("showDate", d.showDate),
            showWorldClocks = p.getBoolean("showWorldClocks", d.showWorldClocks),
            centerHome = p.getBoolean("centerHome", d.centerHome),
            homeTextSize = p.getInt("homeTextSize", d.homeTextSize),
            maxPinned = p.getInt("maxPinned", d.maxPinned),
            hideStatusBar = p.getBoolean("hideStatusBar", d.hideStatusBar),
            drawerList = p.getBoolean("drawerList", d.drawerList),
            drawerIndex = p.getBoolean("drawerIndex", d.drawerIndex),
            drawerFrequent = p.getBoolean("drawerFrequent", d.drawerFrequent),
            drawerKeyboard = p.getBoolean("drawerKeyboard", d.drawerKeyboard),
            autoLaunch = p.getBoolean("autoLaunch", d.autoLaunch),
            gestures = GestureSlot.entries.associateWith { p.getString(it.key, it.default) ?: it.default },
        )
    }

    fun setSettings(c: Context, s: LauncherSettings) {
        val e = sp(c).edit()
            .putString("theme", s.theme.name)
            .putInt("accent", s.accent)
            .putFloat("dim", s.dim)
            .putBoolean("showClock", s.showClock)
            .putInt("clockSize", s.clockSize)
            .putInt("clockFormat", s.clockFormat)
            .putBoolean("showDate", s.showDate)
            .putBoolean("showWorldClocks", s.showWorldClocks)
            .putBoolean("centerHome", s.centerHome)
            .putInt("homeTextSize", s.homeTextSize)
            .putInt("maxPinned", s.maxPinned)
            .putBoolean("hideStatusBar", s.hideStatusBar)
            .putBoolean("drawerList", s.drawerList)
            .putBoolean("drawerIndex", s.drawerIndex)
            .putBoolean("drawerFrequent", s.drawerFrequent)
            .putBoolean("drawerKeyboard", s.drawerKeyboard)
            .putBoolean("autoLaunch", s.autoLaunch)
        for ((slot, value) in s.gestures) e.putString(slot.key, value)
        e.apply()
    }

    // ---- Copia de seguridad (JSON legible, sin nada raro) -------------------
    fun exportJson(c: Context): String {
        val data = JSONObject()
        for ((k, v) in sp(c).all) {
            val o = JSONObject()
            when (v) {
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Set<*> -> { o.put("t", "ss"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            data.put(k, o)
        }
        return JSONObject()
            .put("app", "MinLauncher")
            .put("version", 1)
            .put("data", data)
            .toString(2)
    }

    /** Reemplaza todos los ajustes por los de la copia. Devuelve false si el archivo no sirve. */
    fun importJson(c: Context, text: String): Boolean {
        return try {
            val root = JSONObject(text)
            if (root.optString("app") != "MinLauncher") return false
            val data = root.getJSONObject("data")
            val e = sp(c).edit().clear()
            for (k in data.keys()) {
                val o = data.getJSONObject(k)
                when (o.getString("t")) {
                    "s" -> e.putString(k, o.getString("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "l" -> e.putLong(k, o.getLong("v"))
                    "ss" -> {
                        val a = o.getJSONArray("v")
                        e.putStringSet(k, (0 until a.length()).map { a.getString(it) }.toSet())
                    }
                    else -> {}
                }
            }
            e.putBoolean("onboarded", true)
            e.apply()
            true
        } catch (_: Exception) {
            false
        }
    }
}
