package com.example.minlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

/**
 * Hace dos cosas, ninguna lee lo que hay en tu pantalla:
 *  1) Bloquear la pantalla (doble toque u otro gesto).
 *  2) Opcional: cuando Samsung abre su pantalla de recientes, la cierra y abre la Multitarea de MinLauncher.
 */
class LockService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastTrigger = 0L

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: return
        if (pkg == packageName) return
        if (pkg !in RECENTS_HOSTS) return
        if (!cls.contains("Recents", ignoreCase = true)) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < 1500L) return
        if (!Prefs.getConfig(this).interceptRecents) return
        if (!isDefaultLauncher(this)) return

        lastTrigger = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({ LauncherBus.recentsTick++ }, 250L)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        var instance: LockService? = null
            private set

        private val RECENTS_HOSTS = setOf(
            "com.sec.android.app.launcher",
            "com.android.systemui",
            "com.google.android.apps.nexuslauncher",
            "com.android.launcher3",
        )

        fun lock(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ?: false
    }
}
