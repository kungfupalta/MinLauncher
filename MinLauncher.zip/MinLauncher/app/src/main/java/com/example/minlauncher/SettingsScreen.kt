package com.example.minlauncher

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

// ---- Piezas compartidas (también las usa la bienvenida) --------------------
@Composable
internal fun OptionChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) OnAccent else Ink,
        fontSize = 15.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) Accent else CardHi)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
    )
}

@Composable
internal fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEachIndexed { i, o -> OptionChip(o, i == selected) { onSelect(i) } }
    }
}

@Composable
internal fun Swatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(color)
            .then(if (selected) Modifier.border(3.dp, Ink, CircleShape) else Modifier)
            .clickable(onClick = onClick),
    )
}

@Composable
internal fun AccentPicker(settings: LauncherSettings, onSettings: (LauncherSettings) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AccentPresets.forEachIndexed { i, p ->
            Swatch(p.ui, settings.accent == i) { onSettings(settings.copy(accent = i)) }
        }
        OptionChip("Sistema", settings.accent == AccentSystem) {
            onSettings(settings.copy(accent = AccentSystem))
        }
        OptionChip("Personalizado", settings.accent == AccentCustom) {
            onSettings(settings.copy(accent = AccentCustom))
        }
    }
    if (settings.accent == AccentCustom) {
        val c = Color(settings.customAccent)
        val r = (c.red * 255).roundToInt()
        val g = (c.green * 255).roundToInt()
        val b = (c.blue * 255).roundToInt()
        fun setRgb(nr: Int, ng: Int, nb: Int) {
            onSettings(settings.copy(customAccent = Color(nr / 255f, ng / 255f, nb / 255f).toArgb()))
        }
        SliderRow("Rojo", "$r", r.toFloat(), 0f..255f) { setRgb(it.roundToInt(), g, b) }
        SliderRow("Verde", "$g", g.toFloat(), 0f..255f) { setRgb(r, it.roundToInt(), b) }
        SliderRow("Azul", "$b", b.toFloat(), 0f..255f) { setRgb(r, g, it.roundToInt()) }
    }
}

@Composable
internal fun SubTitle(text: String) {
    Text(
        text,
        color = Accent,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 14.dp, bottom = 2.dp),
    )
}

@Composable
internal fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        color = Accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(start = 6.dp, top = 22.dp, bottom = 8.dp),
    )
}

@Composable
internal fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Card)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        content = content,
    )
}

@Composable
internal fun SwitchRow(
    title: String,
    subtitle: String? = null,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 16.sp)
            if (subtitle != null) Text(subtitle, color = Dim, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = OnAccent,
                checkedTrackColor = Accent,
                uncheckedThumbColor = Dim,
                uncheckedTrackColor = CardHi,
                uncheckedBorderColor = Dim,
            ),
        )
    }
}

@Composable
internal fun SliderRow(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Ink, fontSize = 16.sp)
            Text(valueLabel, color = Accent, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = CardHi,
            ),
        )
    }
}

@Composable
internal fun ActionRow(title: String, subtitle: String? = null, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
    ) {
        Text(title, color = Ink, fontSize = 16.sp)
        if (subtitle != null) Text(subtitle, color = Dim, fontSize = 13.sp)
    }
}

@Composable
internal fun PrimaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(26.dp))
            .background(Accent)
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = OnAccent, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
internal fun TextAction(text: String, onClick: () -> Unit) {
    Text(
        text,
        color = Accent,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

/** Devuelve una función que muestra el diálogo oficial de Android para elegir MinLauncher como app de inicio. */
@Composable
fun rememberSetDefaultLauncher(): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    return remember(launcher) {
        {
            val i = defaultLauncherIntent(ctx)
            try {
                if (i != null) launcher.launch(i) else openHomeSettings(ctx)
            } catch (_: Exception) {
                openHomeSettings(ctx)
            }
        }
    }
}

// ---- Gestos ---------------------------------------------------------------
@Composable
internal fun GestureRow(
    slot: GestureSlot,
    settings: LauncherSettings,
    apps: List<AppInfo>,
    onSettings: (LauncherSettings) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    ActionRow(slot.label, gestureLabel(settings.gesture(slot), apps)) { open = true }
    if (open) {
        GesturePicker(
            slot = slot,
            current = settings.gesture(slot),
            apps = apps,
            onPick = {
                onSettings(settings.copy(gestures = settings.gestures + (slot to it)))
                open = false
            },
            onDismiss = { open = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GesturePicker(
    slot: GestureSlot,
    current: String,
    apps: List<AppInfo>,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var pickingApp by remember { mutableStateOf(false) }
    val isLong = slot == GestureSlot.LongPress
    // "Mantener apretado" siempre abre el editor o los ajustes: así nunca perdés el acceso
    val options = if (isLong) {
        GestureOptions.filter { it.first == Gesture.EDIT || it.first == Gesture.SETTINGS }
    } else GestureOptions

    if (pickingApp) {
        ModalBottomSheet(
            onDismissRequest = { pickingApp = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = SheetBg,
            contentColor = Ink,
        ) {
            AppPicker(apps, emptySet(), "Elegí una app", null) { onPick(Gesture.APP_PREFIX + it.pkg) }
        }
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Card,
            title = { Text(slot.label, color = Ink, fontWeight = FontWeight.Light) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    options.forEach { (id, label) ->
                        PickerRow(label, id == current) { onPick(id) }
                    }
                    if (!isLong) {
                        PickerRow("Abrir una app…", current.startsWith(Gesture.APP_PREFIX)) {
                            pickingApp = true
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar", color = Dim) } },
        )
    }
}

@Composable
private fun PickerRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (selected) Accent else Color.Transparent),
        )
        Spacer(Modifier.width(14.dp))
        Text(label, color = Ink, fontSize = 16.sp)
    }
}

// ---- Apps ocultas -----------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HiddenAppsSheet(
    apps: List<AppInfo>,
    hidden: Set<String>,
    onHidden: (Set<String>) -> Unit,
    onDismiss: () -> Unit,
) {
    var q by remember { mutableStateOf("") }
    val list = remember(apps, q) { apps.filter { matchesQuery(it.label, q) } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetBg,
        contentColor = Ink,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.88f)
                .padding(horizontal = 20.dp),
        ) {
            Text("Apps ocultas", fontSize = 22.sp, fontWeight = FontWeight.Light)
            Text(
                "No aparecen en el cajón ni en la búsqueda",
                color = Dim,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp),
            )
            SearchField(q, { q = it }, {})
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.fillMaxWidth()) {
                items(list, key = { it.component.flattenToString() }) { app ->
                    val isHidden = app.pkg in hidden
                    val toggle = { onHidden(if (isHidden) hidden - app.pkg else hidden + app.pkg) }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { toggle() }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppIcon(app, 40.dp)
                        Spacer(Modifier.width(16.dp))
                        Text(app.label, color = Ink, fontSize = 17.sp, maxLines = 1, modifier = Modifier.weight(1f))
                        Switch(
                            checked = isHidden,
                            onCheckedChange = { toggle() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = OnAccent,
                                checkedTrackColor = Accent,
                                uncheckedThumbColor = Dim,
                                uncheckedTrackColor = CardHi,
                                uncheckedBorderColor = Dim,
                            ),
                        )
                    }
                }
            }
        }
    }
}

// ---- Pantalla de ajustes ------------------------------------------------------
@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    style: IconStyle,
    onStyle: (IconStyle) -> Unit,
    apps: List<AppInfo>,
    hidden: Set<String>,
    onHidden: (Set<String>) -> Unit,
    isDefault: Boolean,
    onSetDefault: () -> Unit,
    onBack: () -> Unit,
) {
    val ctx = LocalContext.current
    var showHidden by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }

    BackHandler { onBack() }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) {
            val ok = try {
                ctx.contentResolver.openOutputStream(uri)?.use {
                    it.write(Prefs.exportJson(ctx).toByteArray(Charsets.UTF_8))
                } != null
            } catch (_: Exception) { false }
            toast(ctx, if (ok) "Copia guardada" else "No se pudo guardar la copia")
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            val text = try {
                ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } catch (_: Exception) { null }
            if (text != null && Prefs.importJson(ctx, text)) {
                toast(ctx, "Ajustes importados")
                (ctx as? Activity)?.recreate()
            } else {
                toast(ctx, "El archivo no es una copia válida de MinLauncher")
            }
        }
    }

    @Suppress("DEPRECATION")
    val versionName = remember {
        try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(SheetBg)
            .pointerInput(Unit) {} // evita que los toques lleguen al inicio que está detrás
            .windowInsetsPadding(safeInsets())
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 40.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
            Spacer(Modifier.width(14.dp))
            Text("Ajustes", color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Light)
        }

        // -- Launcher predeterminado
        SectionTitle("Launcher predeterminado")
        SettingsCard {
            Text(
                if (isDefault) "MinLauncher es tu launcher predeterminado."
                else "Todavía no es tu launcher predeterminado: el botón Inicio abre otro launcher.",
                color = Ink,
                fontSize = 15.sp,
                lineHeight = 21.sp,
            )
            Spacer(Modifier.height(12.dp))
            if (isDefault) {
                TextAction("Cambiar launcher…") { openHomeSettings(ctx) }
            } else {
                PrimaryButton("Establecer como predeterminado", Modifier.fillMaxWidth(), onSetDefault)
            }
        }

        // -- Apariencia
        SectionTitle("Apariencia")
        SettingsCard {
            Text("Tema", color = Ink, fontSize = 16.sp)
            ChipRow(ThemeMode.entries.map { it.label }, settings.theme.ordinal) {
                onSettings(settings.copy(theme = ThemeMode.entries[it]))
            }
            Spacer(Modifier.height(6.dp))
            Text("Color de acento", color = Ink, fontSize = 16.sp)
            AccentPicker(settings, onSettings)
            SliderRow(
                "Oscurecer el fondo",
                if (settings.dim >= 0.995f) "Negro" else "${(settings.dim * 100).roundToInt()}%",
                settings.dim,
                0f..1f,
            ) { onSettings(settings.copy(dim = it)) }
            Text("Tipografía del inicio", color = Ink, fontSize = 16.sp)
            ChipRow(HomeFonts, settings.homeFont) { onSettings(settings.copy(homeFont = it)) }
        }

        // -- Iconos
        SectionTitle("Iconos")
        SettingsCard {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                apps.take(4).forEach { AppIcon(it, style.sizeDp.coerceAtMost(72).dp) }
            }
            SliderRow("Tamaño", "${style.sizeDp}", style.sizeDp.toFloat(), 44f..88f) {
                onStyle(style.copy(sizeDp = it.roundToInt()))
            }
            Text("Forma", color = Ink, fontSize = 16.sp)
            ChipRow(IconShape.entries.map { it.label }, style.shape.ordinal) {
                onStyle(style.copy(shape = IconShape.entries[it]))
            }
            SwitchRow(
                "Iconos temáticos",
                "Del color de acento, con el símbolo oscuro",
                style.themed,
            ) { onStyle(style.copy(themed = it)) }
        }

        // -- Reloj
        SectionTitle("Reloj")
        SettingsCard {
            SwitchRow("Mostrar reloj", checked = settings.showClock) {
                onSettings(settings.copy(showClock = it))
            }
            if (settings.showClock) {
                SliderRow("Tamaño", "${settings.clockSize}", settings.clockSize.toFloat(), MIN_CLOCK_SP..MAX_CLOCK_SP) {
                    onSettings(settings.copy(clockSize = it.roundToInt()))
                }
                Text(
                    "También lo podés agrandar o achicar pellizcándolo con dos dedos en el inicio.",
                    color = Dim,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
                SubTitle("Estilo")
                Text("Grosor", color = Ink, fontSize = 16.sp)
                ChipRow(FontWeights, settings.clockWeight) { onSettings(settings.copy(clockWeight = it)) }
                Text("Color de la hora", color = Ink, fontSize = 16.sp)
                ChipRow(listOf("Texto", "Acento"), settings.clockColor) {
                    onSettings(settings.copy(clockColor = it))
                }
                SwitchRow("Horas y minutos en dos líneas", checked = settings.clockStacked) {
                    onSettings(settings.copy(clockStacked = it))
                }
                Text("Formato de hora", color = Ink, fontSize = 16.sp)
                ChipRow(listOf("Sistema", "24 h", "12 h"), settings.clockFormat) {
                    onSettings(settings.copy(clockFormat = it))
                }
            }
            SubTitle("Debajo de la hora")
            SwitchRow("Mostrar fecha", checked = settings.showDate) {
                onSettings(settings.copy(showDate = it))
            }
            if (settings.showDate) {
                ChipRow(listOf("Completa", "Abreviada", "Numérica", "Solo el día"), settings.dateFormat) {
                    onSettings(settings.copy(dateFormat = it))
                }
            }
            SwitchRow("Mostrar batería", "El porcentaje, junto a la fecha", settings.showBattery) {
                onSettings(settings.copy(showBattery = it))
            }
            SwitchRow("Mostrar próxima alarma", "Si tenés una alarma programada", settings.showAlarm) {
                onSettings(settings.copy(showAlarm = it))
            }
        }

        // -- Horas de otras personas
        SectionTitle("Horas de otras personas")
        SettingsCard {
            WorldClockToggles(settings, onSettings)
            SliderRow("Tamaño", "${settings.worldClockSize}", settings.worldClockSize.toFloat(), MIN_SMALL_SP..MAX_SMALL_SP) {
                onSettings(settings.copy(worldClockSize = it.roundToInt()))
            }
            Text(
                "También se agrandan o achican pellizcándolas con dos dedos en el inicio.",
                color = Dim,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }

        // -- Pantalla de inicio
        SectionTitle("Pantalla de inicio")
        SettingsCard {
            Text("Estilo de las apps", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Lista de texto", "Iconos"), settings.homeStyle) {
                onSettings(settings.copy(homeStyle = it))
            }
            if (settings.homeStyle == 1) {
                SliderRow("Columnas", "${settings.homeColumns}", settings.homeColumns.toFloat(), 2f..6f) {
                    onSettings(settings.copy(homeColumns = it.roundToInt()))
                }
                SwitchRow("Mostrar nombres", checked = settings.homeLabels) {
                    onSettings(settings.copy(homeLabels = it))
                }
            } else {
                SwitchRow("Iconos junto a los nombres", checked = settings.homeIcons) {
                    onSettings(settings.copy(homeIcons = it))
                }
                Text("Grosor del texto", color = Ink, fontSize = 16.sp)
                ChipRow(FontWeights, settings.homeWeight) { onSettings(settings.copy(homeWeight = it)) }
                SliderRow("Tamaño del texto", "${settings.homeTextSize}", settings.homeTextSize.toFloat(), 18f..40f) {
                    onSettings(settings.copy(homeTextSize = it.roundToInt()))
                }
            }
            SubTitle("Distribución")
            Text("Alineación", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Izquierda", "Centro"), if (settings.centerHome) 1 else 0) {
                onSettings(settings.copy(centerHome = it == 1))
            }
            Text("Posición del reloj", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Arriba", "Centro"), settings.clockPosition) {
                onSettings(settings.copy(clockPosition = it))
            }
            Text("Posición de las apps", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Abajo", "Centro"), settings.appsPosition) {
                onSettings(settings.copy(appsPosition = it))
            }
            SliderRow("Margen lateral", "${settings.homeMargin}", settings.homeMargin.toFloat(), 8f..64f) {
                onSettings(settings.copy(homeMargin = it.roundToInt()))
            }
            SliderRow("Máximo de apps en inicio", "${settings.maxPinned}", settings.maxPinned.toFloat(), 3f..10f) {
                onSettings(settings.copy(maxPinned = it.roundToInt()))
            }
            SwitchRow("Barra de búsqueda", "Una barra en el inicio que abre el cajón para buscar", settings.homeSearchBar) {
                onSettings(settings.copy(homeSearchBar = it))
            }
            SwitchRow(
                "Bloquear el diseño",
                "Evita cambiar las apps de inicio sin querer",
                settings.lockLayout,
            ) { onSettings(settings.copy(lockLayout = it)) }
            ActionRow("Cambiar fondo de pantalla") { pickWallpaper(ctx) }
        }

        // -- Cajón de apps
        SectionTitle("Cajón de apps")
        SettingsCard {
            Text("Vista", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Cuadrícula", "Lista"), if (settings.drawerList) 1 else 0) {
                onSettings(settings.copy(drawerList = it == 1))
            }
            if (!settings.drawerList) {
                Text("Columnas", color = Ink, fontSize = 16.sp)
                ChipRow(
                    listOf("Auto", "3", "4", "5", "6"),
                    if (settings.drawerColumns == 0) 0 else (settings.drawerColumns - 2).coerceIn(1, 4),
                ) { onSettings(settings.copy(drawerColumns = if (it == 0) 0 else it + 2)) }
                SwitchRow("Mostrar nombres", checked = settings.drawerLabels) {
                    onSettings(settings.copy(drawerLabels = it))
                }
                if (settings.drawerLabels) {
                    SliderRow("Tamaño de los nombres", "${settings.drawerLabelSize}", settings.drawerLabelSize.toFloat(), 10f..16f) {
                        onSettings(settings.copy(drawerLabelSize = it.roundToInt()))
                    }
                }
            }
            SliderRow(
                "Opacidad del fondo",
                "${(settings.drawerOpacity * 100).roundToInt()}%",
                settings.drawerOpacity,
                0.4f..1f,
            ) { onSettings(settings.copy(drawerOpacity = it)) }
            SwitchRow("Buscador arriba", "Por defecto está abajo, cerca del pulgar", settings.drawerSearchTop) {
                onSettings(settings.copy(drawerSearchTop = it))
            }
            SwitchRow("Índice alfabético", "Letras al costado para saltar rápido", settings.drawerIndex) {
                onSettings(settings.copy(drawerIndex = it))
            }
            SwitchRow("Más usadas", "Tus apps más abiertas, arriba de todo", settings.drawerFrequent) {
                onSettings(settings.copy(drawerFrequent = it))
            }
            SwitchRow("Abrir el teclado al entrar", checked = settings.drawerKeyboard) {
                onSettings(settings.copy(drawerKeyboard = it))
            }
            SwitchRow(
                "Abrir directo con un solo resultado",
                "Al buscar, abre la app si es la única que coincide",
                settings.autoLaunch,
            ) { onSettings(settings.copy(autoLaunch = it)) }
            ActionRow("Apps ocultas", "${hidden.size} ocultas") { showHidden = true }
        }

        // -- Sistema
        SectionTitle("Sistema")
        SettingsCard {
            Text("Orientación de la pantalla", color = Ink, fontSize = 16.sp)
            ChipRow(listOf("Automática", "Vertical", "Horizontal"), settings.orientation) {
                onSettings(settings.copy(orientation = it))
            }
            SwitchRow("Animaciones", "Desactivarlas hace el launcher más directo", settings.animations) {
                onSettings(settings.copy(animations = it))
            }
            SwitchRow("Ocultar la barra de estado", checked = settings.hideStatusBar) {
                onSettings(settings.copy(hideStatusBar = it))
            }
        }

        // -- Gestos
        SectionTitle("Gestos")
        SettingsCard {
            GestureSlot.entries.forEach { GestureRow(it, settings, apps, onSettings) }
            Spacer(Modifier.height(6.dp))
            Text(
                "«Bloquear pantalla» necesita activar MinLauncher en Accesibilidad. Es opcional y solo " +
                    "se usa para apagar la pantalla. Si Android lo bloquea, entrá a Info de la app y " +
                    "permití los ajustes restringidos.",
                color = Dim,
                fontSize = 12.sp,
                lineHeight = 18.sp,
            )
        }

        // -- Copia de seguridad
        SectionTitle("Copia de seguridad")
        SettingsCard {
            ActionRow("Exportar ajustes", "Guarda un archivo con tu configuración") {
                exportLauncher.launch("minlauncher-ajustes.json")
            }
            ActionRow("Importar ajustes", "Restaura una copia guardada antes") {
                importLauncher.launch(arrayOf("*/*"))
            }
            ActionRow("Restablecer ajustes", "Vuelve todo a los valores de fábrica (no toca tus apps)") {
                confirmReset = true
            }
        }

        // -- Acerca de
        SectionTitle("Acerca de")
        SettingsCard {
            Text("MinLauncher $versionName", color = Ink, fontSize = 17.sp)
            Text(
                "Software libre, licencia ${About.LICENSE_NAME}. Sin publicidad, sin rastreo y sin " +
                    "permiso de internet: todo queda en tu teléfono.",
                color = Dim,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 6.dp),
            )
            ActionRow("Código fuente") { openUrl(ctx, About.REPO_URL) }
            ActionRow("Reportar un problema o sugerir algo") { openUrl(ctx, About.REPO_URL + "/issues") }
        }
    }

    if (showHidden) {
        HiddenAppsSheet(apps, hidden, onHidden) { showHidden = false }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = Card,
            title = { Text("Restablecer ajustes", color = Ink, fontWeight = FontWeight.Light) },
            text = {
                Text(
                    "Todos los ajustes y el estilo de iconos vuelven a los valores de fábrica. " +
                        "Tus apps de inicio, nombres y apps ocultas se mantienen.",
                    color = Dim,
                    fontSize = 14.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    Prefs.resetSettings(ctx)
                    (ctx as? Activity)?.recreate()
                }) { Text("Restablecer", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancelar", color = Dim) }
            },
        )
    }
}
