package com.example.minlauncher

import java.text.Normalizer

private val Diacritics = Regex("\\p{InCombiningDiacriticalMarks}+")

/** Minúsculas y sin tildes: "Cámara" -> "camara". Así se busca igual con o sin acentos. */
fun normalize(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD).replace(Diacritics, "").lowercase()

/**
 * Coincide si todas las palabras de la búsqueda aparecen en el nombre,
 * o si la búsqueda son las iniciales ("gm" encuentra "Google Maps").
 */
fun matchesQuery(label: String, query: String): Boolean {
    val q = normalize(query.trim())
    if (q.isEmpty()) return true
    val l = normalize(label)
    val words = q.split(' ').filter { it.isNotEmpty() }
    if (words.all { l.contains(it) }) return true
    val initials = l.split(' ', '-', '.', '_')
        .filter { it.isNotEmpty() }
        .joinToString("") { it.take(1) }
    return initials.startsWith(q)
}

/** Letra del índice alfabético del cajón; todo lo que no es A-Z va bajo '#'. */
fun indexLetter(label: String): Char {
    val c = normalize(label.trim()).firstOrNull() ?: return '#'
    return if (c in 'a'..'z') c.uppercaseChar() else '#'
}
