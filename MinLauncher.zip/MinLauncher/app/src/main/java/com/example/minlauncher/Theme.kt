package com.example.minlauncher

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Todos los colores de la interfaz. Hay una paleta oscura y una clara. */
data class Palette(
    val dark: Boolean,
    val accent: Color,
    val onAccent: Color,
    val ink: Color,
    val dim: Color,
    val card: Color,
    val cardHi: Color,
    val sheet: Color,
    val drawer: Color,
    /** Color del velo que se pone sobre el fondo de pantalla. */
    val scrim: Color,
)

val DarkPalette = Palette(
    dark = true,
    accent = Color(0xFF72B8EE),
    onAccent = Color(0xFF0B1D2E),
    ink = Color(0xFFF2F2F5),
    dim = Color(0xFF8E8E99),
    card = Color(0xFF1F2023),
    cardHi = Color(0xFF2C2D31),
    sheet = Color(0xFF17181B),
    drawer = Color(0xF2090A0D),
    scrim = Color.Black,
)

val LightPalette = Palette(
    dark = false,
    accent = Color(0xFF2583CC),
    onAccent = Color.White,
    ink = Color(0xFF15161A),
    dim = Color(0xFF6B6D78),
    card = Color(0xFFEDEEF2),
    cardHi = Color(0xFFDFE1E8),
    sheet = Color(0xFFF7F8FA),
    drawer = Color(0xF2F7F8FA),
    scrim = Color.White,
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

// Se usan en toda la interfaz como si fueran constantes, pero siguen el tema elegido.
val Accent: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.accent
val OnAccent: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.onAccent
val Ink: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.ink
val Dim: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.dim
val Card: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.card
val CardHi: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.cardHi
val SheetBg: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.sheet
val DrawerBg: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.drawer

fun buildPalette(ctx: android.content.Context, dark: Boolean, accentIndex: Int): Palette {
    val base = if (dark) DarkPalette else LightPalette
    val preset = AccentPresets.getOrNull(accentIndex)
    if (preset != null) {
        return if (dark) base.copy(accent = preset.ui, onAccent = Color(0xFF0B1D2E))
        else base.copy(accent = preset.iconBg, onAccent = Color.White)
    }
    // Colores del sistema (Material You)
    val scheme = if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    return base.copy(accent = scheme.primary, onAccent = scheme.onPrimary)
}

@Composable
fun LauncherTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (settings.theme) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Dark -> true
        ThemeMode.Light -> false
    }
    val palette = remember(dark, settings.accent) { buildPalette(ctx, dark, settings.accent) }
    val scheme = if (dark) {
        darkColorScheme(primary = palette.accent, background = Color.Black, surface = palette.sheet)
    } else {
        lightColorScheme(primary = palette.accent, background = Color.White, surface = palette.sheet)
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Iconos de la barra de estado claros u oscuros según el tema, y opción de ocultarla. */
@Composable
fun SystemBarsEffect(dark: Boolean, hideStatusBar: Boolean) {
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (hideStatusBar) c.hide(WindowInsetsCompat.Type.statusBars())
        else c.show(WindowInsetsCompat.Type.statusBars())
    }
}
