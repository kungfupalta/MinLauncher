package com.example.minlauncher

import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Todos los colores de la interfaz. Hay una paleta oscura y una clara. */
data class Palette(
    val dark: Boolean,
    val accent: Color,
    val onAccent: Color,
    val ink: Color,
    val dim: Color,
    val card: Color,
    val cardHi: Color,
    val sheet: Color,
    val drawer: Color,
    /** Color del velo que se pone sobre el fondo de pantalla. */
    val scrim: Color,
)

/** Oscuro: fondo negro y tarjetas gris oscuro, como One UI. */
val DarkPalette = Palette(
    dark = true,
    accent = Color(0xFF5BA0FF),
    onAccent = Color(0xFF001B3D),
    ink = Color(0xFFF5F5F7),
    dim = Color(0xFF9C9CA3),
    card = Color(0xFF1C1C1E),
    cardHi = Color(0xFF2C2C2E),
    sheet = Color(0xFF000000),
    drawer = Color(0xF2000000),
    scrim = Color.Black,
)

/** Claro: fondo gris muy suave y tarjetas blancas bien redondeadas, como One UI. */
val LightPalette = Palette(
    dark = false,
    accent = Color(0xFF3E91FF),
    onAccent = Color.White,
    ink = Color(0xFF111113),
    dim = Color(0xFF6E6E73),
    card = Color(0xFFFFFFFF),
    cardHi = Color(0xFFEEEFF2),
    sheet = Color(0xFFF4F4F6),
    drawer = Color(0xF2F4F4F6),
    scrim = Color.White,
)

val LocalPalette = staticCompositionLocalOf { DarkPalette }

// Se usan en toda la interfaz como si fueran constantes, pero siguen el tema elegido.
val Accent: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.accent
val OnAccent: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.onAccent
val Ink: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.ink
val Dim: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.dim
val Card: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.card
val CardHi: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.cardHi
val SheetBg: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.sheet
val DrawerBg: Color
    @Composable @ReadOnlyComposable get() = LocalPalette.current.drawer

val HomeFonts = listOf("Predeterminada", "Serif", "Monoespaciada", "Cursiva")
val FontWeights = listOf("Fino", "Liviano", "Normal", "Negrita")

fun fontFor(i: Int): FontFamily = when (i) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    3 -> FontFamily.Cursive
    else -> FontFamily.Default
}

fun weightFor(i: Int): FontWeight = when (i) {
    0 -> FontWeight.Thin
    1 -> FontWeight.Light
    2 -> FontWeight.Normal
    else -> FontWeight.Bold
}

fun buildPalette(ctx: android.content.Context, dark: Boolean, accentIndex: Int, customAccent: Int): Palette {
    val base = if (dark) DarkPalette else LightPalette
    val preset = AccentPresets.getOrNull(accentIndex)
    if (preset != null) {
        return if (dark) base.copy(accent = preset.ui, onAccent = Color(0xFF0B1D2E))
        else base.copy(accent = preset.iconBg, onAccent = Color.White)
    }
    if (accentIndex == AccentCustom) {
        val c = Color(customAccent)
        return base.copy(
            accent = c,
            onAccent = if (c.luminance() > 0.5f) Color(0xFF0B1D2E) else Color.White,
        )
    }
    // Colores del sistema (Material You)
    val scheme = if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    return base.copy(accent = scheme.primary, onAccent = scheme.onPrimary)
}

@Composable
fun LauncherTheme(settings: LauncherSettings, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = when (settings.theme) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Dark -> true
        ThemeMode.Light -> false
    }
    val palette = remember(dark, settings.accent, settings.customAccent) {
        buildPalette(ctx, dark, settings.accent, settings.customAccent)
    }
    val scheme = if (dark) {
        darkColorScheme(primary = palette.accent, background = Color.Black, surface = palette.sheet)
    } else {
        lightColorScheme(primary = palette.accent, background = Color.White, surface = palette.sheet)
    }
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

/** Iconos de la barra de estado claros u oscuros según el tema, ocultarla y bloquear la orientación. */
@Composable
fun SystemBarsEffect(dark: Boolean, hideStatusBar: Boolean, orientation: Int) {
    val view = LocalView.current
    SideEffect {
        val activity = view.context as? Activity ?: return@SideEffect
        activity.requestedOrientation = when (orientation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val c = WindowCompat.getInsetsController(activity.window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (hideStatusBar) c.hide(WindowInsetsCompat.Type.statusBars())
        else c.show(WindowInsetsCompat.Type.statusBars())
    }
}
