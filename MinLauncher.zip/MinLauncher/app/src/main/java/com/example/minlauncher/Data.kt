package com.example.minlauncher

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

// ---------------------------------------------------------------------------
// Modelos
// ---------------------------------------------------------------------------

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val original: String = label,
)

enum class IconShape(val label: String) {
    Squircle("Squircle"),
    Circle("Círculo"),
    Rounded("Redondeado"),
    Square("Cuadrado"),
}

enum class HomeStyle(val label: String) {
    OneUI("One UI"),
    Classic("Clásico"),
    Centered("Centrado"),
    Icons("Con iconos"),
}

enum class ClockStyle(val label: String) {
    Thin("Fino"),
    Bold("Grueso"),
    Serif("Serif"),
    Mono("Mono"),
}

enum class BgStyle(val label: String) {
    Wallpaper("Mi fondo"),
    Black("Negro"),
    Gradient("Degradado"),
}

enum class DrawerAnim(val label: String) {
    Slide("Deslizar"),
    Zoom("Zoom"),
    Fade("Desvanecer"),
}

enum class GestureAction(val label: String) {
    None("Nada"),
    Drawer("Abrir el cajón de apps"),
    Notifications("Notificaciones"),
    QuickSettings("Ajustes rápidos"),
    Lock("Bloquear la pantalla"),
    Flashlight("Linterna"),
    EditHome("Editar el inicio"),
    LauncherSettings("Ajustes del launcher"),
}

/** Color de acento (interfaz) y color de la baldosa de los iconos temáticos. */
data class PaletteItem(val name: String, val accent: Long, val tile: Long)

val Palettes = listOf(
    PaletteItem("Celeste", 0xFF72B8EE, 0xFF2583CC),
    PaletteItem("Lila", 0xFFB69CFF, 0xFF7656D8),
    PaletteItem("Menta", 0xFF6FD6B5, 0xFF1E9C7B),
    PaletteItem("Coral", 0xFFFF9A8A, 0xFFD65A48),
    PaletteItem("Ámbar", 0xFFF2C94C, 0xFFC48F12),
    PaletteItem("Rosa", 0xFFF48FB1, 0xFFCC4E7C),
)

/** palette == Palettes.size significa "color personalizado" (usa hue). */
data class IconStyle(
    val sizeDp: Int = 62,
    val shape: IconShape = IconShape.Squircle,
    val themed: Boolean = true,
    val palette: Int = 0,
    val hue: Float = 210f,
)

private fun hsvColor(h: Float, s: Float, v: Float): Int =
    android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359f), s, v))

fun accentArgb(st: IconStyle): Int =
    if (st.palette >= Palettes.size) hsvColor(st.hue, 0.50f, 1.0f)
    else Palettes[st.palette.coerceAtLeast(0)].accent.toInt()

fun tileArgb(st: IconStyle): Int =
    if (st.palette >= Palettes.size) hsvColor(st.hue, 0.85f, 0.80f)
    else Palettes[st.palette.coerceAtLeast(0)].tile.toInt()

data class LauncherConfig(
    val dim: Float = 0.62f,
    val bgStyle: BgStyle = BgStyle.Wallpaper,
    val showLabels: Boolean = true,
    val showDate: Boolean = true,
    val homeStyle: HomeStyle = HomeStyle.OneUI,
    val clockStyle: ClockStyle = ClockStyle.Thin,
    val clockSize: Int = 96,
    val drawerAnim: DrawerAnim = DrawerAnim.Slide,
    val gestureUp: GestureAction = GestureAction.Drawer,
    val gestureDown: GestureAction = GestureAction.Notifications,
    val gestureLeft: GestureAction = GestureAction.None,
    val gestureRight: GestureAction = GestureAction.None,
    val gestureDoubleTap: GestureAction = GestureAction.None,
    val autoLaunch: Boolean = false,
)

/** Cuántas apps entran en el inicio según el estilo. */
fun maxPinnedFor(cfg: LauncherConfig): Int = if (cfg.homeStyle == HomeStyle.OneUI) 24 else 7

// ---------------------------------------------------------------------------
// Apps
// ---------------------------------------------------------------------------

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                component = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Teléfono, mensajes, cámara y navegador si se encuentran. */
fun defaultPinned(ctx: Context, apps: List<AppInfo>): List<String> {
    val pm = ctx.packageManager
    val valid = apps.map { it.pkg }.toSet()
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
    )
    return intents
        .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .filter { it in valid }
        .distinct()
}

fun launchApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

fun openAppInfo(ctx: Context, app: AppInfo) {
    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

fun uninstallApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

// ---------------------------------------------------------------------------
// Atajos del sistema y acciones
// ---------------------------------------------------------------------------

/** Atajos de la app (por ejemplo "Nueva cámara selfie"). Solo funciona si MinLauncher es el launcher predeterminado. */
fun loadShortcuts(ctx: Context, app: AppInfo): List<ShortcutInfo> {
    return try {
        val la = ctx.getSystemService(LauncherApps::class.java)
        if (la == null || !la.hasShortcutHostPermission()) {
            emptyList()
        } else {
            val q = LauncherApps.ShortcutQuery()
                .setPackage(app.pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            val list: List<ShortcutInfo> = la.getShortcuts(q, Process.myUserHandle()) ?: emptyList()
            list.filter { it.isEnabled && it.shortLabel != null }.take(4)
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun startShortcut(ctx: Context, s: ShortcutInfo) {
    try {
        ctx.getSystemService(LauncherApps::class.java)?.startShortcut(s, null, null)
    } catch (_: Exception) {}
}

/** Baja el panel de notificaciones (necesita el permiso EXPAND_STATUS_BAR). */
fun expandNotifications(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager")
            .getMethod("expandNotificationsPanel")
            .invoke(sb)
    } catch (_: Exception) {}
}

fun openClock(ctx: Context) {
    try {
        ctx.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

fun openCalendar(ctx: Context) {
    try {
        val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (_: Exception) {}
}

fun webSearch(ctx: Context, query: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (_: Exception) {}
}

fun openHomeSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

fun openAccessibilitySettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

fun expandQuickSettings(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager")
            .getMethod("expandSettingsPanel")
            .invoke(sb)
    } catch (_: Exception) {}
}

object Torch {
    private var on = false
    fun toggle(ctx: Context) {
        try {
            val cm = ctx.getSystemService(CameraManager::class.java)
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            on = !on
            cm.setTorchMode(id, on)
        } catch (_: Exception) {}
    }
}

fun copyText(ctx: Context, text: String) {
    try {
        ctx.getSystemService(ClipboardManager::class.java)
            .setPrimaryClip(ClipData.newPlainText("resultado", text))
    } catch (_: Exception) {}
}

fun isDefaultLauncher(ctx: Context): Boolean {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val ri = ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
    return ri?.activityInfo?.packageName == ctx.packageName
}

// ---------------------------------------------------------------------------
// Preferencias
// ---------------------------------------------------------------------------

private inline fun <reified T : Enum<T>> android.content.SharedPreferences.getEnum(key: String, def: T): T =
    try { enumValueOf<T>(getString(key, def.name) ?: def.name) } catch (_: Exception) { def }

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    /** null = nunca configurado (primera vez). */
    fun getPinned(c: Context): List<String>? =
        sp(c).getString("pinned", null)?.let { if (it.isEmpty()) emptyList() else it.split("|") }

    fun setPinned(c: Context, list: List<String>) {
        sp(c).edit().putString("pinned", list.joinToString("|")).apply()
    }

    fun getHidden(c: Context): Set<String> =
        sp(c).getString("hidden", null)?.split("|")?.filter { it.isNotEmpty() }?.toSet() ?: emptySet()

    fun setHidden(c: Context, set: Set<String>) {
        sp(c).edit().putString("hidden", set.joinToString("|")).apply()
    }

    fun isSetupDone(c: Context): Boolean = sp(c).getBoolean("setupDone", false)

    fun setSetupDone(c: Context, done: Boolean) {
        sp(c).edit().putBoolean("setupDone", done).apply()
    }

    fun getStyle(c: Context): IconStyle {
        val p = sp(c)
        return IconStyle(
            sizeDp = p.getInt("iconSize", 62),
            shape = p.getEnum("shape", IconShape.Squircle),
            themed = p.getBoolean("themed", true),
            palette = p.getInt("palette", 0).coerceIn(0, Palettes.size),
            hue = p.getFloat("hue", 210f),
        )
    }

    fun setStyle(c: Context, st: IconStyle) {
        sp(c).edit()
            .putInt("iconSize", st.sizeDp)
            .putString("shape", st.shape.name)
            .putBoolean("themed", st.themed)
            .putInt("palette", st.palette)
            .putFloat("hue", st.hue)
            .apply()
    }

    fun getConfig(c: Context): LauncherConfig {
        val p = sp(c)
        val d = LauncherConfig()
        return LauncherConfig(
            dim = p.getFloat("dim", d.dim),
            bgStyle = p.getEnum("bgStyle", d.bgStyle),
            showLabels = p.getBoolean("showLabels", d.showLabels),
            showDate = p.getBoolean("showDate", d.showDate),
            homeStyle = p.getEnum("homeStyle", d.homeStyle),
            clockStyle = p.getEnum("clockStyle", d.clockStyle),
            clockSize = p.getInt("clockSize", d.clockSize),
            drawerAnim = p.getEnum("drawerAnim", d.drawerAnim),
            gestureUp = p.getEnum("gUp", d.gestureUp),
            gestureDown = p.getEnum("gDown", d.gestureDown),
            gestureLeft = p.getEnum("gLeft", d.gestureLeft),
            gestureRight = p.getEnum("gRight", d.gestureRight),
            gestureDoubleTap = p.getEnum("gDouble", d.gestureDoubleTap),
            autoLaunch = p.getBoolean("autoLaunch", d.autoLaunch),
        )
    }

    fun setConfig(c: Context, cfg: LauncherConfig) {
        sp(c).edit()
            .putFloat("dim", cfg.dim)
            .putString("bgStyle", cfg.bgStyle.name)
            .putBoolean("showLabels", cfg.showLabels)
            .putBoolean("showDate", cfg.showDate)
            .putString("homeStyle", cfg.homeStyle.name)
            .putString("clockStyle", cfg.clockStyle.name)
            .putInt("clockSize", cfg.clockSize)
            .putString("drawerAnim", cfg.drawerAnim.name)
            .putString("gUp", cfg.gestureUp.name)
            .putString("gDown", cfg.gestureDown.name)
            .putString("gLeft", cfg.gestureLeft.name)
            .putString("gRight", cfg.gestureRight.name)
            .putString("gDouble", cfg.gestureDoubleTap.name)
            .putBoolean("autoLaunch", cfg.autoLaunch)
            .apply()
    }

    /** Nombres personalizados: paquete -> nombre */
    fun getLabels(c: Context): Map<String, String> {
        val s = sp(c).getString("labels", null) ?: return emptyMap()
        return try {
            val o = org.json.JSONObject(s)
            o.keys().asSequence().associateWith { o.getString(it) }
        } catch (_: Exception) { emptyMap() }
    }

    fun setLabels(c: Context, map: Map<String, String>) {
        sp(c).edit().putString("labels", org.json.JSONObject(map).toString()).apply()
    }
}

// ---------------------------------------------------------------------------
// Iconos
// ---------------------------------------------------------------------------

object IconCache {
    private val map = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    private fun key(app: AppInfo, st: IconStyle) = "${app.pkg}|${st.shape.name}|${st.themed}|${tileArgb(st)}"
    fun peek(app: AppInfo, st: IconStyle): ImageBitmap? = map[key(app, st)]
    fun get(ctx: Context, app: AppInfo, st: IconStyle): ImageBitmap =
        map.getOrPut(key(app, st)) { IconRenderer.render(ctx, app, st) }
    fun clear(pkg: String) { map.keys.removeAll { it.startsWith("$pkg|") } }
}

/** Iconos con forma elegible. Temáticos = baldosa de color con el símbolo oscuro (como One UI). */
object IconRenderer {
    private val Fg = android.graphics.Color.parseColor("#08131F")
    private val LegacyBg = android.graphics.Color.parseColor("#E9EAEE")
    private const val SIZE = 192

    private fun shapePath(shape: IconShape, s: Float): Path {
        val p = Path()
        when (shape) {
            IconShape.Circle -> p.addCircle(s / 2f, s / 2f, s / 2f - 1f, Path.Direction.CW)
            IconShape.Rounded -> p.addRoundRect(RectF(1f, 1f, s - 1f, s - 1f), s * 0.20f, s * 0.20f, Path.Direction.CW)
            IconShape.Square -> p.addRoundRect(RectF(1f, 1f, s - 1f, s - 1f), s * 0.06f, s * 0.06f, Path.Direction.CW)
            IconShape.Squircle -> {
                val r = s / 2f - 1f
                val c = s / 2f
                val n = 4.6
                val steps = 140
                for (i in 0..steps) {
                    val t = 2.0 * Math.PI * i / steps
                    val ct = Math.cos(t)
                    val st = Math.sin(t)
                    val x = c + r * Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)
                    val y = c + r * Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    fun render(ctx: Context, app: AppInfo, style: IconStyle): ImageBitmap {
        val s = SIZE
        val d = ctx.packageManager.getActivityIcon(app.component)
        val tile = tileArgb(style)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val layer = c.saveLayer(0f, 0f, s.toFloat(), s.toFloat(), null)

        if (d is AdaptiveIconDrawable) {
            val mono = if (style.themed && Build.VERSION.SDK_INT >= 33) d.monochrome else null
            if (mono != null) {
                c.drawColor(tile)
                val big = (s * 1.35f).toInt()
                val o = (s - big) / 2
                val m = mono.mutate()
                m.setTint(Fg)
                m.setBounds(o, o, o + big, o + big)
                m.draw(c)
            } else {
                val big = (s * 1.5f).toInt()
                val o = (s - big) / 2
                d.background?.apply { setBounds(o, o, o + big, o + big); draw(c) }
                d.foreground?.apply { setBounds(o, o, o + big, o + big); draw(c) }
            }
        } else {
            // Icono "plano" (sin capas): sobre un fondo, recortado con la forma elegida
            c.drawColor(LegacyBg)
            val pad = (s * 0.14f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad)
            d.draw(c)
        }

        val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        c.drawPath(shapePath(style.shape, s.toFloat()), mask)
        c.restoreToCount(layer)
        return bmp.asImageBitmap()
    }
}
