package com.example.minlauncher

import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateUtils
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val original: String = label,
)

enum class IconShape(val label: String) {
    Squircle("Squircle"),
    Circle("Círculo"),
    Rounded("Redondeado"),
    Square("Cuadrado"),
}

data class IconStyle(
    val sizeDp: Int = 62,
    val shape: IconShape = IconShape.Squircle,
    val themed: Boolean = true,
    /** Colores de los iconos temáticos; salen del color de acento y no se guardan. */
    val tintBg: Int = 0xFF2583CC.toInt(),
    val tintFg: Int = 0xFF08131F.toInt(),
)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                component = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
            )
        }
        .sortedBy { normalize(it.label) }
}

/** Teléfono, mensajes, cámara y navegador si se encuentran. */
fun defaultPinned(ctx: Context, apps: List<AppInfo>): List<String> {
    val pm = ctx.packageManager
    val valid = apps.map { it.pkg }.toSet()
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
    )
    return intents
        .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .filter { it in valid }
        .distinct()
}

// ---- Acciones sobre apps ---------------------------------------------------
fun launchApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try {
        ctx.startActivity(i)
        Prefs.bumpUsage(ctx, app.pkg)
    } catch (_: Exception) {}
}

fun openAppInfo(ctx: Context, app: AppInfo) {
    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

fun uninstallApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

/** Atajos de la app (los que salen al mantener apretado el icono en otros launchers). */
fun loadShortcuts(ctx: Context, app: AppInfo): List<ShortcutInfo> {
    return try {
        val la = ctx.getSystemService(LauncherApps::class.java) ?: return emptyList()
        // Solo el launcher predeterminado tiene permiso para leer atajos
        if (!la.hasShortcutHostPermission()) return emptyList()
        val q = LauncherApps.ShortcutQuery()
            .setPackage(app.pkg)
            .setQueryFlags(
                LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                    LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
            )
        (la.getShortcuts(q, Process.myUserHandle()) ?: emptyList())
            .filter { it.isEnabled }
            .take(4)
    } catch (_: Exception) {
        emptyList()
    }
}

fun launchShortcut(ctx: Context, s: ShortcutInfo) {
    try {
        ctx.getSystemService(LauncherApps::class.java)?.startShortcut(s, null, null)
    } catch (_: Exception) {}
}

// ---- Launcher predeterminado -------------------------------------------------
fun isDefaultLauncher(ctx: Context): Boolean {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val res = ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
    return res?.activityInfo?.packageName == ctx.packageName
}

/** El diálogo oficial de Android "¿Usar MinLauncher como app de inicio?". null si no hace falta o no existe. */
fun defaultLauncherIntent(ctx: Context): Intent? {
    val rm = ctx.getSystemService(RoleManager::class.java) ?: return null
    return if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
        rm.createRequestRoleIntent(RoleManager.ROLE_HOME)
    } else null
}

fun openHomeSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}

// ---- Acciones del sistema (gestos) ---------------------------------------------
/** Abre el panel de notificaciones. Usa una API oculta: si tu Android la bloquea, simplemente no hace nada. */
fun expandNotifications(ctx: Context) {
    try {
        val bar = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager")
            .getMethod("expandNotificationsPanel")
            .invoke(bar)
    } catch (_: Exception) {}
}

/** Bloquea la pantalla con el servicio de accesibilidad opcional; si no está activado, te lleva a activarlo. */
fun lockScreenOrPrompt(ctx: Context) {
    val service = LockService.instance
    if (service != null) {
        service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
    } else {
        toast(ctx, "Activá MinLauncher en Accesibilidad para bloquear con un gesto")
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }
}

fun pickWallpaper(ctx: Context) {
    try {
        val i = Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Fondo de pantalla")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (_: Exception) {}
}

/** Búsqueda web con DuckDuckGo (sin cuenta ni rastreo). */
fun webSearch(ctx: Context, query: String) {
    val uri = Uri.parse("https://duckduckgo.com/?q=" + Uri.encode(query))
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

// ---- Datos para el reloj ---------------------------------------------------
/** Fecha según el formato elegido: 0 completa, 1 abreviada, 2 numérica, 3 solo el día. */
fun formatDate(ctx: Context, nowMs: Long, mode: Int): String {
    val flags = when (mode) {
        1 -> DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE or
            DateUtils.FORMAT_NO_YEAR or DateUtils.FORMAT_ABBREV_ALL
        2 -> DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NUMERIC_DATE or DateUtils.FORMAT_NO_YEAR
        3 -> DateUtils.FORMAT_SHOW_WEEKDAY
        else -> DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_NO_YEAR
    }
    return DateUtils.formatDateTime(ctx, nowMs, flags)
}

/** Porcentaje de batería, o -1 si no se puede leer. */
fun batteryPercent(ctx: Context): Int = try {
    ctx.getSystemService(BatteryManager::class.java)
        .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
} catch (_: Exception) { -1 }

/** Hora de la próxima alarma del reloj del sistema, o null si no hay ninguna. */
fun nextAlarmMillis(ctx: Context): Long? = try {
    ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock?.triggerTime
} catch (_: Exception) { null }

// ---- Iconos ---------------------------------------------------------------
object IconCache {
    private val map = java.util.concurrent.ConcurrentHashMap<String, ImageBitmap>()
    private fun key(app: AppInfo, st: IconStyle) =
        "${app.pkg}|${st.shape.name}|${st.themed}|${st.tintBg}|${st.tintFg}"
    fun peek(app: AppInfo, st: IconStyle): ImageBitmap? = map[key(app, st)]
    fun get(ctx: Context, app: AppInfo, st: IconStyle): ImageBitmap =
        map.getOrPut(key(app, st)) { IconRenderer.render(ctx, app, st) }
    fun clear(pkg: String) { map.keys.removeAll { it.startsWith("$pkg|") } }
}

/** Iconos con forma elegible. Temáticos = fondo de color de acento con el símbolo oscuro (como One UI). */
object IconRenderer {
    private val LegacyBg = android.graphics.Color.parseColor("#E9EAEE")
    private const val SIZE = 192

    private fun shapePath(shape: IconShape, s: Float): Path {
        val p = Path()
        when (shape) {
            IconShape.Circle -> p.addCircle(s / 2f, s / 2f, s / 2f - 1f, Path.Direction.CW)
            IconShape.Rounded -> p.addRoundRect(RectF(1f, 1f, s - 1f, s - 1f), s * 0.20f, s * 0.20f, Path.Direction.CW)
            IconShape.Square -> p.addRoundRect(RectF(1f, 1f, s - 1f, s - 1f), s * 0.06f, s * 0.06f, Path.Direction.CW)
            IconShape.Squircle -> {
                val r = s / 2f - 1f
                val c = s / 2f
                val n = 4.6
                val steps = 140
                for (i in 0..steps) {
                    val t = 2.0 * Math.PI * i / steps
                    val ct = Math.cos(t)
                    val st = Math.sin(t)
                    val x = c + r * Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)
                    val y = c + r * Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)
                    if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
                }
                p.close()
            }
        }
        return p
    }

    fun render(ctx: Context, app: AppInfo, style: IconStyle): ImageBitmap {
        val s = SIZE
        val d = ctx.packageManager.getActivityIcon(app.component)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        if (d is AdaptiveIconDrawable) {
            val mono = if (style.themed && Build.VERSION.SDK_INT >= 33) d.monochrome else null
            val layer = c.saveLayer(0f, 0f, s.toFloat(), s.toFloat(), null)
            if (mono != null) {
                c.drawColor(style.tintBg)
                val big = (s * 1.35f).toInt()
                val o = (s - big) / 2
                val m = mono.mutate()
                m.setTint(style.tintFg)
                m.setBounds(o, o, o + big, o + big)
                m.draw(c)
            } else {
                val big = (s * 1.5f).toInt()
                val o = (s - big) / 2
                d.background?.apply { setBounds(o, o, o + big, o + big); draw(c) }
                d.foreground?.apply { setBounds(o, o, o + big, o + big); draw(c) }
            }
            val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            c.drawPath(shapePath(style.shape, s.toFloat()), mask)
            c.restoreToCount(layer)
        } else {
            // Icono "plano" (sin capas): se pone sobre un fondo y se recorta con la forma elegida
            val layer = c.saveLayer(0f, 0f, s.toFloat(), s.toFloat(), null)
            c.drawColor(LegacyBg)
            val pad = (s * 0.14f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad)
            d.draw(c)
            val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            c.drawPath(shapePath(style.shape, s.toFloat()), mask)
            c.restoreToCount(layer)
        }
        return bmp.asImageBitmap()
    }
}
