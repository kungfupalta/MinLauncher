package com.example.minlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val original: String = label,
)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppInfo(
                label = it.loadLabel(pm).toString(),
                pkg = it.activityInfo.packageName,
                component = ComponentName(it.activityInfo.packageName, it.activityInfo.name),
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Teléfono, cámara, navegador y mensajes si se encuentran. */
fun defaultPinned(ctx: Context, apps: List<AppInfo>): List<String> {
    val pm = ctx.packageManager
    val valid = apps.map { it.pkg }.toSet()
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
    )
    return intents
        .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .filter { it in valid }
        .distinct()
}

fun launchApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(app.component)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

fun openAppInfo(ctx: Context, app: AppInfo) {
    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

fun uninstallApp(ctx: Context, app: AppInfo) {
    val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try { ctx.startActivity(i) } catch (_: Exception) {}
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    /** null = nunca configurado (primera vez). */
    fun getPinned(c: Context): List<String>? =
        sp(c).getString("pinned", null)?.let { if (it.isEmpty()) emptyList() else it.split("|") }

    fun setPinned(c: Context, list: List<String>) {
        sp(c).edit().putString("pinned", list.joinToString("|")).apply()
    }

    /** Nombres personalizados: paquete -> nombre */
    fun getLabels(c: Context): Map<String, String> {
        val s = sp(c).getString("labels", null) ?: return emptyMap()
        return try {
            val o = org.json.JSONObject(s)
            o.keys().asSequence().associateWith { o.getString(it) }
        } catch (_: Exception) { emptyMap() }
    }

    fun setLabels(c: Context, map: Map<String, String>) {
        sp(c).edit().putString("labels", org.json.JSONObject(map).toString()).apply()
    }
}

object IconCache {
    private val map = HashMap<String, ImageBitmap>()
    fun peek(app: AppInfo): ImageBitmap? = map[app.pkg]
    fun get(ctx: Context, app: AppInfo): ImageBitmap = map.getOrPut(app.pkg) {
        IconRenderer.render(ctx, app)
    }
    fun clear(pkg: String) { map.remove(pkg) }
}


/** Iconos "temáticos": cuadrado redondeado azul con el símbolo oscuro (como los de One UI). */
object IconRenderer {
    /** false = iconos originales de cada app */
    const val THEMED = true
    private val Bg = android.graphics.Color.parseColor("#2583CC")
    private val Fg = android.graphics.Color.parseColor("#08131F")
    private const val SIZE = 168

    private fun squircle(s: Float): Path {
        val p = Path()
        val r = s / 2f - 1f
        val c = s / 2f
        val n = 4.6
        val steps = 140
        for (i in 0..steps) {
            val t = 2.0 * Math.PI * i / steps
            val ct = Math.cos(t)
            val st = Math.sin(t)
            val x = c + r * Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)
            val y = c + r * Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
        return p
    }

    fun render(ctx: Context, app: AppInfo): ImageBitmap {
        val s = SIZE
        val d = ctx.packageManager.getActivityIcon(app.component)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        if (d is AdaptiveIconDrawable) {
            val mono = if (THEMED && Build.VERSION.SDK_INT >= 33) d.monochrome else null
            val layer = c.saveLayer(0f, 0f, s.toFloat(), s.toFloat(), null)
            if (mono != null) {
                c.drawColor(Bg)
                val big = (s * 1.35f).toInt()
                val o = (s - big) / 2
                val m = mono.mutate()
                m.setTint(Fg)
                m.setBounds(o, o, o + big, o + big)
                m.draw(c)
            } else {
                val big = (s * 1.5f).toInt()
                val o = (s - big) / 2
                d.background?.apply { setBounds(o, o, o + big, o + big); draw(c) }
                d.foreground?.apply { setBounds(o, o, o + big, o + big); draw(c) }
            }
            val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            c.drawPath(squircle(s.toFloat()), mask)
            c.restoreToCount(layer)
        } else {
            val pad = (s * 0.06f).toInt()
            d.setBounds(pad, pad, s - pad, s - pad)
            d.draw(c)
        }
        return bmp.asImageBitmap()
    }
}
