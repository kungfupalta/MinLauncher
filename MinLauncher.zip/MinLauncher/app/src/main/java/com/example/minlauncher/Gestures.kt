package com.example.minlauncher

import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

/** Deslizar hacia arriba o hacia abajo en el inicio. Los costados quedan libres para cambiar de página. */
@Composable
fun Modifier.swipeGestures(onGesture: (GestureSlot) -> Unit): Modifier {
    val callback by rememberUpdatedState(onGesture)
    return this.pointerInput(Unit) {
        var total = 0f
        detectVerticalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = {
                if (total < -90f) callback(GestureSlot.SwipeUp)
                else if (total > 90f) callback(GestureSlot.SwipeDown)
            },
            onDragCancel = { total = 0f },
            onVerticalDrag = { _, dy -> total += dy },
        )
    }
}
