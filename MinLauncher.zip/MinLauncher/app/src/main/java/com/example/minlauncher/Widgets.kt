package com.example.minlauncher

import android.text.format.DateFormat
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Una persona con su zona horaria. Para sumar otra hora, agregá una línea acá. */
data class ZoneClock(val label: String, val place: String, val zoneId: String)

val WorldClockEntries = listOf(
    ZoneClock("Hora Arianna", "Ecuador", "America/Guayaquil"),
    ZoneClock("Hora Marcos", "Argentina", "America/Argentina/Buenos_Aires"),
)

private fun timeIn(is24: Boolean, nowMs: Long, zoneId: String): String =
    Instant.ofEpochMilli(nowMs)
        .atZone(ZoneId.of(zoneId))
        .format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a"))

/** Si allá ya es otro día que en tu teléfono, lo aclara. */
private fun dayTag(nowMs: Long, zoneId: String): String {
    val there = Instant.ofEpochMilli(nowMs).atZone(ZoneId.of(zoneId)).toLocalDate()
    val here = Instant.ofEpochMilli(nowMs).atZone(ZoneId.systemDefault()).toLocalDate()
    return when {
        there.isBefore(here) -> " · ayer"
        there.isAfter(here) -> " · mañana"
        else -> ""
    }
}

/** Widget del inicio con dos horas. Mantenerlo apretado permite quitarlo. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WorldClockWidget(settings: LauncherSettings, onRemove: () -> Unit) {
    val ctx = LocalContext.current
    var confirmRemove by remember { mutableStateOf(false) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    val is24 = when (settings.clockFormat) {
        1 -> true
        2 -> false
        else -> DateFormat.is24HourFormat(ctx)
    }

    Column(
        Modifier
            .widthIn(min = 250.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Card.copy(alpha = 0.85f))
            .combinedClickable(onClick = {}, onLongClick = { confirmRemove = true })
            .padding(horizontal = 18.dp, vertical = 12.dp),
    ) {
        WorldClockEntries.forEachIndexed { i, entry ->
            if (i > 0) Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(entry.label, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(
                        entry.place + dayTag(now, entry.zoneId),
                        color = Dim,
                        fontSize = 12.sp,
                    )
                }
                Text(
                    timeIn(is24, now, entry.zoneId),
                    color = Accent,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                )
            }
        }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            containerColor = Card,
            title = { Text("Quitar widget", color = Ink, fontWeight = FontWeight.Light) },
            text = {
                Text(
                    "Dejás de ver la hora de Arianna y Marcos en el inicio. " +
                        "Podés volver a agregarlo en Ajustes > Inicio.",
                    color = Dim,
                    fontSize = 14.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmRemove = false; onRemove() }) {
                    Text("Quitar", color = Accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmRemove = false }) { Text("Cancelar", color = Dim) }
            },
        )
    }
}
