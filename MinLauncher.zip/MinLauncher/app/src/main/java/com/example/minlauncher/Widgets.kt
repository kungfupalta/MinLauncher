package com.example.minlauncher

import android.text.format.DateFormat
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Una persona con su zona horaria. `key` es lo que se guarda en los ajustes. */
data class ZoneClock(val key: String, val label: String, val place: String, val zoneId: String)

/** Para sumar otra hora, agregá una línea acá: aparece sola en Ajustes con su propio interruptor. */
val WorldClockEntries = listOf(
    ZoneClock("arianna", "Hora Arianna", "Ecuador", "America/Guayaquil"),
    ZoneClock("marcos", "Hora Marcos", "Argentina", "America/Argentina/Buenos_Aires"),
)

private fun timeIn(is24: Boolean, nowMs: Long, zoneId: String): String =
    Instant.ofEpochMilli(nowMs)
        .atZone(ZoneId.of(zoneId))
        .format(DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a"))

/** Si allá ya es otro día que en tu teléfono, lo aclara. */
private fun dayTag(nowMs: Long, zoneId: String): String {
    val there = Instant.ofEpochMilli(nowMs).atZone(ZoneId.of(zoneId)).toLocalDate()
    val here = Instant.ofEpochMilli(nowMs).atZone(ZoneId.systemDefault()).toLocalDate()
    return when {
        there.isBefore(here) -> " · ayer"
        there.isAfter(here) -> " · mañana"
        else -> ""
    }
}

/**
 * Horas chiquitas que van debajo del reloj principal. Cada una se muestra solo si está activada
 * en Ajustes; manteniéndola apretada se puede quitar.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WorldClocks(settings: LauncherSettings, align: Alignment.Horizontal, onRemove: (String) -> Unit) {
    val active = WorldClockEntries.filter { it.key in settings.worldClocks }
    if (active.isEmpty()) return

    val ctx = LocalContext.current
    var toRemove by remember { mutableStateOf<ZoneClock?>(null) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(60_000L - (value % 60_000L) + 50L)
        }
    }
    val is24 = when (settings.clockFormat) {
        1 -> true
        2 -> false
        else -> DateFormat.is24HourFormat(ctx)
    }

    Column(Modifier.padding(start = 2.dp, top = 6.dp), horizontalAlignment = align) {
        active.forEach { entry ->
            Row(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .combinedClickable(onClick = {}, onLongClick = { toRemove = entry })
                    .padding(horizontal = 2.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(entry.label, color = Dim, fontSize = 12.sp)
                Spacer(Modifier.width(8.dp))
                Text(
                    timeIn(is24, now, entry.zoneId),
                    color = Ink,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
                val tag = dayTag(now, entry.zoneId)
                if (tag.isNotEmpty()) Text(tag, color = Dim, fontSize = 11.sp)
            }
        }
    }

    toRemove?.let { entry ->
        AlertDialog(
            onDismissRequest = { toRemove = null },
            containerColor = Card,
            title = { Text("Quitar ${entry.label}", color = Ink, fontWeight = FontWeight.Light) },
            text = {
                Text(
                    "Deja de verse debajo del reloj. Podés volver a mostrarla en Ajustes > Inicio.",
                    color = Dim,
                    fontSize = 14.sp,
                )
            },
            confirmButton = {
                TextButton(onClick = { toRemove = null; onRemove(entry.key) }) {
                    Text("Quitar", color = Accent)
                }
            },
            dismissButton = {
                TextButton(onClick = { toRemove = null }) { Text("Cancelar", color = Dim) }
            },
        )
    }
}

/** Un interruptor por cada hora: se pueden mostrar juntas o por separado. */
@Composable
internal fun WorldClockToggles(settings: LauncherSettings, onSettings: (LauncherSettings) -> Unit) {
    WorldClockEntries.forEach { entry ->
        SwitchRow(
            entry.label,
            "${entry.place} · se ve chiquita debajo del reloj",
            entry.key in settings.worldClocks,
        ) { on -> onSettings(settings.withWorldClock(entry.key, on)) }
    }
}
