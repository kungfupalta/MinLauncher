package com.example.minlauncher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchTest {

    @Test
    fun normalizeQuitaTildesYMayusculas() {
        assertEquals("camara", normalize("Cámara"))
        assertEquals("nandu", normalize("Ñandú"))
    }

    @Test
    fun buscaSinImportarTildes() {
        assertTrue(matchesQuery("Cámara", "camara"))
        assertTrue(matchesQuery("Reloj", "RELOJ"))
    }

    @Test
    fun buscaPorVariasPalabrasEnCualquierOrden() {
        assertTrue(matchesQuery("Google Maps", "maps goo"))
    }

    @Test
    fun buscaPorIniciales() {
        assertTrue(matchesQuery("Google Maps", "gm"))
        assertFalse(matchesQuery("Google Maps", "xyz"))
    }

    @Test
    fun busquedaVaciaCoincideConTodo() {
        assertTrue(matchesQuery("Cualquier app", "   "))
    }

    @Test
    fun letraDelIndice() {
        assertEquals('A', indexLetter("Álbum"))
        assertEquals('#', indexLetter("1Password"))
        assertEquals('#', indexLetter(""))
    }
}
