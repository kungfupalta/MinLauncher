package com.example.minlauncher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LayoutTest {

    @Test
    fun fromOrderPoneLasPrimerasEnLaBarraYElRestoEnLaCuadricula() {
        val l = HomeLayout.fromOrder(listOf("a", "b", "c", "d", "e"), cols = 4, rows = 5, dockCount = 3)
        assertEquals(listOf("a", "b", "c"), l.items.filter { it.page == DOCK }.sortedBy { it.col }.map { it.pkg })
        assertEquals(Placed("d", 0, 0, 0), l.find("d"))
        assertEquals(Placed("e", 0, 1, 0), l.find("e"))
    }

    @Test
    fun moverAUnaCeldaVaciaSoloCambiaDeLugar() {
        val l = HomeLayout().add("a", 4, 5).move("a", 0, 2, 3, 4, 5)
        assertEquals(Placed("a", 0, 2, 3), l.find("a"))
        assertEquals(1, l.items.size)
    }

    @Test
    fun moverAUnaCeldaOcupadaIntercambia() {
        val l = HomeLayout()
            .move("a", 0, 0, 0, 4, 5)
            .move("b", 0, 1, 0, 4, 5)
            .move("a", 0, 1, 0, 4, 5)
        assertEquals(Placed("a", 0, 1, 0), l.find("a"))
        assertEquals(Placed("b", 0, 0, 0), l.find("b"))
    }

    @Test
    fun intercambiarConLaBarraFunciona() {
        val l = HomeLayout()
            .move("a", 0, 0, 0, 4, 5)
            .move("b", DOCK, 0, 0, 4, 5)
            .move("a", DOCK, 0, 0, 4, 5)
        assertEquals(Placed("a", DOCK, 0, 0), l.find("a"))
        assertEquals(Placed("b", 0, 0, 0), l.find("b"))
    }

    @Test
    fun unaAppNuevaSobreUnaOcupadaDesplazaALaOtraAlPrimerHuecoLibre() {
        val l = HomeLayout().move("a", 0, 0, 0, 4, 5).move("b", 0, 0, 0, 4, 5)
        assertEquals(Placed("b", 0, 0, 0), l.find("b"))
        assertEquals(Placed("a", 0, 1, 0), l.find("a"))
    }

    @Test
    fun agregarCreaUnaPaginaNuevaCuandoNoHayLugar() {
        var l = HomeLayout()
        for (i in 0 until 7) l = l.add("app$i", cols = 3, rows = 2) // caben 6 por página
        assertEquals(2, l.pageCount)
        assertEquals(1, l.find("app6")!!.page)
    }

    @Test
    fun agregarUnaAppRepetidaNoHaceNada() {
        val l = HomeLayout().add("a", 4, 5)
        assertEquals(l, l.add("a", 4, 5))
    }

    @Test
    fun quitarYLimpiarPaginasVacias() {
        var l = HomeLayout().move("a", 0, 0, 0, 4, 5).move("b", 2, 0, 0, 4, 5)
        assertEquals(3, l.pageCount)
        l = l.remove("b").pruned()
        assertEquals(1, l.pageCount)
        assertNull(l.find("b"))
    }

    @Test
    fun siSeAchicaLaCuadriculaLasAppsDeAfueraSeReacomodan() {
        val l = HomeLayout()
            .move("a", 0, 0, 0, 5, 6)
            .move("b", 0, 4, 5, 5, 6)
            .reflow(cols = 3, rows = 3, dockCount = 4)
        val b = l.find("b")!!
        assertTrue(b.col < 3 && b.row < 3)
        assertEquals(2, l.items.size)
    }

    @Test
    fun siSeAchicaLaBarraLasAppsSobrantesPasanALaCuadricula() {
        val l = HomeLayout.fromOrder(listOf("a", "b", "c", "d"), 4, 5, dockCount = 4)
            .reflow(cols = 4, rows = 5, dockCount = 3)
        assertTrue(l.find("d")!!.page >= 0)
        assertEquals(3, l.items.count { it.page == DOCK })
    }

    @Test
    fun seQuitanLasAppsDesinstaladas() {
        val l = HomeLayout.fromOrder(listOf("a", "b"), 4, 5, 4).dropMissing(setOf("a"))
        assertTrue(l.contains("a"))
        assertFalse(l.contains("b"))
    }

    @Test
    fun guardarYLeerDevuelveLoMismo() {
        val l = HomeLayout.fromOrder(listOf("com.a", "com.b", "com.c"), 4, 5, 2).move("com.c", 1, 3, 4, 4, 5)
        assertEquals(l, HomeLayout.decode(l.encode()))
        assertEquals(HomeLayout(), HomeLayout.decode(HomeLayout().encode()))
    }

    @Test
    fun textoGuardadoRotoNoRompeNada() {
        assertNull(HomeLayout.decode("esto no es un inicio"))
    }

    // ---- Qué hay bajo el dedo
    private val geo = Geo(
        cols = 4, rows = 5, dockCount = 4, showDock = true, widthPx = 400f, sidePx = 0f,
        topPx = 0f, cellW = 100f, cellH = 100f, gridH = 500f, dockTop = 600f, dockH = 100f,
        slotW = 100f, removeH = 20f,
    )

    @Test
    fun tocarUnaCeldaDevuelveSuLugar() {
        assertEquals(DropTarget(1, 1, 2), geo.targetAt(150f, 250f, page = 1, clamp = false))
    }

    @Test
    fun tocarLaBarraInferiorDevuelveElLugarDeLaBarra() {
        assertEquals(DropTarget(DOCK, 3, 0), geo.targetAt(350f, 650f, page = 0, clamp = false))
    }

    @Test
    fun fueraDeLaCuadriculaNoHayNada() {
        assertNull(geo.targetAt(-10f, 250f, page = 0, clamp = false))
        assertNull(geo.targetAt(150f, 550f, page = 0, clamp = false))
    }

    @Test
    fun alSoltarSiempreHayUnLugarMasCercano() {
        assertEquals(DropTarget(0, 0, 2), geo.targetAt(-10f, 250f, page = 0, clamp = true))
        assertEquals(DropTarget(0, 3, 4), geo.targetAt(999f, 580f, page = 0, clamp = true))
    }

    @Test
    fun soltarArribaEsQuitar() {
        val t = geo.targetAt(200f, 5f, page = 0, clamp = true)
        assertNotNull(t)
        assertTrue(t!!.remove)
    }
}
