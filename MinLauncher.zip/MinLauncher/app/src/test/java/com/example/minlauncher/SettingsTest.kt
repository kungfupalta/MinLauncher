package com.example.minlauncher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsTest {

    @Test
    fun porDefectoSeMuestranLasDosHoras() {
        assertEquals(setOf("arianna", "marcos"), LauncherSettings().worldClocks)
    }

    @Test
    fun cadaHoraSePuedeQuitarPorSeparado() {
        val s = LauncherSettings().withWorldClock("marcos", false)
        assertEquals(setOf("arianna"), s.worldClocks)
        assertTrue(s.withWorldClock("marcos", true).worldClocks.contains("marcos"))
    }

    @Test
    fun mantenerApretadoSiempreAbreEditorOAjustes() {
        // Garantiza que nunca te quedes sin acceso a los ajustes
        assertEquals(Gesture.EDIT, GestureSlot.LongPress.default)
    }

    @Test
    fun cadaGestoTieneAccionPorDefecto() {
        val s = LauncherSettings()
        GestureSlot.entries.forEach { assertEquals(it.default, s.gesture(it)) }
        assertFalse(s.lockLayout)
    }

    @Test
    fun losLimitesDeTamanoTienenSentido() {
        assertTrue(MIN_CLOCK_SP < LauncherSettings().clockSize)
        assertTrue(LauncherSettings().clockSize < MAX_CLOCK_SP)
        assertTrue(MIN_SMALL_SP < LauncherSettings().worldClockSize)
        assertTrue(LauncherSettings().worldClockSize < MAX_SMALL_SP)
    }
}
