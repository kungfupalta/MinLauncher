# MinLauncher usa solo APIs públicas y reflexión sobre clases del sistema (no se ofuscan),
# así que no hacen falta reglas especiales. Agregá las tuyas acá si sumás librerías.
