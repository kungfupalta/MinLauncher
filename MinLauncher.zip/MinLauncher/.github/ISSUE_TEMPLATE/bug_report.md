---
name: Reportar un error
about: Algo no anda como debería
labels: bug
---

**Qué pasó**

**Cómo reproducirlo**
1.
2.

**Qué esperabas que pasara**

**Tu teléfono**
- Modelo y versión de Android:
- Versión de MinLauncher (Ajustes > Acerca de):
