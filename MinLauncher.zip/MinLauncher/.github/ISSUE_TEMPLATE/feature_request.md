---
name: Proponer una función
about: Una idea para mejorar MinLauncher
labels: enhancement
---

**Qué querés poder hacer**

**Por qué te sirve**

**Alternativas que probaste**
