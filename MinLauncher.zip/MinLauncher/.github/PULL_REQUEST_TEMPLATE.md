## Qué cambia

## Cómo lo probé
- [ ] Teléfono real o emulador (Android 12+)
- [ ] Horizontal y vertical, tema claro y oscuro
- [ ] `gradle :app:testDebugUnitTest`

## Checklist
- [ ] No agrega permisos de internet ni librerías de rastreo
- [ ] Actualicé `CHANGELOG.md`
