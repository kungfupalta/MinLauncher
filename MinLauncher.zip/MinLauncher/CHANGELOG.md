# Cambios

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/).

## [1.1.0]

### Agregado
- Guía de bienvenida de primera vez con botón para dejar MinLauncher como launcher predeterminado.
- Pantalla de Ajustes completa: tema claro/oscuro/sistema, color de acento (con Material You), reloj, alineación, tamaños y barra de estado.
- Gestos configurables: deslizar en cuatro direcciones, doble toque y mantener apretado, con acciones como abrir notificaciones, bloquear pantalla o abrir cualquier app.
- Horas chiquitas debajo del reloj (Hora Arianna: Ecuador, Hora Marcos: Argentina), que se activan por separado y se pueden quitar manteniéndolas apretadas.
- Cajón de apps: índice alfabético, vista en lista, fila de más usadas, búsqueda sin tildes y por iniciales, búsqueda web si no hay resultados.
- Apps ocultas y atajos de cada app en el menú de mantener apretado.
- Copia de seguridad: exportar e importar ajustes en JSON.
- Ícono propio, licencia MIT, README, guía de contribución, política de privacidad y metadatos para F-Droid.
- Tests unitarios de la búsqueda y publicación automática del APK al subir una etiqueta.

### Cambiado
- El APK de release ahora se achica con R8 y se quitan los recursos sin usar.
- Los iconos temáticos toman el color de acento elegido.

## [1.0]
- Primera versión: reloj, apps fijadas, cajón con buscador, formas de icono y renombrado.
