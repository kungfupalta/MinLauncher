# Cambios

Formato basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/).

## [1.1.0]

### Agregado
- **Nuevo estilo de inicio inspirado en One UI**: cuadrícula con páginas, puntos de página y barra inferior, con las apps **arrastrables y ordenables a gusto** (intercambiar celdas, mover a la barra, cambiar de página, quitar arrastrando arriba).
- Ajustes de la cuadrícula: columnas, filas, márgenes, nombres, cantidad de apps de la barra inferior y su fondo.
- Nueva paleta clara y oscura al estilo One UI, con tarjetas más redondeadas y encabezado grande en Ajustes.
- Guía de bienvenida de primera vez con botón para dejar MinLauncher como launcher predeterminado.
- Pantalla de Ajustes completa: tema claro/oscuro/sistema, color de acento (con Material You), reloj, alineación, tamaños y barra de estado.
- Gestos configurables: deslizar en cuatro direcciones, doble toque y mantener apretado, con acciones como abrir notificaciones, bloquear pantalla o abrir cualquier app.
- Horas chiquitas debajo del reloj (Hora Arianna: Ecuador, Hora Marcos: Argentina), que se activan por separado y se pueden quitar manteniéndolas apretadas.
- Cajón de apps: índice alfabético, vista en lista, fila de más usadas, búsqueda sin tildes y por iniciales, búsqueda web si no hay resultados.
- Apps ocultas y atajos de cada app en el menú de mantener apretado.
- Copia de seguridad: exportar e importar ajustes en JSON, y restablecer todo a los valores de fábrica.
- El reloj y las horas chiquitas se agrandan o achican **pellizcando con dos dedos** en el inicio.
- Reloj: grosor, color, dos líneas, formato de fecha, batería y próxima alarma.
- Inicio: apps como lista o como iconos en cuadrícula, iconos junto a los nombres, posición del reloj y de las apps, margen lateral, barra de búsqueda y bloqueo del diseño.
- Cajón: columnas, tamaño de los nombres, opacidad del fondo y buscador arriba o abajo.
- Apariencia: tipografía, color de acento personalizado (RGB), orientación de pantalla y animaciones activables.
- Ícono propio, licencia MIT, README, guía de contribución, política de privacidad y metadatos para F-Droid.
- Tests unitarios de la búsqueda y publicación automática del APK al subir una etiqueta.

### Cambiado
- La lista de texto en el inicio pasa a ser **opcional**; el estilo por defecto es la cuadrícula.
- Se quitaron los gestos de deslizar a izquierda y derecha: ahora cambian de página.
- El APK de release ahora se achica con R8 y se quitan los recursos sin usar.
- Los iconos temáticos toman el color de acento elegido.

## [1.0]
- Primera versión: reloj, apps fijadas, cajón con buscador, formas de icono y renombrado.
