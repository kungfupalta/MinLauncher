package com.smartdebloater.shizuku

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            val scheme = if (isSystemInDarkTheme()) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
            MaterialTheme(colorScheme = scheme) { AppScreen(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.shizuku.refresh()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val sz by vm.shizuku.state.collectAsStateWithLifecycle()

    val visible = remember(ui.apps, ui.query, ui.filter) {
        ui.apps.filter { a ->
            (ui.filter.risk == null || a.risk == ui.filter.risk) &&
                (ui.query.isBlank() ||
                    a.label.contains(ui.query, ignoreCase = true) ||
                    a.packageName.contains(ui.query, ignoreCase = true))
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Smart Debloater · Shizuku") }) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = vm::autoSelect,
                        modifier = Modifier.weight(1f),
                        enabled = !ui.scanning && !ui.working
                    ) { Text("Selección automática") }
                    Button(
                        onClick = vm::askConfirm,
                        modifier = Modifier.weight(1f),
                        enabled = ui.selected.isNotEmpty() && sz == ShizukuState.READY && !ui.working
                    ) { Text("Desinstalar (${ui.selected.size})") }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ShizukuCard(sz, onRequest = { vm.shizuku.requestPermission() }, onRetry = { vm.shizuku.refresh() })

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Switch(checked = ui.useWeb, onCheckedChange = vm::setUseWeb, enabled = !ui.scanning)
                Spacer(Modifier.width(8.dp))
                Text("Consultar Google Play", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = vm::scan, enabled = !ui.scanning) { Text("Re-escanear") }
            }

            OutlinedTextField(
                value = ui.query,
                onValueChange = vm::setQuery,
                label = { Text("Buscar app o paquete") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Filter.values().toList()) { f ->
                    FilterChip(selected = ui.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f.label) })
                }
            }

            if (ui.scanning) {
                Text(
                    "Analizando paquetes… ${(ui.progress * 100).toInt()}%",
                    Modifier.padding(horizontal = 12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
                LinearProgressIndicator(progress = { ui.progress }, modifier = Modifier.fillMaxWidth().padding(12.dp))
            } else {
                Text(
                    "${visible.size} apps · ${ui.selected.size} seleccionadas",
                    Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelMedium
                )
            }

            LazyColumn(Modifier.weight(1f)) {
                items(visible, key = { it.packageName }) { app ->
                    AppRow(app, app.packageName in ui.selected) { vm.toggle(app.packageName) }
                }
            }
        }
    }

    if (ui.working) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text("Desinstalando…") },
            text = { CircularProgressIndicator() }
        )
    }

    if (ui.confirmDialog) {
        AlertDialog(
            onDismissRequest = vm::dismissConfirm,
            title = { Text("¿Desinstalar ${ui.selected.size} apps?") },
            text = {
                Text(
                    "Se ejecutará «pm uninstall --user 0» vía Shizuku. Las apps de sistema se quitan solo " +
                        "del usuario actual y pueden restaurarse con «pm install-existing --user 0 <paquete>» " +
                        "o con un restablecimiento de fábrica. Las apps críticas nunca se desinstalan."
                )
            },
            confirmButton = { TextButton(onClick = vm::uninstallSelected) { Text("Desinstalar") } },
            dismissButton = { TextButton(onClick = vm::dismissConfirm) { Text("Cancelar") } }
        )
    }

    ui.report?.let { lines ->
        AlertDialog(
            onDismissRequest = vm::dismissReport,
            title = { Text("Resultado") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    lines.forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(4.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissReport) { Text("Cerrar") } }
        )
    }
}

@Composable
fun ShizukuCard(state: ShizukuState, onRequest: () -> Unit, onRetry: () -> Unit) {
    val msg: String
    val actionLabel: String?
    val action: () -> Unit
    when (state) {
        ShizukuState.NOT_RUNNING -> {
            msg = "Shizuku no está activo. Ábrelo e inícialo (depuración inalámbrica)."
            actionLabel = "Reintentar"; action = onRetry
        }
        ShizukuState.NO_PERMISSION -> {
            msg = "Falta el permiso de Shizuku. Si no aparece el diálogo, concédelo desde la app Shizuku."
            actionLabel = "Conceder"; action = onRequest
        }
        ShizukuState.CONNECTING -> {
            msg = "Conectando con Shizuku…"
            actionLabel = null; action = {}
        }
        ShizukuState.READY -> {
            msg = "Shizuku conectado ✔ — listo para desinstalar."
            actionLabel = null; action = {}
        }
    }
    Card(Modifier.fillMaxWidth().padding(12.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(msg, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            if (actionLabel != null) TextButton(onClick = action) { Text(actionLabel) }
        }
    }
}

@Composable
fun AppRow(app: AppEntry, checked: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val icon = remember(app.packageName) {
        runCatching { ctx.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    val canSelect = app.risk != Risk.CRITICAL
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .clickable(enabled = canSelect, onClick = onToggle)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            if (icon != null) Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(40.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                RiskBadge(app.risk)
                Spacer(Modifier.height(6.dp))
                Text("¿Qué hace? " + app.summary, style = MaterialTheme.typography.bodySmall, maxLines = 5, overflow = TextOverflow.Ellipsis)
            }
            Checkbox(checked = checked, onCheckedChange = { onToggle() }, enabled = canSelect)
        }
    }
}

@Composable
fun RiskBadge(risk: Risk) {
    Surface(color = Color(risk.color), shape = RoundedCornerShape(50)) {
        Text(
            risk.badge,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}
