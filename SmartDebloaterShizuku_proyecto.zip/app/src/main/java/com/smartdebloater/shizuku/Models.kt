package com.smartdebloater.shizuku

/** El orden del enum define el orden de la lista en pantalla. */
enum class Risk(val label: String, val badge: String, val color: Long) {
    SAFE("Seguro de borrar", "✔ Seguro de borrar · se recomienda eliminar", 0xFF2E7D32),
    UNNECESSARY("Innecesario para el uso diario", "● Innecesario para el uso diario", 0xFFEF6C00),
    UNKNOWN("Sin clasificar", "? Sin clasificar · revisar", 0xFF607D8B),
    CRITICAL("Crítico / No tocar", "✖ Crítico · No tocar", 0xFFC62828)
}

enum class InfoSource { KNOWLEDGE_BASE, WEB, HEURISTIC }

data class AppEntry(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val risk: Risk,
    val summary: String,
    val source: InfoSource
)
