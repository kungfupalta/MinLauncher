package com.smartdebloater.shizuku

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.atomic.AtomicInteger

class PackageScanner(private val context: Context) {

    @Suppress("DEPRECATION")
    private fun installed(pm: PackageManager): List<ApplicationInfo> =
        if (Build.VERSION.SDK_INT >= 33)
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        else
            pm.getInstalledApplications(0)

    suspend fun scan(useWeb: Boolean, onProgress: (Int, Int) -> Unit): List<AppEntry> = coroutineScope {
        val pm = context.packageManager
        val apps = installed(pm).filter { it.packageName != context.packageName }
        val total = apps.size
        val done = AtomicInteger(0)
        val gate = Semaphore(8)

        apps.map { ai ->
            async(Dispatchers.IO) {
                val pkg = ai.packageName
                val isSystem = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
                val label = runCatching { pm.getApplicationLabel(ai).toString() }.getOrDefault(pkg)

                val known = KnowledgeBase.lookup(pkg)
                var entry = if (known != null) {
                    AppEntry(pkg, label, isSystem, known.risk, known.summary, InfoSource.KNOWLEDGE_BASE)
                } else {
                    val h = KnowledgeBase.heuristic(pkg, isSystem, ai.sourceDir)
                    AppEntry(pkg, label, isSystem, h.risk, h.summary, InfoSource.HEURISTIC)
                }

                // Investigación web solo para paquetes desconocidos y no críticos
                if (known == null && useWeb && entry.risk != Risk.CRITICAL) {
                    val web = gate.withPermit { WebInfoFetcher.fetch(pkg) }
                    if (web != null) entry = entry.copy(summary = web, source = InfoSource.WEB)
                }
                onProgress(done.incrementAndGet(), total)
                entry
            }
        }.awaitAll().sortedWith(compareBy({ it.risk.ordinal }, { it.label.lowercase() }))
    }
}
