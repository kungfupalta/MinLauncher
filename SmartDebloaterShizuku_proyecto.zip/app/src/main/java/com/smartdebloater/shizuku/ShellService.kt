package com.smartdebloater.shizuku

import kotlin.system.exitProcess

/**
 * Se ejecuta DENTRO del proceso de Shizuku (uid shell / ADB), por eso puede lanzar `pm uninstall`.
 */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val process = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            "$code\n$output"
        } catch (e: Exception) {
            "-1\n${e.message}"
        }
    }
}
