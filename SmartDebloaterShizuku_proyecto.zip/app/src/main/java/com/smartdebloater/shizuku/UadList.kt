package com.smartdebloater.shizuku

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Lista comunitaria Universal Android Debloater (Next Generation): miles de paquetes
 * (AOSP, Google, Samsung, operadoras…) con nivel de riesgo y descripción.
 * Se descarga al escanear y se guarda en caché para usarla sin conexión.
 */
object UadList {

    data class Entry(val removal: String, val description: String)

    private const val URL_LIST =
        "https://raw.githubusercontent.com/Universal-Debloater-Alliance/universal-android-debloater-next-generation/main/resources/assets/uad_lists.json"

    @Volatile private var map: Map<String, Entry> = emptyMap()

    val size: Int get() = map.size

    fun get(pkg: String): Entry? = map[pkg]

    suspend fun load(context: Context, allowDownload: Boolean) = withContext(Dispatchers.IO) {
        val cache = File(context.cacheDir, "uad_lists.json")
        if (allowDownload) runCatching { download(cache) }
        if (cache.exists()) runCatching { map = parse(cache.readText()) }
    }

    private fun download(target: File) {
        val conn = URL(URL_LIST).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            if (conn.responseCode != 200) return
            val tmp = File(target.parentFile, target.name + ".tmp")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (tmp.length() > 10_000) tmp.copyTo(target, overwrite = true)
            tmp.delete()
        } finally {
            conn.disconnect()
        }
    }

    /** Acepta tanto el formato array [{id,...}] como el objeto {"paquete": {...}}. */
    private fun parse(text: String): Map<String, Entry> {
        val out = HashMap<String, Entry>(8192)
        fun add(id: String, o: JSONObject?) {
            if (id.isBlank() || o == null) return
            val desc = o.optString("description").replace(Regex("\\s+"), " ").trim()
            out[id] = Entry(o.optString("removal"), if (desc.length > 260) desc.take(257) + "…" else desc)
        }
        if (text.trimStart().startsWith("[")) {
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(o.optString("id"), o)
            }
        } else {
            val obj = JSONObject(text)
            for (k in obj.keys()) add(k, obj.optJSONObject(k))
        }
        return out
    }
}
