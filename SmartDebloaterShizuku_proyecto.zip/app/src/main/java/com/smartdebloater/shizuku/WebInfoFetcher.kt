package com.smartdebloater.shizuku

import androidx.core.text.HtmlCompat
import java.net.HttpURLConnection
import java.net.URL

/** Consulta la ficha pública de Google Play y devuelve un resumen corto en español. */
object WebInfoFetcher {

    private val metaTag = Regex(
        "<meta[^>]+(?:name=\"description\"|property=\"og:description\")[^>]*>",
        RegexOption.IGNORE_CASE
    )
    private val content = Regex("content=\"([^\"]+)\"", RegexOption.IGNORE_CASE)

    fun fetch(pkg: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://play.google.com/store/apps/details?id=$pkg&hl=es&gl=ES")
            conn = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; SM-A536B) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                setRequestProperty("Accept-Language", "es-ES,es;q=0.9")
            }
            if (conn.responseCode != 200) return null
            val html = conn.inputStream.bufferedReader().use { it.readText() }
            val tag = metaTag.find(html)?.value ?: return null
            val raw = content.find(tag)?.groupValues?.get(1) ?: return null
            val clean = HtmlCompat.fromHtml(raw, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()
            if (clean.isBlank()) null else shorten(clean)
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun shorten(text: String, max: Int = 220): String {
        if (text.length <= max) return text
        val cut = text.substring(0, max)
        val dot = cut.lastIndexOf('.')
        return if (dot > 80) cut.substring(0, dot + 1) else "$cut…"
    }
}
