package com.smartdebloater.shizuku

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Filter(val label: String, val risk: Risk?) {
    ALL("Todas", null),
    SAFE("Seguras", Risk.SAFE),
    UNNECESSARY("Innecesarias", Risk.UNNECESSARY),
    UNKNOWN("Sin clasificar", Risk.UNKNOWN),
    CRITICAL("Críticas", Risk.CRITICAL)
}

data class UiState(
    val apps: List<AppEntry> = emptyList(),
    val selected: Set<String> = emptySet(),
    val scanning: Boolean = false,
    val progress: Float = 0f,
    val query: String = "",
    val filter: Filter = Filter.ALL,
    val useWeb: Boolean = true,
    val working: Boolean = false,
    val confirmDialog: Boolean = false,
    val report: List<String>? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val shizuku = ShizukuManager(app)
    private val scanner = PackageScanner(app)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val pkgRegex = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+\$")

    init {
        shizuku.register()
        shizuku.refresh()
        scan()
    }

    override fun onCleared() {
        shizuku.release()
    }

    fun scan() {
        if (_ui.value.scanning) return
        viewModelScope.launch {
            _ui.update { it.copy(scanning = true, progress = 0f) }
            val list = scanner.scan(_ui.value.useWeb) { d, t ->
                _ui.update { st -> st.copy(progress = d / t.toFloat()) }
            }
            val names = list.map { a -> a.packageName }.toSet()
            _ui.update { st -> st.copy(apps = list, selected = st.selected.intersect(names), scanning = false) }
        }
    }

    fun setQuery(q: String) = _ui.update { it.copy(query = q) }
    fun setFilter(f: Filter) = _ui.update { it.copy(filter = f) }
    fun setUseWeb(v: Boolean) = _ui.update { it.copy(useWeb = v) }

    fun toggle(pkg: String) = _ui.update { st ->
        val app = st.apps.firstOrNull { it.packageName == pkg }
        if (app == null || app.risk == Risk.CRITICAL) st
        else st.copy(selected = if (pkg in st.selected) st.selected - pkg else st.selected + pkg)
    }

    /** Marca solo lo catalogado como "Seguro de borrar" (bloatware / servicios basura). */
    fun autoSelect() = _ui.update { st ->
        st.copy(selected = st.apps.filter { it.risk == Risk.SAFE }.map { it.packageName }.toSet())
    }

    fun clearSelection() = _ui.update { it.copy(selected = emptySet()) }
    fun askConfirm() = _ui.update { it.copy(confirmDialog = true) }
    fun dismissConfirm() = _ui.update { it.copy(confirmDialog = false) }
    fun dismissReport() = _ui.update { it.copy(report = null) }

    fun uninstallSelected() {
        viewModelScope.launch {
            val st = _ui.value
            val targets = st.apps.filter {
                it.packageName in st.selected && it.risk != Risk.CRITICAL && pkgRegex.matches(it.packageName)
            }
            _ui.update { it.copy(working = true, confirmDialog = false) }

            val report = mutableListOf<String>()
            val removed = mutableSetOf<String>()
            for (t in targets) {
                val r = shizuku.run("pm uninstall --user 0 ${t.packageName}")
                val ok = r.exitCode == 0 && r.output.contains("Success", ignoreCase = true)
                if (ok) removed += t.packageName
                report += if (ok) "✅ ${t.label} (${t.packageName})"
                else "❌ ${t.label} (${t.packageName}): ${r.output}"
            }
            _ui.update { cur ->
                cur.copy(
                    apps = cur.apps.filterNot { it.packageName in removed },
                    selected = cur.selected - removed,
                    working = false,
                    report = report
                )
            }
        }
    }
}
