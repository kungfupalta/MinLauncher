package com.smartdebloater.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NO_PERMISSION, CONNECTING, READY }

data class CommandResult(val exitCode: Int, val output: String)

class ShizukuManager(context: Context) {

    private val _state = MutableStateFlow(ShizukuState.NOT_RUNNING)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    @Volatile private var shell: IShellService? = null
    @Volatile private var binding = false

    private val args = Shizuku.UserServiceArgs(
        ComponentName(context.packageName, ShellService::class.java.name)
    ).daemon(false).processNameSuffix("shell").version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            if (binder != null && binder.pingBinder()) {
                shell = IShellService.Stub.asInterface(binder)
                _state.value = ShizukuState.READY
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null
            binding = false
            refresh()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        shell = null
        binding = false
        _state.value = ShizukuState.NOT_RUNNING
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, grant ->
        if (grant == PackageManager.PERMISSION_GRANTED) bind() else _state.value = ShizukuState.NO_PERMISSION
    }

    fun register() {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
    }

    fun release() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        try { Shizuku.unbindUserService(args, connection, true) } catch (_: Throwable) {}
    }

    /** Re-evalúa el estado: servicio activo -> permiso -> conexión. */
    fun refresh() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                _state.value = ShizukuState.NOT_RUNNING
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bind()
            } else {
                _state.value = ShizukuState.NO_PERMISSION
            }
        } catch (_: Throwable) {
            _state.value = ShizukuState.NOT_RUNNING
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (_: Throwable) {}
    }

    private fun bind() {
        if (shell != null) { _state.value = ShizukuState.READY; return }
        if (binding) return
        binding = true
        _state.value = ShizukuState.CONNECTING
        try {
            Shizuku.bindUserService(args, connection)
        } catch (_: Throwable) {
            binding = false
            _state.value = ShizukuState.NO_PERMISSION
        }
    }

    suspend fun run(command: String): CommandResult = withContext(Dispatchers.IO) {
        val s = shell ?: return@withContext CommandResult(-1, "Shizuku no está conectado")
        try {
            val raw = s.exec(command)
            val idx = raw.indexOf('\n')
            if (idx < 0) CommandResult(-1, raw.trim())
            else CommandResult(raw.substring(0, idx).toIntOrNull() ?: -1, raw.substring(idx + 1).trim())
        } catch (e: Exception) {
            CommandResult(-1, e.message ?: "Error desconocido")
        }
    }

    private companion object { const val REQUEST_CODE = 1001 }
}
