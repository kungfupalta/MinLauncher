package com.smartdebloater.shizuku

/**
 * Base de conocimiento local (orientada a Samsung One UI / Galaxy A53 5G).
 * Orden: coincidencia exacta -> prefijos críticos -> prefijos de operadora -> heurística.
 */
object KnowledgeBase {

    data class Info(val risk: Risk, val summary: String)

    private fun s(t: String) = Info(Risk.SAFE, t)
    private fun u(t: String) = Info(Risk.UNNECESSARY, t)
    private fun c(t: String) = Info(Risk.CRITICAL, t)

    private val baseExact: Map<String, Info> = mapOf(
        // Facebook (bloatware preinstalado)
        "com.facebook.appmanager" to s("Servicio de Facebook preinstalado que instala y actualiza apps de Facebook en segundo plano. No lo necesitas."),
        "com.facebook.services" to s("Servicio auxiliar de Facebook. Solo sirve a la app de Facebook."),
        "com.facebook.system" to s("Componente de Facebook integrado en el sistema que corre en segundo plano."),
        "com.facebook.katana" to u("App de Facebook. Puedes usar la web si no la abres a diario."),
        "com.facebook.orca" to u("Messenger de Facebook."),
        // Bixby y funciones Samsung poco usadas
        "com.samsung.android.bixby.agent" to s("Asistente de voz Bixby. Si usas Google Assistant no lo necesitas."),
        "com.samsung.android.bixby.wakeup" to s("Escucha en segundo plano la orden «Hi Bixby» y gasta batería."),
        "com.samsung.android.bixby.service" to u("Servicio de apoyo de Bixby."),
        "com.samsung.android.visionintelligence" to s("Bixby Vision: reconoce objetos y textos con la cámara. Función poco usada."),
        "com.samsung.android.app.spage" to u("Samsung Free: panel de noticias y contenido a la izquierda del escritorio."),
        "com.samsung.android.arzone" to s("AR Zone: filtros y juegos de realidad aumentada."),
        "com.samsung.android.aremoji" to u("AR Emoji: crea avatares animados con la cámara."),
        "com.samsung.android.aremojieditor" to s("Editor de avatares AR Emoji."),
        "com.samsung.android.ardrawing" to s("Dibujo AR: dibuja en 3D con la cámara."),
        "com.sec.android.mimage.avatarstickers" to s("Stickers de tu avatar AR Emoji para teclado y chats."),
        "com.samsung.android.stickercenter" to u("Tienda de stickers de Samsung."),
        "com.samsung.android.livestickers" to s("Live Stickers: crea stickers recortando fotos."),
        "com.samsung.android.app.tips" to s("Consejos y tutoriales de Samsung."),
        "com.samsung.android.game.gamehome" to s("Game Launcher: agrupa juegos y muestra recomendaciones."),
        "com.samsung.android.game.gametools" to u("Game Tools: botones flotantes y capturas dentro de juegos."),
        "com.samsung.android.kidsinstaller" to s("Instalador de Samsung Kids (modo infantil)."),
        "com.samsung.android.app.watchmanagerstub" to s("Instalador del gestor de Galaxy Watch."),
        "com.samsung.sree" to s("Samsung Global Goals: muestra campañas solidarias en pantalla de bloqueo."),
        "com.samsung.android.rubin.app" to s("Servicio de personalización de Samsung: analiza hábitos para dar sugerencias."),
        "com.samsung.android.mapsagent" to s("Agente de mapas de Samsung para servicios de ubicación de terceros."),
        "com.samsung.android.tvplus" to s("Samsung TV Plus: televisión gratuita con anuncios."),
        "com.samsung.android.bbc.bbcagent" to s("Servicio de noticias BBC dentro de Samsung Free."),
        "com.samsung.android.smartcallprovider" to s("Smart Call: identifica números desconocidos y muestra publicidad."),
        "com.samsung.android.ipsgeofence" to s("Servicio de geovalla de interiores para funciones opcionales de ubicación."),
        "com.samsung.android.app.sharelive" to u("Quick Share / Share Live: compartir archivos con dispositivos cercanos."),
        "com.samsung.android.smartswitchassistant" to u("Ayudante de Smart Switch para migrar datos desde otro móvil."),
        "com.sec.android.easyMover.Agent" to u("Agente de Smart Switch."),
        "com.samsung.android.themestore" to u("Tienda de temas, fondos e iconos de Samsung."),
        "com.samsung.android.voc" to u("Samsung Members: soporte, diagnóstico y comunidad."),
        "com.samsung.android.fmm" to u("Encontrar mi móvil de Samsung. Útil si lo pierdes; bórralo solo si usas el de Google."),
        "com.samsung.android.scloud" to u("Samsung Cloud: copias de seguridad y sincronización en la nube de Samsung."),
        "com.samsung.android.app.reminder" to u("Recordatorios de Samsung."),
        "com.samsung.android.app.notes" to u("Samsung Notes: app de notas."),
        "com.samsung.android.calendar" to u("Calendario de Samsung."),
        "com.samsung.android.email.provider" to u("Correo de Samsung."),
        "com.sec.android.daemonapp" to u("Tiempo de Samsung (widget y app del clima)."),
        "com.sec.android.app.sbrowser" to u("Samsung Internet: navegador de Samsung."),
        "com.sec.android.app.samsungapps" to u("Galaxy Store: tienda de aplicaciones de Samsung."),
        "com.samsung.android.app.updatecenter" to u("Actualiza apps de Samsung fuera de Play Store."),
        "com.samsung.android.spay" to u("Samsung Wallet / Pay: pagos con el móvil."),
        "com.samsung.android.spayfw" to u("Servicio de pagos de Samsung Pay."),
        "com.samsung.android.samsungpass" to u("Samsung Pass: guarda contraseñas y datos biométricos."),
        "com.samsung.android.app.galaxyfinder" to u("Buscador global de Samsung."),
        "com.samsung.android.carkeyfw" to u("Llave digital del coche."),
        "com.sec.android.app.billing" to u("Servicio de pagos dentro de apps de Samsung."),
        "com.samsung.android.dynamiclock" to u("Pantalla de bloqueo dinámica con imágenes rotativas."),
        // Microsoft / Netflix / Amazon / terceros preinstalados
        "com.microsoft.skydrive" to s("OneDrive preinstalado: nube de Microsoft."),
        "com.microsoft.office.officehubrow" to u("Microsoft 365 (Office)."),
        "com.microsoft.office.excel" to u("Microsoft Excel."),
        "com.microsoft.office.word" to u("Microsoft Word."),
        "com.microsoft.office.powerpoint" to u("Microsoft PowerPoint."),
        "com.microsoft.office.outlook" to u("Outlook: correo de Microsoft."),
        "com.linkedin.android" to u("LinkedIn: red social profesional."),
        "com.netflix.partner.activation" to s("Servicio de activación de Netflix preinstalado por el fabricante."),
        "com.netflix.mediaclient" to u("Netflix: streaming de series y películas."),
        "com.spotify.music" to u("Spotify: música en streaming."),
        "com.amazon.appmanager" to s("Servicio de Amazon preinstalado para instalar sus apps."),
        "com.amazon.mShop.android.shopping" to u("Amazon Shopping."),
        "com.amazon.avod.thirdpartyclient" to u("Amazon Prime Video."),
        "com.mcafee.vsmandroid" to s("Antivirus McAfee de prueba preinstalado."),
        "com.mcafee.wsstub" to s("Instalador de McAfee."),
        // Google opcionales
        "com.google.android.apps.magazines" to s("Google Noticias."),
        "com.google.android.printservice.recommendation" to s("Recomienda servicios de impresión. Casi nadie lo usa."),
        "com.google.android.apps.tachyon" to u("Google Meet / Duo: videollamadas."),
        "com.google.android.videos" to u("Google TV: compra y alquiler de películas."),
        "com.google.android.apps.youtube.music" to u("YouTube Music."),
        "com.google.android.youtube" to u("YouTube."),
        "com.google.android.apps.podcasts" to u("Google Podcasts."),
        "com.google.android.apps.photos" to u("Google Fotos."),
        "com.google.android.apps.docs" to u("Google Drive."),
        "com.google.android.apps.wellbeing" to u("Bienestar digital: tiempo de uso y modos de concentración."),
        "com.google.android.apps.googleassistant" to u("Asistente de Google."),
        "com.google.android.projection.gearhead" to u("Android Auto: pantalla del móvil en el coche."),
        "com.google.ar.core" to u("Servicios de Google Play para RA: solo para apps de realidad aumentada.")
    )

    // Ampliación basada en listas de la comunidad XDA/UAD/Technastic (One UI 7/8, Android 15/16)
    private val extraExact: Map<String, Info> = mapOf(
        // --- AOSP / Google: seguros ---
        "com.android.egg" to s("Huevo de Pascua de Android (minijuego oculto). Sin utilidad real."),
        "com.android.bookmarkprovider" to s("Proveedor de marcadores del navegador antiguo."),
        "com.android.hotwordenrollment.xgoogle" to s("Entrenamiento de voz para «Hey Google»."),
        "com.android.hotwordenrollment.okgoogle" to s("Entrenamiento de voz para «Ok Google»."),
        "com.android.dynsystem" to s("Actualizaciones dinámicas del sistema (DSU), solo para desarrolladores."),
        "com.google.android.feedback" to s("Envía informes de errores y comentarios a Google."),
        "com.google.android.apps.restore" to s("Android Switch: migración de datos desde otro móvil durante la configuración inicial."),
        "com.google.android.gms.location.history" to s("Historial de ubicaciones de Google (Timeline). Registra por dónde te mueves."),
        "com.microsoft.appmanager" to s("Link to Windows: vincula el móvil con un PC con Windows."),
        // --- Samsung: seguros ---
        "com.samsung.android.bixbyvision.framework" to s("Base de Bixby Vision (reconocimiento visual)."),
        "com.samsung.android.app.settings.bixby" to s("Ajustes de Bixby dentro de Ajustes."),
        "com.samsung.android.app.camera.sticker.facearavatar.preload" to s("Stickers de Crocro & Friends para la cámara."),
        "com.samsung.storyservice" to s("Historias automáticas de la Galería."),
        "com.samsung.safetyinformation" to s("Pantalla con información regulatoria y de seguridad del equipo."),
        "com.samsung.android.service.aircommand" to s("Air Command (S Pen). El A53 no incluye S Pen."),
        "com.samsung.android.service.peoplestripe" to s("Panel Edge «Personas»."),
        "com.samsung.android.app.taskedge" to s("Panel Edge «Tareas»."),
        "com.hiya.star" to s("Hiya: identificador de llamadas con servicios de terceros."),
        "com.touchtype.swiftkey" to s("Teclado SwiftKey de Microsoft preinstalado. Te queda el teclado Samsung."),
        "com.swiftkey.swiftkeyconfigurator" to s("Configurador de fábrica de SwiftKey."),
        "com.pandora.android" to s("Pandora: música en streaming preinstalada por operadora."),
        "com.playstudios.popslots" to s("Juego de casino preinstalado."),
        "com.gsn.android.tripeaks" to s("Juego de cartas preinstalado."),
        "com.foxnextgames.m3" to s("Juego preinstalado."),
        "com.wb.goog.got.conquest" to s("Juego Game of Thrones preinstalado."),
        // --- AOSP / Google: opcionales ---
        "com.android.chrome" to u("Navegador Chrome. Bórralo solo si usas otro navegador."),
        "com.android.stk" to u("Kit de herramientas SIM: menús de servicios de algunas operadoras."),
        "com.android.apps.tag" to u("Lector de etiquetas NFC."),
        "com.android.printspooler" to u("Servicio de impresión; también se usa para «Guardar como PDF»."),
        "com.android.bips" to u("Servicio de impresión predeterminado."),
        "com.android.dreams.basic" to u("Salvapantallas interactivo."),
        "com.android.dreams.phototable" to u("Salvapantallas de fotos."),
        "com.android.wallpaper.livepicker" to u("Selector de fondos de pantalla animados."),
        "com.android.virtualization.terminal" to u("Terminal Linux de Android 16; muchos modelos no la soportan."),
        "com.google.android.adservices.api" to u("Servicios de publicidad de Google (Privacy Sandbox)."),
        "com.google.mainline.adservices" to u("Módulo de servicios de publicidad de Google."),
        "com.google.android.apps.docs.editors.sheets" to u("Hojas de cálculo de Google."),
        "com.google.android.apps.messaging" to u("Mensajes de Google (SMS/RCS). Déjalo si es tu app de mensajes."),
        "com.google.android.googlequicksearchbox" to u("App de Google y Asistente. Quitarla afecta a la búsqueda y a «Hey Google»."),
        "com.google.android.tts" to u("Voz de Google para lectura en voz alta y TalkBack."),
        "com.google.android.apps.bard" to u("Gemini, el asistente de IA de Google."),
        "com.google.android.gm" to u("Gmail."),
        "com.google.android.apps.maps" to u("Google Maps."),
        "com.google.android.syncadapters.calendar" to u("Sincroniza Google Calendar. Sin él el calendario no se actualiza con tu cuenta."),
        "com.google.android.as" to u("Android System Intelligence: sugerencias inteligentes y respuestas automáticas."),
        "com.google.android.apps.accessibility.voiceaccess" to u("Voice Access: controlar el móvil con la voz."),
        "com.google.audio.hearing.visualization.accessibility.scribe" to u("Transcripción en vivo y notificaciones de sonido."),
        // --- Samsung: opcionales ---
        "com.samsung.android.app.watchmanager" to u("Galaxy Wearable: gestiona relojes y auriculares Galaxy."),
        "com.samsung.android.forest" to u("Bienestar digital de Samsung."),
        "com.samsung.android.app.interpreter" to u("Intérprete: traducción simultánea de Samsung."),
        "com.samsung.android.app.sketchbook" to u("Asistente de dibujo."),
        "com.sec.android.app.vepreload" to u("Studio: editor de vídeo de Samsung."),
        "com.sec.android.app.quicktool" to u("Herramientas rápidas (linterna, medidor…)."),
        "com.samsung.android.video" to u("Reproductor de vídeo de Samsung."),
        "com.sec.android.app.voicenote" to u("Grabadora de voz de Samsung."),
        "com.sec.android.app.popupcalculator" to u("Calculadora de Samsung."),
        "com.sec.android.app.shealth" to u("Samsung Health: pasos, sueño y ejercicio."),
        "com.samsung.android.oneconnect" to u("SmartThings: control de dispositivos del hogar."),
        "com.samsung.android.service.stplatform" to u("Servicio de apoyo de SmartThings."),
        "com.sec.android.easyMover" to u("Smart Switch: pasar datos desde otro móvil."),
        "com.samsung.android.aware.service" to u("Agente de Quick Share."),
        "com.samsung.android.mdx" to u("Servicio de enlace con Windows."),
        "com.samsung.android.mdx.kit" to u("Conectividad de Quick Share."),
        "com.samsung.android.allshare.service.mediashare" to u("Compartir contenido con dispositivos cercanos."),
        "com.samsung.android.mydevice" to u("Detección de dispositivos cercanos."),
        "com.samsung.android.easysetup" to u("Escaneo de dispositivos cercanos para configurarlos."),
        "com.samsung.android.beaconmanager" to u("Agente de escaneo de dispositivos cercanos."),
        "com.samsung.android.app.appsedge" to u("Panel Edge «Apps»."),
        "com.samsung.android.app.clipboardedge" to u("Panel Edge del portapapeles."),
        "com.sec.android.dexsystemui" to u("Interfaz de Samsung DeX (modo escritorio)."),
        "com.sec.android.desktopmode.uiservice" to u("Servicio de Samsung DeX."),
        "com.sec.android.app.desktoplauncher" to u("Pantalla de inicio de DeX."),
        "com.sec.unifiedwfc" to u("Llamadas por Wi-Fi. Útil si tu operadora lo ofrece."),
        "com.sec.hearingadjust" to u("Adaptar sonido: perfil auditivo."),
        "com.samsung.android.bluelightfilter" to u("Protección ocular (filtro de luz azul)."),
        "com.samsung.android.universalswitch" to u("Interruptor universal (accesibilidad)."),
        "com.samsung.android.app.aodservice" to u("Pantalla siempre activa (AOD). Si la quitas, pierdes esa función."),
        "com.samsung.android.sdk.handwriting" to u("Servicio de escritura a mano."),
        "com.samsung.knox.securefolder" to u("Carpeta segura: espacio cifrado. Requiere cuenta Samsung."),
        "com.sec.penup" to u("PENUP: comunidad de dibujo de Samsung."),
        "com.samsung.android.samsungpassautofill" to u("Autorrelleno con Samsung Pass."),
        "com.samsung.android.app.routines" to u("Modos y rutinas. Si las usas, no la quites."),
        // --- Samsung: críticas (conocidas por romper funciones) ---
        "com.samsung.android.app.dressroom" to c("Fondos y estilo. Si la quitas no podrás cambiar el fondo de pantalla."),
        "com.samsung.android.scpm" to c("Samsung Cloud Assistant: otras apps de Samsung dependen de él."),
        "com.sec.android.app.myfiles" to c("Mis archivos. Quitarla puede hacer fallar Ajustes."),
        "com.samsung.android.smartmirroring" to c("Smart View: lo usan el launcher y el reproductor."),
        "com.samsung.android.app.smartcapture" to c("Capturas de pantalla avanzadas y grabación."),
        "com.samsung.android.wifi.softap.resources" to c("Recursos del punto de acceso Wi-Fi / datos móviles."),
        "com.sec.location.nsflp2" to c("Proveedor de ubicación de Samsung (GPS)."),
        "com.osp.app.signin" to c("Cuenta Samsung. Otras apps dependen de ella."),
        "com.sec.android.diagmonagent" to c("Agente de diagnóstico del sistema; quitarlo puede causar cierres."),
        "com.samsung.android.dkey" to c("Llave digital de Samsung Wallet; quitarla puede aumentar el consumo en segundo plano.")
    )

    private val exact: Map<String, Info> = baseExact + extraExact

    private val critical: List<Pair<String, String>> = listOf(
        "android" to "Núcleo del framework de Android.",
        "com.android.systemui" to "Interfaz del sistema: barra de estado, notificaciones y ajustes rápidos.",
        "com.android.phone" to "Servicios de telefonía: llamadas y red móvil.",
        "com.android.settings" to "App de Ajustes del sistema.",
        "com.android.providers" to "Proveedor de datos del sistema (contactos, SMS, medios, descargas…).",
        "com.android.server" to "Componente interno del servidor del sistema.",
        "com.android.bluetooth" to "Servicio Bluetooth.",
        "com.android.nfc" to "Servicio NFC y pagos sin contacto.",
        "com.android.networkstack" to "Pila de red del sistema.",
        "com.google.android.networkstack" to "Pila de red del sistema.",
        "com.android.wifi" to "Servicio Wi-Fi.",
        "com.google.android.wifi" to "Servicio Wi-Fi.",
        "com.android.permissioncontroller" to "Gestor de permisos de apps.",
        "com.google.android.permissioncontroller" to "Gestor de permisos de apps.",
        "com.android.packageinstaller" to "Instalador de paquetes.",
        "com.google.android.packageinstaller" to "Instalador de paquetes.",
        "com.google.android.gms" to "Servicios de Google Play: notificaciones push, ubicación y login. Muchas apps dependen de él.",
        "com.google.android.gsf" to "Framework de servicios de Google.",
        "com.android.vending" to "Google Play Store.",
        "com.google.android.webview" to "WebView: muestra contenido web dentro de las apps.",
        "com.android.webview" to "WebView del sistema.",
        "com.android.shell" to "Shell del sistema, usado también por ADB/Shizuku.",
        "com.android.cellbroadcast" to "Alertas de emergencia.",
        "com.android.carrierconfig" to "Configuración de operadora (datos móviles, VoLTE).",
        "com.android.keychain" to "Almacén de certificados y claves.",
        "com.android.certinstaller" to "Instalador de certificados.",
        "com.android.location.fused" to "Proveedor de ubicación.",
        "com.android.inputdevices" to "Dispositivos de entrada.",
        "com.android.ext.services" to "Servicios extendidos del sistema.",
        "com.android.managedprovisioning" to "Aprovisionamiento del dispositivo.",
        "com.android.documentsui" to "Selector de archivos del sistema.",
        "com.google.android.documentsui" to "Selector de archivos del sistema.",
        "com.android.captiveportallogin" to "Inicio de sesión en redes Wi-Fi con portal.",
        "com.sec.android.app.launcher" to "Pantalla de inicio One UI. Sin ella no hay escritorio.",
        "com.samsung.android.knox" to "Seguridad Samsung Knox.",
        "com.knox" to "Seguridad Samsung Knox.",
        "com.samsung.android.dialer" to "Aplicación de teléfono.",
        "com.samsung.android.incallui" to "Pantalla de llamada en curso.",
        "com.samsung.android.messaging" to "Aplicación de mensajes/SMS.",
        "com.samsung.android.contacts" to "Aplicación de contactos.",
        "com.samsung.android.honeyboard" to "Teclado de Samsung.",
        "com.google.android.inputmethod" to "Teclado de Google (Gboard).",
        "com.samsung.android.app.telephonyui" to "Interfaz de telefonía de Samsung.",
        "com.sec.imsservice" to "Servicio IMS: VoLTE y llamadas Wi-Fi.",
        "com.sec.phone" to "Servicios de telefonía de Samsung.",
        "com.samsung.android.providers" to "Proveedor de datos de Samsung.",
        "com.sec.android.provider" to "Proveedor de datos de Samsung.",
        "com.samsung.android.biometrics" to "Huella y reconocimiento facial.",
        "com.sec.android.app.camera" to "Cámara.",
        "com.sec.android.gallery3d" to "Galería.",
        "com.samsung.android.app.settings" to "Ajustes de Samsung.",
        "com.samsung.android.settings" to "Ajustes de Samsung.",
        "moe.shizuku.privileged.api" to "Shizuku: la herramienta que usa esta app para desinstalar."
    )

    private val carrierPrefixes = listOf(
        "com.vzw", "com.verizon", "com.att", "com.tmobile", "com.sprint",
        "com.orange", "com.vodafone", "com.telefonica", "com.movistar", "com.claro",
        "com.vcast", "com.asurion", "com.motricity", "com.synchronoss", "com.wavemarket"
    )

    private val criticalHint = Regex(
        "launcher|keyboard|inputmethod|telecom|telephony|dialer|systemui|provision|setupwizard|provider|" +
            "bluetooth|nfc|wifi|knox|security|permission|installer|webview|biometric|fingerprint|" +
            "cellbroadcast|emergency|modem|\\.ril|network|vpn|settings|framework|accessibility|" +
            "\\.gms|\\.gsf|vending|camera|gallery|contacts|messag|\\.mms|\\.sms|\\.sim"
    )

    private fun matches(pkg: String, prefix: String) = pkg == prefix || pkg.startsWith("$prefix.")

    /** Información si el paquete es conocido; null si hay que usar heurística/web. */
    fun lookup(pkg: String): Info? {
        exact[pkg]?.let { return it }
        critical.firstOrNull { matches(pkg, it.first) }?.let {
            return Info(Risk.CRITICAL, it.second + " Eliminarla puede provocar fallos graves o bootloop.")
        }
        UadList.get(pkg)?.let { e ->
            val text = (if (e.description.isBlank()) "Sin descripción en la lista UAD." else e.description) + " (fuente: UAD, en inglés)"
            when (e.removal) {
                "Recommended" -> return Info(Risk.SAFE, text)
                "Advanced" -> return Info(Risk.UNNECESSARY, text)
                "Expert" -> return Info(Risk.UNKNOWN, "Solo para expertos. $text")
                "Unsafe" -> return Info(Risk.CRITICAL, "Peligroso de borrar. $text")
            }
        }
        if (pkg.startsWith("com.samsung.SMT")) {
            return Info(Risk.UNNECESSARY, "Motor/voces de síntesis de voz de Samsung. Solo si usas lectura en voz alta.")
        }
        if (carrierPrefixes.any { matches(pkg, it) }) {
            return Info(Risk.UNNECESSARY, "App preinstalada por tu operadora (gestión de cuenta, ofertas o servicios propios).")
        }
        return null
    }

    fun heuristic(pkg: String, isSystem: Boolean, sourceDir: String?): Info = when {
        !isSystem -> Info(Risk.UNKNOWN, "Aplicación instalada por ti. Decide tú si la sigues usando.")
        criticalHint.containsMatchIn(pkg) ->
            Info(Risk.CRITICAL, "El nombre del paquete indica un componente esencial del sistema (telefonía, red, seguridad, ajustes…).")
        sourceDir?.contains("/priv-app/") == true ->
            Info(Risk.CRITICAL, "App privilegiada del sistema: tiene permisos especiales y otros servicios dependen de ella.")
        else -> Info(Risk.UNKNOWN, "App de sistema sin información conocida. No la borres sin investigarla antes.")
    }
}
