package com.smartdebloater.shizuku;

interface IShellService {
    // Transacción reservada por Shizuku para destruir el servicio
    void destroy() = 16777114;

    // Devuelve "<exitCode>\n<salida stdout+stderr>"
    String exec(String command) = 1;
}
